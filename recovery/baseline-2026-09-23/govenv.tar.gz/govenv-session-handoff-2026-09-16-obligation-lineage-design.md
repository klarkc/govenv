# Govenv session handoff — obligation continuity, supersession, disposition and constitutional lineage

**Date:** 2026-09-16  
**Repository:** `klarkc/govenv`  
**Purpose:** Resume the design study before changing the constitution or kernel.

## 1. Starting question

We investigated whether superseded governance items (`GV`s) are still implemented/proved and whether their proofs remain checked.

Current implementation in `src/Govenv/Kernel/Assurance.agda` requires assurance coverage only for `done` items. `todo`, `cancelled`, and `superseded` items are skipped by `doneItemsCovered`.

Therefore, today:

```text
✓ done          -> assurance required
◇ todo          -> no assurance required yet
× cancelled     -> no assurance required
↪ superseded    -> no assurance required
```

A historical assurance module may remain imported/typechecked, but `completionCoverage` does not require an assurance for a superseded item.

This exposed an important gap: a completed GV can be superseded and its operative obligation can disappear without any formal proof that the replacement preserved, reformulated, or intentionally withdrew that obligation.

## 2. Relevant current governance

### GV54 — immutable governance history

GV54 is done.

It preserves immutable governance identity across roadmap evolution:

- `GovernanceId` cannot disappear or be reused.
- Definition and owning phase cannot mutate.
- Obsolete/corrected governance remains represented as `cancelled` or `superseded`.
- Supersession explicitly identifies a newer replacement `GovernanceId`.

This preserves the **GV**, but not necessarily continuity of the **obligation established by the GV**.

### GV74 — evidence-bearing completion

GV74 is currently `todo`.

Its proposition says, in essence:

- a GV may transition to `done` only when governed evidence establishes it;
- every **non-superseded** `done` item must remain satisfied in subsequent valid states.

The important gap is the phrase `non-superseded`: once a `done` item becomes `superseded`, the current design stops requiring its obligation.

### GV86 — cumulative constitution

GV86 is currently `todo`.

Its intended semantics are important:

- governance items are cumulative constitutional decisions;
- from introduction onward, each item is interpreted against the complete constitution at that revision;
- `todo`, `done`, `superseded`, and `cancelled` remain constitutional history;
- lifecycle determines **operative effect**, not constitutional membership;
- explicit arbitrary dependency relationships between GVs are not required/modelled.

We agreed this is a better model than making every new GV explicitly depend on every previous GV.

## 3. Core architectural distinction

We agreed that the constitution should distinguish:

```text
constitutional membership
operative effect
historical establishment
```

Example:

```text
GV10 ↪ GV50
```

means:

```text
GV10:
  remains constitutional history: yes
  remains immutable/revision-addressable: yes
  continues directly operative: no
```

Supersession must not mean deletion.

## 4. Problem discovered: supersession can currently erase obligation

Example:

```text
GV10 ✓
  proposition: P
  assurance: proof P
```

then:

```text
GV10 ↪ GV100
GV100 ◇
```

Today the system can reach a state where:

```text
GV10 no longer requires assurance
GV100 is still todo
therefore no current obligation formally requires P
```

This is an unacceptable gap.

The key principle agreed:

> Constitutional obligations may evolve, but they may never disappear by omission.

GV54 currently guarantees that the **governance identity** cannot silently disappear. We need a complementary rule ensuring that an **established obligation** cannot silently disappear.

## 5. Do not solve this with a general GV dependency graph

We explicitly rejected this model:

```text
GV100 depends GV0
GV100 depends GV1
...
GV100 depends GV99
```

That would reintroduce a redundant and fragile DAG.

Instead, retain GV86:

```text
new GV
  is interpreted against the whole constitution at its revision
```

Cross-GV relations should exist only where there is a specific typed constitutional meaning, especially:

- planned replacement;
- effective supersession;
- obligation lineage/disposition.

This is a **normative lineage graph**, not a generic dependency graph.

## 6. Planned replacement must be distinct from effective supersession

We rejected a rule equivalent to:

```text
done -> superseded(done replacement)
```

because that prevents future planning.

A completed operative GV must be allowed to have a future replacement planned while remaining fully operative.

Agreed conceptual distinction:

```text
↝  planned replacement / replacement intent
↪  effective supersession
```

Example lifecycle:

```text
R1:
GV10 ✓

R2:
GV10 ✓
GV100 ◇
GV10 ↝ GV100

R3:
GV10 ✓
GV100 ✓
GV10 ↝ GV100

R4:
GV10 ↪ GV100
GV100 ✓
```

Semantics:

```text
↝ = planning only; no change to operative obligations
↪ = effective constitutional transfer/disposition
```

A planned replacement can exist for multiple revisions without disabling the old obligation.

The exact Agda source operator syntax is **not finalized**. `↝` is the preferred semantic/projected notation for planning, while current `↪` should remain effective supersession.

## 7. Supersession needs governed disposition

Effective supersession should not merely mean:

```text
old rule no longer matters
```

It should mean:

> The old GV stops exercising its obligation directly because the constitution has established a governed disposition for those obligations.

Conceptual structure:

```text
GVold
  |
  | established obligations
  v
Supersession GVold GVnew
  |
  | total disposition
  v
GVnew / new obligation lineage
```

Possible semantic outcomes discussed:

```text
preserved
strengthened
weakened
reformulated
withdrawn
```

However, we should **not freeze these as constructors yet**. Their exact formal meaning must be studied first.

Important distinction:

- preservation can often be derived/proved;
- withdrawal is a normative decision and must be explicit;
- reformulation needs a typed relation to the replacement obligation;
- “missing” must never be interpreted as withdrawal.

## 8. Critical refinement: derive disposition from proofs where possible

The user proposed an important improvement:

> The agent produces the proof for the new GV. The compiler should be able to determine which inherited obligations are exercised/covered by the new proof. If something is not covered, the compiler should force an explicit disposition.

We agreed, with one essential rule:

> The compiler may infer **coverage**, but it must never infer `withdrawn` merely because something was omitted.

Bad:

```text
old obligation not mentioned
=> compiler assumes withdrawn
```

Correct:

```text
old obligation not covered
=> compilation failure
```

Then the author/agent must either:

```text
prove/cover it
```

or explicitly:

```text
withdraw it
```

or explicitly establish a reformulation.

This turns “agent forgot an old obligation” from a review problem into a type error.

## 9. Do not inspect whether a proof term literally reuses the old proof

We explicitly rejected syntactic proof-use tracking.

Reason:

```agda
newProof : OldProof -> NewProof
newProof old = someOtherProof
```

may accept but ignore `old`.

Conversely, a new proof may imply the old proposition without referring to the old proof term.

Therefore the correct question is semantic:

> Does the new evidence establish/cover the inherited obligation?

Not:

> Did the source code reference the old proof?

## 10. Obligation identity is becoming important

Earlier `ObligationId` looked like a future refinement. During this session we concluded it may be needed relatively early.

Reason: if a GV contains multiple semantic responsibilities, the compiler needs identities to know which obligation was:

- preserved;
- reformulated;
- withdrawn;
- left uncovered.

Conceptually:

```text
GV10 introduces:
  O1 = A
  O2 = B
  O3 = C
```

Then a replacement could establish:

```text
O1 -> covered/preserved
O2 -> reformulated as O4
O3 -> explicitly withdrawn
O5 -> newly introduced
```

The kernel can require **totality**:

```text
every operative inherited obligation
has exactly one governed disposition
```

and **disjointness**:

```text
an obligation cannot simultaneously be preserved and withdrawn
```

## 11. Migration strategy for ObligationId

We do not want to explode the current project by decomposing every historical GV immediately.

A pragmatic first model:

```text
each existing GV initially owns one implicit obligation:
O(GVx, 0)
```

Example:

```text
GV3  -> O(GV3,0)
GV54 -> O(GV54,0)
GV70 -> O(GV70,0)
```

Later, new GVs may introduce multiple obligations if needed:

```text
O(GV100,0)
O(GV100,1)
O(GV100,2)
```

This preserves migration feasibility while leaving the architecture open to finer granularity.

## 12. Proposed coverage model

Conceptually, evidence should carry obligation coverage in its type.

Example shape (not final Agda):

```text
Evidence Proposition [ObligationId...]
```

Example:

```text
proofA : Evidence A [O1]
proofB : Evidence B [O2]

combine proofA proofB
=> Evidence (A × B) [O1, O2]
```

For effective supersession:

```text
Inherited  = [O1, O2, O3]
Covered    = [O1, O2]
Withdrawn  = [O3]

Covered U Withdrawn = Inherited
```

or with reformulation:

```text
Inherited    = [O1, O2, O3]
Covered      = [O1]
Reformulated = [O2 -> O7]
Withdrawn    = [O3]
```

No inherited obligation may remain unaccounted for.

The exact type representation is still open.

## 13. Important ownership decision: disposition belongs to the transition

We concluded that disposition should probably not belong directly to the lifecycle state of the old GV or as arbitrary metadata on the new GV.

Better conceptual ownership:

```text
Supersession old new
```

with its own proof/disposition information.

This is important because:

```text
GVold
GVnew
```

are constitutional decisions, while:

```text
Supersession old new
```

is a typed constitutional **transition**.

That distinction avoids turning ordinary GVs into dependency containers.

## 14. Constitution vs OperativeConstitution

We agreed to seriously consider making this distinction formal.

```text
Constitution[R]
  = complete immutable governance history at revision R
```

including:

```text
todo
done
cancelled
superseded
replacement intents
historical transitions
```

Then derive:

```text
OperativeConstitution[R]
```

containing the obligations currently in force.

Conceptual pipeline:

```text
Constitution[R]
      |
      | lifecycle + relations + dispositions
      v
OperativeConstitution[R]
      |
      +--> coherence
      +--> assurance
      +--> validation
```

This would make current semantics much clearer than scattering “operative/not operative” logic across roadmap and assurance.

## 15. Constitutional coherence

A missing future property was identified.

Example invalid state:

```text
GV10 ✓ : P
GV100 ✓ : not P
```

If neither supersedes/disposes the other, the operative constitution is contradictory.

A future notion of validity should trend toward:

```text
ValidConstitution R =
  structurallyValid
  AND supersessionValid
  AND obligationsDischarged
  AND operativeCoherent
  AND assurancesSatisfied
```

Intentional change is valid only when the constitution explicitly explains the transition/disposition.

## 16. Cancelled vs superseded

We want a strict semantic distinction:

```text
cancelled
= planned governance that never became an established operative obligation
  and was abandoned

superseded
= an established or planned decision remains historical,
  but responsibility/effect moved through an explicit replacement transition
```

Likely desirable future invariant:

```text
done -> cancelled
```

should be impossible.

A completed item should only leave direct operative authority through governed supersession/disposition.

## 17. N->M supersession should remain possible architecturally

Current model is one old GV pointing to one newer replacement.

We do not need to implement N->M immediately, but should avoid types that permanently forbid:

Split:

```text
GV10
  -> GV100
  -> GV101
```

Merge:

```text
GV10 --\
GV20 ----> GV100
GV30 --/
```

This becomes even more natural if lineage is expressed over `ObligationId`s rather than GV dependencies.

## 18. Chains of supersession

Example:

```text
GV10 ↪ GV50
GV50 ↪ GV100
```

We do **not** want GV100 to manually depend on or list GV10.

The kernel should derive lineage transitively.

Desired question:

```text
current responsibility for O1 = ?
```

and derive:

```text
GV100
```

from the transition chain.

Historical proofs remain auditable without requiring every future GV to import the whole chain.

## 19. Roadmap / DSL design

Current DSL exposes:

```text
phase:
■ finished
▣ active
□ future

item:
✓ done
◇ todo
× cancelled
↪ superseded

tree:
┬
├
╟
```

Current `↪` is already strongly associated with effective terminal supersession and should probably remain so.

Preferred conceptual addition:

```text
↝ planned replacement
```

But exact Agda source syntax is not chosen yet.

Important design rule:

> Replacement intent should be a relation/dimension, not a new lifecycle state.

For example, projected state may read:

```text
✓ GV77  Current release governance
◇ GV95  New release governance
         GV77 ↝ GV95
```

while source syntax may differ if another Agda notation is cleaner.

Do not force source syntax and rendered syntax to be identical.

## 20. Delta redesign

Current `Govenv.Kernel.Release.ItemProgress` contains:

```text
completed
advanced
introduced
cancelledProgress
supersededProgress
```

We observed that supersession is semantically different from ordinary item lifecycle because it relates governance identities and changes operative authority.

Potential future split:

```text
GovernanceDelta
├── ItemImpact
│    ├── introduced
│    ├── advanced
│    ├── completed
│    └── cancelled
│
├── RelationImpact
│    ├── replacementPlanned
│    └── supersessionActivated
│
└── PhaseProgress
```

`supersessionActivated` would carry/derive the total obligation disposition.

We also identified a useful distinction:

```text
establishment impact
vs
operative impact
```

Example:

```text
R1:
GV77 ✓
GV95 ◇
GV77 ↝ GV95

R2:
GV77 ✓
GV95 ✓
GV77 ↝ GV95
```

Delta R1->R2:

```text
GV95 completed
operative changes: none
```

Then:

```text
R3:
GV77 ↪ GV95
GV95 ✓
```

Delta R2->R3:

```text
operative supersession activated
```

This is semantically cleaner than treating all of it as one item-progress category.

## 21. Changelog / PR / GitHub Release

The current release-governance materialization already has:

- typed `SupersessionDelta`;
- resolved/unresolved supersession;
- old/new proposition comparison;
- phase-change comparison;
- GitHub and portable changelog renderers;
- semantic diff of old/new proposition text.

This existing infrastructure is a strong fit for the new model.

Target architecture:

```text
proof / constitution
      |
      v
derived obligation dispositions
      |
      v
typed GovernanceDelta
      |
      +--> CHANGELOG
      +--> Release Please PR body
      +--> GitHub Release
```

The changelog should **never decide** disposition. It only projects typed results.

Possible future presentation:

Planned replacement:

```text
GV77 ↝ GV95
GV77 remains operative
GV95 pending
```

Effective supersession:

```text
GV77 ↪ GV95

Obligations:
  O1 preserved
  O2 reformulated -> O7
  O3 withdrawn
```

The exact UI is not finalized.

## 22. Core projection principle

We agreed on this architectural rule:

```text
Roadmap
  = constitutional state

Delta
  = typed constitutional transition

CHANGELOG / PR / Release
  = projections of that transition
```

Never the reverse.

This fits the existing direction of GV95, where Govenv is intended to be the semantic owner of canonical changelog/release governance content.

## 23. Real cases to use as design tests

Before adding new GVs, test the formal model against actual supersessions already in the roadmap:

```text
GV47 -> GV68
GV49 -> GV69
GV48 -> GV70
GV77 -> GV95
```

For each, determine:

1. What obligation existed?
2. Was the old GV `todo` or `done` when superseded?
3. What assurance/evidence existed?
4. Does the replacement proof semantically cover the old obligation?
5. Is the relationship preservation, reformulation, weakening, withdrawal, or something else?
6. Can that relationship be derived from typed evidence?
7. What must remain an explicit normative decision?
8. How should it appear in:
   - roadmap,
   - typed delta,
   - CHANGELOG,
   - PR,
   - GitHub Release?

Use these real cases before inventing abstractions.

## 24. Proposed next work sequence

Do **not** modify the constitution/kernel yet.

Resume with a formal design spike:

### Step A — define candidate types on paper

Study candidate shapes for:

```text
ObligationId
ReplacementIntent
Coverage
Supersession
Disposition
OperativeConstitution
```

Do not commit to syntax yet.

### Step B — exercise real historical cases

Use:

```text
47 -> 68
49 -> 69
48 -> 70
77 -> 95
```

Build a table for each case.

### Step C — close the transition matrix

At minimum test:

```text
nonexistent -> todo
todo -> done
todo -> cancelled

done + planned replacement
todo + planned replacement
replacement candidate done while old remains operative

done -> effective superseded
todo -> effective superseded

supersession chain
replacement-of-replacement
planned replacement abandoned
split / merge (at least as architectural thought experiments)
```

For each define:

```text
roadmap representation
operative effect
proof requirements
delta
changelog projection
valid / invalid
```

### Step D — choose operators

Likely semantics:

```text
↝ planned replacement
↪ effective supersession
```

But confirm after Step C.

### Step E — define delta types

Decide whether to formally split:

```text
ItemImpact
RelationImpact
PhaseProgress
```

and whether establishment vs operative impact should be first-class.

### Step F — only then write governance items

Once the model is coherent, introduce new GV(s) to constitutionalize:

- obligation continuity;
- planned replacement vs effective supersession;
- total governed disposition;
- compiler-derived coverage;
- explicit withdrawal/reformulation where proof coverage does not suffice;
- no obligation disappearing by omission;
- operative constitution / coherence if included in same or later GV.

Because GV54 makes definitions immutable, avoid prematurely creating a GV with an incomplete design.

## 25. Central design principles agreed

```text
1. Governance history is append-only.

2. Lifecycle controls operative effect, not constitutional membership.

3. New GVs are interpreted against the whole constitution;
   no arbitrary all-prior-GV dependency DAG.

4. Planned replacement does not deactivate the old GV.

5. Effective supersession requires total disposition of inherited
   established obligations.

6. New evidence should automatically prove/cover inherited obligations
   when the type demonstrates that coverage.

7. Missing coverage is an error, never implicit withdrawal.

8. Withdrawal is an explicit normative decision.

9. Reformulation is an explicit typed relation to new obligation(s).

10. Every inherited operative obligation has exactly one destiny.

11. Cross-GV relations are typed constitutional transitions/lineage,
    not general dependencies.

12. Delta is derived from typed constitutional transition.

13. Changelog/PR/Release only project the delta.

14. The long-term graph is better understood as obligation lineage,
    not GV dependency.
```

## 26. Current code areas relevant for continuation

Inspect these first in the next session:

```text
src/Govenv/Kernel/Roadmap.agda
src/Govenv/Roadmap/DSL.agda
src/Govenv/Kernel/Assurance.agda
Govenv/Assurance.lagda.md
src/Govenv/Kernel/Release.agda
Govenv/Materialization/ReleaseGovernance.lagda.md
src/Govenv/Projection/ReleaseGovernance.agda
Govenv/Roadmap.lagda.md
.govenv/roadmap.snapshot
```

Current important implementation facts:

```text
ItemState =
  done
  todo
  cancelled
  superseded GovernanceRef
```

Current roadmap integrity checks supersession target:

```text
old GV index < replacement GV index
replacement exists in roadmap
```

Current assurance coverage skips superseded items.

Current release delta allows:

```text
done -> superseded
todo -> superseded
```

and treats superseded as terminal.

Current release materialization already derives resolved supersession cards and proposition diffs.

## 27. No repository changes made in this session

This session was design analysis only.

No new GV was added.
No branch/PR was created.
No kernel code was modified.
No release was created or triggered.

The next session should resume from **Step A: candidate type design and real-case simulation**, not implementation.
