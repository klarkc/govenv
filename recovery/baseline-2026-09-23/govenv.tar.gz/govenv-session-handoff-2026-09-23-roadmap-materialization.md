# Govenv — Session Handoff

Date: 2026-09-23
Repo: `klarkc/govenv`
Local repo used in this session: `/home/klarkc/Sources/klarkc/govenv`

## Current committed baseline

Last known committed/pushed HEAD:

```text
9217340 gov(roadmap): index governance by phase
```

Important: everything described below after that commit was still WIP / uncommitted when the session was stopped.

Known nearby history:

```text
9217340 gov(roadmap): index governance by phase
8456e5b gov(roadmap): distinguish pending item glyph
0a50c3b gov(roadmap): distinguish active phase glyph
7ade94c gov(roadmap): unify phase and item state notation
bb10417 gov(release): define governance delta
22fd80a gov(roadmap): type governance identifiers
1029e8e gov(admin): record verified materialization
c7b6f1c gov(admin): verify materialization read-back
```

## Project thesis

Canonical product idea:

> A type system for your repository. Formally define what your project is allowed to become.

Architectural direction:

```text
Constitution / governed values
        ↓
Pure projections / serialization
        ↓
Effectful adapters
        ↓
Repository / GitHub / external systems
```

Policy belongs in governed values. Projection layers should not invent policy. Adapters should only apply, observe, or verify.

---

# 1. Roadmap redesign agreed in this session

The previous roadmap encoded phase ownership twice:

```agda
GovernanceId : PhaseId → Set
```

plus phases containing items indexed by the same phase.

We decided to remove that coupling and introduce a generic typed identifier.

## Generic identifier

Agreed direction:

```agda
data IdentifierKind : Set where
  Phase Governance : IdentifierKind

data Identifier
  (kind : IdentifierKind)
  : Nat → String → Set where

  identifier :
    (idx : Nat) →
    (description : String) →
    Identifier kind idx description
```

Aliases:

```agda
PhaseId : Nat → String → Set
PhaseId = Identifier Phase

GovernanceId : Nat → String → Set
GovernanceId = Identifier Governance
```

Visual constructors:

```agda
P :
  (idx : Nat) →
  (description : String) →
  PhaseId idx description

GV :
  (idx : Nat) →
  (description : String) →
  GovernanceId idx description
```

This means:

```agda
P 1 "Formal governance kernel"
```

has type:

```agda
PhaseId 1 "Formal governance kernel"
```

and:

```agda
GV 45 "Require every admin materialization ..."
```

has type:

```agda
GovernanceId 45 "Require every admin materialization ..."
```

Number and description are both available at type level and runtime.

Common helpers:

```agda
indexOf
descriptionOf
```

should work for both phases and governance IDs.

---

# 2. BelongsTo

The phase/GV relation should not live inside `GovernanceId`.

Agreed model:

```agda
data BelongsTo
  (governance : GovernanceId gvIdx gvDescription)
  (phase : PhaseId phaseIdx phaseDescription)
  : Set where

  belongs : BelongsTo governance phase
```

The relationship is structural and generated when the GV is attached to a phase.

The constitutional roadmap should NOT expose explicit proofs.

Conceptually:

```text
GV 45 "..."
   │
   └── BelongsTo ──→ P 1 "Formal governance kernel"
```

The position in the hierarchy establishes that evidence.

---

# 3. Final roadmap surface

User explicitly wanted `Govenv/Roadmap.lagda.md` to hide implementation details.

It should contain only:

- module/import boilerplate;
- one single `roadmap` value;
- phases and GVs;
- no `PhaseId` definition;
- no `GovernanceId` definition;
- no `BelongsTo`;
- no intermediate `phase0`, `phase1`, etc.;
- no raw list constructors;
- no implementation records.

Desired visual form:

```agda
roadmap = roadmapOf (
    P 0 "Bootstrap and project shape" ■
    ┬ GV 0 "Literate `Govenv.lagda.md` closure root." ✓
    ├ GV 1 "Project governance under `Govenv/`; reusable kernel under `Govenv.Kernel.*`." ✓
    ├ GV 2 "Reproducible Stage 0 bootstrap, documentation site, and automated releases." ✓

  ╟ P 1 "Formal governance kernel" ▣
    ┬ GV 3 "`Verdict`: `holds`, `violated`, and `unknown`." ✓
    ├ GV 4 "Minimal `Rule` abstraction." ✓
    ...
    ├ GV 50 "Use generic typed identifiers with structural `BelongsTo`, and express the entire roadmap as one declarative tree with implementation mechanics hidden." ✓

  ╟ P 2 "Pure repository evaluator" □
    ┬ GV 25 "Evaluate facts, rules, verdicts, obligations, and diagnostics without IO." ◇

  ...
)
```

Visual semantics:

```text
■ finished phase
▣ active phase
□ future phase

✓ completed GV
◇ pending GV

┬ first child
├ sibling child
╟ next phase
```

`└` is better kept for rendered output where the last child is known; source DSL can use `├` consistently.

---

# 4. Roadmap implementation WIP

New files created during WIP:

```text
src/Govenv/Kernel/Identifier.agda
src/Govenv/Roadmap/DSL.agda
```

`src/Govenv/Kernel/Roadmap.agda` was substantially rewritten.

The kernel currently has concepts roughly like:

```agda
ItemState
PhaseState
BelongsTo
GovernanceSpec
Membership
PhaseNode
Roadmap
PhaseSequence
ValidRoadmap
AllFuture
```

The intended invariant remains:

```text
finished* → exactly one active → future*
```

or, for a completed roadmap:

```text
finished+
```

The sequence is normalized into:

```agda
progressing :
  List (PhaseNode finished) →
  PhaseNode active →
  List (PhaseNode future) →
  Roadmap

complete :
  List (PhaseNode finished) →
  Roadmap
```

The roadmap DSL exposes only:

```agda
P
GV

_■
_▣
_□

_✓
_◇

_┬_
_├_
_╟_

roadmapOf
```

---

# 5. Exact current roadmap failure

The last test run reached the new roadmap representation, but failed on instance inference for `ValidRoadmap`.

Error was essentially:

```text
No instance of type
Govenv.Kernel.Roadmap.ValidRoadmap
(
  (finished ∷ [])
  ++States
  ((active ∷ [])
   ++States
   ((future ∷ [])
    ++States
    ...
  ))
)
was found in scope.
```

This happens because `roadmapOf` expects:

```agda
{{validity : ValidRoadmap states}}
```

but `states` is expressed through unreduced nested `_++States_` applications produced by `_╟_`.

So the immediate technical task is:

> make `ValidRoadmap` inference see the normalized state list, or redesign `_╟_` / `PhaseSequence` so the resulting state index reduces structurally.

Do not weaken the invariant just to make the DSL compile.

Potential directions:

1. redefine sequence concatenation so indices normalize definitionally;
2. make `_╟_` construct the sequence directly rather than append singleton `PhaseSequence`s;
3. avoid typeclass inference here and carry the validity proof structurally in the DSL;
4. encode the allowed phase-state transition directly in a typed builder.

Preserve the user-facing syntax as much as practical.

---

# 6. README insight that changed the architecture

During the roadmap work, we noticed the same issue exists in README governance.

Current architecture had:

```text
Govenv.Readme
  └── governs data

Govenv.Projection.Readme.renderReadme
  └── still decides composition:
      header
      roadmap
      getting started
```

That means `renderReadme` still contains semantic project policy.

User agreed this should move into governed materialization data.

The projection should only serialize.

Target architecture:

```text
Govenv.Materialization.Readme
        ↓
Govenv.Projection.Readme
        ↓
README.md
```

where the materialization defines:

- content;
- structure;
- section order;
- inclusion/exclusion;
- semantic decisions.

Projection defines only Markdown representation details.

---

# 7. New materialization architecture

User proposed and approved the namespace pattern:

```text
.github/workflows/test.yml
  → Govenv.Materialization.Github.Workflows.Test

.gitignore
  → Govenv.Materialization.Gitignore

README.md
  → Govenv.Materialization.Readme
```

This should become the general architecture for all materialized state.

Conceptual model:

```text
Govenv.Materialization.*
        │
        │ canonical semantic authority
        │
        ├── content
        ├── structure
        ├── ordering
        ├── inclusion/exclusion
        └── policy
        ↓
Govenv.Projection.*
        │
        │ target representation only
        ├── Markdown
        ├── YAML
        ├── JSON
        └── plain text
        ↓
Govenv.Adapter.*
        │
        │ effects only
        ├── write
        ├── apply
        ├── read back
        └── verify
```

Key principle:

> No materializer, projection, adapter, workflow, or serializer may invent policy.

---

# 8. Proposed GV51

We agreed this deserves a new governance item rather than silently broadening earlier GVs.

Suggested semantics:

```text
GV51 — Materialization closure

Every state materialized by Govenv must have exactly one canonical
Govenv.Materialization.* definition containing all semantic content,
structure, ordering, inclusion, and policy decisions.

Projection layers may only encode target-format representation.

Adapters may only apply, observe, or verify the projected state.
```

This generalizes / organizes several existing GVs:

```text
GV51  general materialization closure
 │
 ├─ GV16 README materialization
 ├─ GV21 project description projection
 ├─ GV24 CI projection closure
 ├─ GV44 automatic versioned materialization
 └─ GV48 release governance delta
```

Potential future invariant:

```text
materialized targets
        =
declared Govenv.Materialization.* values
```

So if a materialized/tracked file exists without a governed materialization definition, Govenv could eventually report a violation.

---

# 9. Admin materialization belongs in the same model

User asked specifically whether admin should also use `Govenv.Materialization.*`.

Answer: yes.

Do NOT create a separate architecture such as:

```text
Govenv.Admin.Materialization.*
```

Instead, admin is a capability/property of a materialization.

Conceptually:

```agda
data Capability : Set where
  repository
  admin
```

Then a materialization declares its required capability.

Examples:

```text
README.md
→ Govenv.Materialization.Readme
→ capability: repository

GitHub repository description
→ Govenv.Materialization.Github.Repository.Description
→ capability: admin
```

Desired flow:

```text
Govenv.Materialization.*
        │
        ├── target
        ├── governed value
        └── required capability
                     │
                     ▼
Govenv.Projection.*
                     │
                     ▼
Govenv.Adapter.*
        │
        ├── repository → normal CI/materialization
        └── admin      → Admin Materialize
                           ↓
                         readback
                           ↓
                         evidence
```

Important principle:

> The workflow must not decide whether something is admin. The governed materialization declares the required capability.

This fits existing governance:

```text
GV22 — admin path restriction
GV45 — mandatory readback/verification
GV46 — typed evidence
GV51 — canonical materialization authority
```

---

# 10. README migration target

The next materialization refactor should use README as the exemplar.

Instead of:

```agda
renderReadme =
  renderHeader readme ++
  renderRoadmap readme ++
  renderGettingStarted readme
```

the governed value should express the composition itself, approximately:

```agda
module Govenv.Materialization.Readme where

readme =
  document
    ┬ header ...
    ├ roadmapSection roadmap
    ├ gettingStarted ...
```

Then projection becomes conceptually:

```agda
renderReadme : String
renderReadme = renderMarkdown readme
```

The exact DSL is not finalized yet.

---

# 11. GV48 release-delta WIP

GV48 work existed before the roadmap refactor and remains uncommitted.

Known uncommitted files included:

```text
Govenv/Release.lagda.md
src/Govenv/Kernel/Release.agda
src/Govenv/Adapter/release-governance.sh
src/Govenv/Adapter/release-governance-pr.sh
```

The intended release governance delta remains:

```text
■ P1 → ▣ P2
├ ✓ GV45  completed
├ ◇ GV46  ↑ advanced
└ ◇ GV50  + introduced
```

Semantics:

```text
completed
advanced
introduced
```

plus phase progression.

SemVer must remain independent from GV IDs / governance delta.

Do not finish GV48 before stabilizing the roadmap/type model, because the new flat `GovernanceId` / `Identifier` abstraction likely simplifies `ItemImpact`.

---

# 12. Known release adapter logic

`release-governance.sh` had logic to:

- compare previous/current generated README roadmap;
- extract roadmap phase/item state;
- parse `Refs: GV...` from commits;
- classify governance impacts;
- render an idempotent governance-impact section.

Classification direction:

```text
previous ◇ → current ✓
  => completed

absent previously + current ✓ + explicitly referenced
  => completed

current ◇ + referenced
  => advanced

absent previously otherwise
  => introduced
```

This avoided falsely calling all first-formalized historical GVs “completed”.

---

# 13. Last known working-tree state

At session stop, `main` was still at `9217340`.

Known modified files:

```text
Govenv/Readme.lagda.md
Govenv/Release.lagda.md
Govenv/Roadmap.lagda.md
src/Govenv/Kernel/Readme.agda
src/Govenv/Kernel/Release.agda
src/Govenv/Kernel/Roadmap.agda
src/Govenv/Projection/Readme.agda
```

Known untracked files:

```text
TestRoadmap.agda
src/Govenv/Adapter/release-governance-pr.sh
src/Govenv/Adapter/release-governance.sh
src/Govenv/Kernel/Identifier.agda
src/Govenv/Roadmap/DSL.agda
```

Do NOT discard or overwrite these blindly.

`TestRoadmap.agda` is a scratch/minimal parser/type-check test and should be inspected before deletion.

---

# 14. Current architectural priority

Resume in this order:

1. inspect `git status` and diff;
2. preserve all current WIP;
3. fix `ValidRoadmap` / `_++States_` inference without weakening invariants;
4. get `Govenv/Roadmap.lagda.md` compiling in the desired single-tree form;
5. run:
   ```bash
   nix run github:cachix/devenv/v2.3 -- tasks run govenv:materialize
   nix run github:cachix/devenv/v2.3 -- test
   ```
6. validate generated README roadmap;
7. add/adjust GV51 for materialization closure;
8. migrate README to:
   ```text
   Govenv.Materialization.Readme
   ```
9. make projection purely representational;
10. only then revisit GV48 release delta.

---

# 15. Strong constraints to preserve

- Generic reusable kernel under `Govenv.Kernel.*`.
- Project-specific governed values in literate Agda.
- No implementation details in `Govenv/Roadmap.lagda.md`.
- Roadmap should be a single visual tree.
- `PhaseId` and `GovernanceId` share generic `Identifier`.
- `GovernanceId` must NOT encode phase ownership.
- `BelongsTo` is a separate structural relation.
- GV/phase number + description should be both runtime values and type indices.
- Exactly one active phase while roadmap is in progress.
- Projection should not contain policy.
- Adapter should not contain policy.
- Admin is a capability of a materialization, not a separate architecture.
- SemVer remains independent of governance IDs.
- Do not mark roadmap items done until semantic closure is real.
- Stage 0 stays pinned to devenv v2.3 / Agda 2.8.0.

---

# 16. Resume prompt

Use this in the next session:

> Continue the Govenv work from this handoff. First inspect the current working tree and read the relevant WIP files before changing anything. Preserve all uncommitted work. The immediate task is to finish the new single-tree roadmap DSL based on generic `Identifier`, separate `BelongsTo`, and hidden implementation details. The last blocker is `ValidRoadmap` inference over `_++States_`. Once the roadmap materializes/tests cleanly, proceed with GV51 and `Govenv.Materialization.Readme`, keeping projections representation-only and adapters effect-only. Do not prematurely finish GV48.

