# Govenv session handoff — Protocol, AGENTS bootstrap, typed context, LSP-first

Date: 2026-09-22
Repository: `klarkc/govenv`
Working machine: `solo098`
Primary worktree: `/home/klarkc/Sources/klarkc/govenv-history-spike`
Branch: `spike/constitutional-history`
PR: #32
PR URL: https://github.com/klarkc/govenv/pull/32

## 1. Session objective and current state

This session started from review of PR #32, originally a constitutional-history spike and GV1 source-boundary counterexample closure. During semantic review, several architectural refinements were discovered:

1. Experimental code must not live under `Kernel`.
2. Implementation documentation should live in the same `.agda` file as the code.
3. Human-facing normative domains should be literate Agda (`*.lagda.md`).
4. Governance and contributor/agent process guidance are distinct normative domains.
5. The contributor/agent domain was first called `OperationalPolicy`, then renamed to **`Protocol`**.
6. `AGENTS.md` should not be semantic authority; it is an interim materialized projection of `Govenv.Protocol`.
7. Counterexamples should be canonical literate governed evidence under the relevant GV assurance:
   `Govenv/Assurance/GV<n>/Counterexample/*.lagda.md`.
8. Longer-term, `AGENTS.md` should shrink dramatically or disappear once typed context can be resolved and delivered through the LSP.
9. Architecture should drive semantic scoping; the LSP should deliver only relevant typed context near the action boundary.
10. MCP may eventually expose the same typed context, but it is optional and should not be attacked now. The current direction is **LSP-first**.

## 2. Current conceptual architecture

The emerging model is:

```text
Govenv
├── Governance
│   └── constitutional normative authority
│       human-facing + formal
│       *.lagda.md
│
├── Protocol
│   └── contributor/agent procedural normative authority
│       human-facing + formal
│       *.lagda.md
│
├── Architecture
│   └── repository roles, paths, dependency directions
│
├── Assurance
│   ├── assurance boundaries
│   └── GV<n>/Counterexample/*.lagda.md
│
├── Materialization
│   └── canonical versioned/generated artifacts
│
src/Govenv/
├── Kernel/
│   └── established reusable semantic implementation
├── Experiment/
│   └── experimental/candidate semantic implementations
├── Projection/
└── Adapter/
```

The important distinction:

```text
Governance
  → what repository/system states, transitions, effects, and properties are valid

Protocol
  → how contributors and agents should work, investigate, validate, and make decisions

Architecture
  → how repository areas are classified and how roles may depend on each other
```

Protocol is normative but **non-constitutional**. A repository state is not invalid merely because someone reached it through a different valid process.

## 3. Documentation authority rule

The current agreed rule is:

```text
human-facing normative semantic authority
  → *.lagda.md
  → Governance, Protocol, governed evidence/counterexamples

code-first implementation semantic authority
  → *.agda
  → Kernel, Experiment, Projection, Adapter
  → documentation belongs in the same owning .agda source

standalone versioned human artifact
  → governed materialization
```

Therefore:

```text
Foo.agda + README.md                     ✗
Foo.agda with its explanation/comments  ✓

Governance/Foo.lagda.md                 ✓
Protocol.lagda.md                       ✓

handwritten AGENTS.md                   ✗
materialized AGENTS.md                  ✓
```

## 4. Counterexample organization

The user explicitly preferred all counterexamples separated but colocated under the related GV.

Canonical pattern:

```text
Govenv/Assurance/GV1.lagda.md
Govenv/Assurance/GV1/
└── Counterexample/
    └── SourcePlacement.lagda.md
```

General form:

```text
Govenv/Assurance/GV<n>/Counterexample/*.lagda.md
```

A counterexample module should contain:

- human explanation of what happened;
- the observed facts/state;
- why it contradicted the governed/relied-upon property;
- the assurance boundary exposed as missing or insufficient;
- formal proof that recurrence is now rejected.

External fixtures, if literally required by adapters/tests, should not become independent handwritten authority. They should be governed materializations of canonical evidence.

## 5. GV1 source-boundary counterexample

Original problem:

PR #32 had root-level:

```text
spike/ConstitutionalHistory.agda
...
```

Established GV1 says roughly:

> Project governance under `Govenv/`; reusable kernel under `Govenv.Kernel.*`.

A root `spike/` was therefore semantically suspicious and exposed a missing source-boundary assurance.

Implemented:

### `src/Govenv/Kernel/Architecture.agda`

Path-prefix helpers:

- `pathUnderRoot`
- `firstOutsideRoots`

### `Govenv/Architecture.lagda.md`

Governed source roots:

```agda
sourceRoots : List String
sourceRoots =
    "Govenv.lagda.md"
  ∷ "Govenv/"
  ∷ "src/Govenv/"
  ∷ []
```

### `Govenv/Assurance/GV1.lagda.md`

Defines the candidate source-boundary rule.

### Canonical counterexample

Now intended as:

```text
Govenv/Assurance/GV1/Counterexample/SourcePlacement.lagda.md
```

The previous standalone file:

```text
Govenv/Architecture/source-placement-counterexample.md
```

was removed.

Important nuance:
The GV1 source boundary only proves that tracked Agda/literate-Agda source remains inside governed Govenv source roots. It does **not** prove that arbitrary source is semantically classified into the correct architecture role. Therefore GV1 central assurance remains legacy debt; do not overclaim the partial source-boundary assurance as full semantic GV1 discharge.

## 6. Experiment vs Kernel

A major correction in this session:

The constitutional-history spike had been moved under:

```text
src/Govenv/Kernel/ConstitutionalHistorySpike/
```

This was still semantically wrong because an experiment is not established reusable kernel.

It was moved toward:

```text
src/Govenv/Experiment/ConstitutionalHistory/
```

with explicit variants:

```text
src/Govenv/Experiment/ConstitutionalHistory.agda
src/Govenv/Experiment/ConstitutionalHistory/Baseline.agda
src/Govenv/Experiment/ConstitutionalHistory/BaselineScenarios.agda
src/Govenv/Experiment/ConstitutionalHistory/Stdlib.agda
src/Govenv/Experiment/ConstitutionalHistory/StdlibScenarios.agda
src/Govenv/Experiment/ConstitutionalHistory/Propositional.agda
src/Govenv/Experiment/ConstitutionalHistory/PropositionalScenarios.agda
src/Govenv/Experiment/ConstitutionalHistory/EcosystemReuse.agda
```

The root experiment module documents the experiment directly in `.agda`; the old `README.md` under the experiment was removed.

Intended architecture dependency:

```text
Experiment → Kernel   ✓
Kernel → Experiment   ✗
```

## 7. Governance vs Protocol

The domain was initially introduced as `OperationalPolicy`. During PR review the user asked for a non-compound name. `Protocol` was chosen.

The preferred wording:

```text
Govenv.Governance
    → defines what is valid

Govenv.Protocol
    → defines how contributors/agents operate
```

This is better than `OperationalPolicy` because:

- it is single-word;
- still feels normative;
- does not conflate with policy concepts that can themselves be governed;
- expresses procedures/discipline/heuristics well.

Current intended chain:

```text
Govenv.Protocol
      ↓
Govenv.Materialization.Agents
      ↓
Govenv.Projection.Agents
      ↓
Govenv.Adapter.Agents
      ↓
AGENTS.md
```

`AGENTS.md` should begin with something like:

```text
<!-- Generated from Govenv.Protocol. Do not edit manually. -->
```

It is a projection, not an authority.

## 8. Important GV54 discovery while renaming Protocol

GV54 is established:

> Governance identity, definition, and owning phase are immutable once introduced.

During the rename `OperationalPolicy → Protocol`, simply editing GV96/GV97/GV98 in a later commit caused:

```text
Immutable governance definition was changed: GV96
```

from `govenv:materialize`.

Correct response:

Because these GV introductions exist only inside the unmerged PR branch, the branch history must be rewritten so that **Protocol is the original wording at the introduction revision**, rather than creating a later mutation.

The approach used:

1. Capture the rename diff.
2. Reset back to the semantic commit that introduced GV96–GV99.
3. Apply the rename diff there.
4. Amend that semantic commit.
5. Regenerate materializations.

This is important: do not “fix” immutable introduced GVs with later edits inside the same candidate history if the intended name was wrong at introduction. Rewrite the candidate history before merge.

## 9. GVs introduced in this work

The session introduced, conceptually:

### GV96 — versioned artifact authority

Intent:

- handwritten semantic authority is limited to:
  - code-first `.agda`;
  - human-facing normative `.lagda.md`;
- implementation/experiment documentation lives in owning `.agda`;
- Governance, Protocol, and governed evidence keep prose + formalization in literate modules;
- every other versioned artifact must be produced by exactly one governed `Govenv.Materialization.*`;
- transient `.govenv` state is not versioned;
- temporary devenv bootstrap exceptions remain until their migration completes.

GV71 and GV72 were intended to be superseded by GV96 rather than rewritten.

### GV97 — Governance vs Protocol and AGENTS

Intent:

- `Govenv.Governance` and `Govenv.Protocol` are distinct literate normative domains;
- Governance defines constitutional validity;
- Protocol guides contributor/agent process without independently invalidating repository state;
- `AGENTS.md` is materialized exclusively from `Govenv.Protocol`;
- tracked divergence must fail.

### GV98 — expanded architecture roles

Intent:

- architecture includes:
  - closure
  - constitution
  - protocol
  - materialization
  - kernel
  - experiment
  - projection
  - adapter
  - generated
- `Experiment → Kernel`
- `Kernel ↛ Experiment`
- Protocol is distinct from constitutional Governance.

GV62 was intended to be superseded by GV98.

### GV99 — canonical counterexamples

Intent:

- persisted counterexamples live as governed literate evidence under:

```text
Govenv/Assurance/GV<n>/Counterexample/
```

- external fixtures are materializations rather than handwritten authority.

Important: these GVs were still pending (`◇`) in the roadmap, not completed.

## 10. AGENTS.md size constraint proposal

The user proposed a new explicit GV:

```text
AGENTS.md must always be ≤ 10,000 characters.
```

Current materialized AGENTS measured during this session:

```text
bytes ≈ 9632
chars ≈ 9618
```

So the limit is already relevant.

The key semantic nuance agreed:

**Exceeding 10k must NOT itself justify moving arbitrary Protocol into Governance.**

Correct resolution order when the bound is pressured:

1. remove rationale/elaboration from the AGENTS projection while keeping it in `Govenv.Protocol`;
2. remove redundancy / compact genuine protocol;
3. identify statements that are actually contributor-independent state/effect properties and therefore belong in Governance;
4. preserve Protocol semantics without weakening them.

The size limit is a bound on the **AI-facing bootstrap projection**, not an excuse to contaminate Governance.

A candidate GV100 could state roughly:

> While typed Govenv context is not yet supplied directly to supported agent clients, `AGENTS.md` is an interim compatibility/bootstrap materialization of `Govenv.Protocol`, limited to at most 10,000 characters. Exceeding the bound must fail candidate validation. Remediation must preserve semantic classification: rationale may remain only in Protocol, redundant instructions may be compacted, and only contributor-independent state/effect semantics may move to Governance. The size bound alone never justifies promoting Protocol to Governance.

Do not consider this wording final yet; it was only discussed.

## 11. AGENTS.md should become a bootstrap, not the memory

A major conceptual conclusion:

```text
AGENTS.md ≠ the memory
AGENTS.md = interim memory/bootstrap projection
```

Long-term typed memory should live in:

```text
Governance
Architecture
Protocol
Roadmap/Current
Assurance
Counterexamples
```

The AI-facing context should be **resolved on demand**, not permanently stuffed into AGENTS.

## 12. Architecture as semantic scoping index

The user correctly observed that the earlier “relevance/scoping protocol” probably belongs in `Architecture`.

Agreed refinement:

Architecture is the first semantic index answering:

```text
Given this path/module:
  what Role is it?
  what Area owns it?
  what dependency directions are structurally possible?
```

Example:

```text
src/Govenv/Experiment/ConstitutionalHistory/Propositional.agda
        ↓
Architecture
        ↓
Area = src/Govenv/Experiment/
Role = experiment
        ↓
experiment → kernel
```

But Architecture alone is not enough to determine all relevant context.

The missing semantic relation is approximately:

```text
what Governance applies to this subject?
what Protocol applies?
which Assurances apply?
which Counterexamples apply?
```

Potential kernel model:

```agda
data Subject : Set where
  area      : Area → Subject
  role      : Role → Subject
  module    : Module → Subject
  artifact  : Artifact → Subject
  effect    : Effect → Subject
```

Possible relevance relations:

```agda
AppliesTo : Governance → Subject → Set
AppliesTo : Protocol   → Subject → Set
Assures   : Assurance  → Subject → Set
```

Names are not fixed. The main idea is that **scope/relevance should be typed**, not encoded as prose in AGENTS.

## 13. Typed Context resolver

A likely missing abstraction:

```agda
record ContextRequest : Set where
  field
    revision : Revision
    focus    : List Subject
    action   : Action

record Context : Set where
  field
    architecture    : ...
    governance      : ...
    protocol        : ...
    assurances      : ...
    counterexamples : ...
```

and:

```agda
resolveContext :
  ContextRequest →
  Context
```

Important point: context should depend not only on the file but also on the **operation/action**.

Examples:

```text
read Foo.agda
  → maybe light context

edit Foo.agda
  → Architecture
  → applicable Governance
  → applicable Protocol
  → relevant Assurance
  → relevant Counterexamples

git commit
  → commit governance
  → changed scopes
  → governance delta
  → regression/counterexample obligations

publish release
  → release governance
  → authorization
  → materialization/publication assurances
```

So the preferred conceptual key is:

```text
(revision, operation, subjects) → Context
```

not merely:

```text
file → context
```

## 14. LSP-first context delivery

The user clarified that LSP is also for agents because many agents support LSP by default.

Therefore the current direction is:

```text
                    Govenv typed model
                           │
          ┌────────────────┼────────────────┐
          │                │                │
     Architecture      Governance        Protocol
          │                │                │
          └────────┬───────┴───────┬────────┘
                   │               │
              Assurance      Counterexamples
                   \               /
                    \             /
                     Context resolver
                           │
                           ▼
                          LSP
                           │
                    human + agents
```

LSP is a particularly good boundary because it already knows:

```text
workspace
document URI
position/range
symbols
imports
incremental changes
diagnostics
```

A future custom request could be conceptually:

```text
govenv/context
```

with input like:

```text
revision
uri
range/symbol
operation
```

and a typed/projected output containing only relevant:

```text
architecture
governance
protocol
assurance
counterexamples
```

The goal is to inject context at the closest useful semantic boundary **before the agent acts**.

## 15. Existing roadmap already contains much of the future direction

Important existing pending GVs found in the repo:

### GV33

```text
Expose the checker through an LSP/editor loop.
```

### GV34

```text
Expose governance context and diagnostic deltas through an MCP adapter for agent clients.
```

### GV88

Very important. It requires every governable obligation to be enforced at its **earliest sound information boundary**, while keeping `govenv check` authoritative.

GV88 already explicitly calls for:

- construction-time Agda constraints;
- static candidate / incremental / LSP checks;
- commit-boundary checks;
- PR/CI only for information first available there;
- post-effect checks only for irreducible external observation.

This strongly supports the LSP-first context design.

## 16. MCP clarification

The user did not understand why MCP was mentioned and clarified that it is not necessary now.

Agreed position:

```text
Context resolver
    ↓
   LSP   ← primary / current target
```

MCP can later be another adapter:

```text
Context resolver
   ├── LSP   ← primary
   └── MCP   ← optional future adapter
```

Do **not** make MCP part of the critical path now.

GV34 can remain future work.

The semantic authority is not LSP or MCP; both would only expose the same typed `Context`.

## 17. Final vision for AGENTS.md

### Current/interim

Until typed context is delivered automatically to supported agent clients:

```text
Govenv.Protocol
      ↓
Projection/Materialization
      ↓
AGENTS.md
```

AGENTS is a compatibility bootstrap, subject to a strict size bound.

### Transition

```text
Architecture ─┐
Governance ───┤
Protocol ─────┤
Assurance ────┤→ Context resolver → LSP
Counterexample┘

Protocol ─────→ AGENTS.md
                progressively smaller
```

### Final

```text
Architecture ─┐
Governance ───┤
Protocol ─────┤
Assurance ────┤→ Context resolver → LSP → human/agent
Counterexample┘

AGENTS.md
  → tiny compatibility bootstrap
  → or removed entirely if no supported client needs it
```

Possible final tiny AGENTS:

```text
# AGENTS.md

This repository is governed by Govenv.

Use the Govenv language-server context for the scope being inspected or
modified. Governance, protocol, architecture, assurance, and counterexample
context are derived from the repository's typed semantic model.

Do not treat this file as semantic authority.
```

Maybe even this becomes unnecessary if every supported client enters through the LSP.

## 18. Important memory-system insight

A useful conceptual split emerged:

```text
Semantic memory
  → Governance
  → Architecture
  → Roadmap
  → Assurance
  → Counterexamples

Procedural memory
  → Protocol

Working-memory/context projection
  → Context resolver
  → LSP
  → currently AGENTS.md as interim bootstrap
```

This is probably the strongest framing for future Govenv agent support.

The system of types becomes the memory. The LSP selects and projects the relevant slice.

## 19. Current Protocol content

At the time of inspection, `Govenv/Protocol.lagda.md` contained sections corresponding to:

- Protocol vs governance
- Reuse-first engineering policy
- Semantic validation before check trust
- Preserve the Govenv frontend
- Documentation follows semantic authority
- Refactoring authority
- Dependency discipline
- devenv generated state
- Centralized dependency management

Much of this can eventually remain as rich rationale in `Protocol.lagda.md` while AGENTS receives only concise operational instructions.

## 20. PR / branch operational history

PR #32 had been validated earlier with a head around:

```text
36957c1
```

against main:

```text
8af5ae6
```

and GitHub reported `mergeable: true`.

Later, during the `OperationalPolicy → Protocol` rename, the branch history was rewritten to respect GV54.

The last visible semantic amended commit during this session was:

```text
ceff39f gov(architecture): separate normative and experiment domains
```

Then a new materialization commit was created:

```text
474a447 chore(materialize): update governed materializations
```

However, IMPORTANT:

At the exact end of this session, `govenv:check` had been started after this rename/materialization and was still being monitored when the conversation moved into conceptual discussion. Therefore a new session MUST NOT assume the final Protocol rename branch is fully validated/pushed merely from earlier green state.

First actions in the new session should be:

```sh
cd /home/klarkc/Sources/klarkc/govenv-history-spike
git status --short --branch
git log --oneline --decorate --max-count=10
git fetch origin
git rev-parse --short HEAD
git rev-parse --short origin/main
```

Then check whether the last `govenv:check` process completed; if uncertain, rerun:

```sh
nix run github:cachix/devenv/v2.3 -- tasks run govenv:check
```

After green validation:

1. verify `origin/main` is still ancestor;
2. verify merge-tree has no conflict;
3. force-push with lease because history was rewritten;
4. update PR #32 body/head references;
5. confirm GitHub `mergeable: true`.

Do not tell the user the PR is ready until these semantic + mechanical checks are done.

## 21. Materialization behavior

Canonical command:

```sh
nix run github:cachix/devenv/v2.3 -- tasks run govenv:materialize
```

Authoritative full check:

```sh
nix run github:cachix/devenv/v2.3 -- tasks run govenv:check
```

Derived materialization commit format currently used:

```text
chore(materialize): update governed materializations

Derived-From-Parent: true
Refs: GV44 GV51 GV90 GV92 GV93
skip-checks: true
```

When rebase conflicts on `CHANGELOG.md` happen only in the derived materialization commit:

- do not manually merge generated changelog;
- skip the stale derived commit;
- regenerate materializations from rebased semantic history;
- create a fresh derived commit.

## 22. Materialized AGENTS blank-line note

During Protocol rename, generated `AGENTS.md` had an extra blank line at EOF.

The source was adjusted by changing the final `centralizedDependencyManagement` string from ending with double newline to single newline.

The canonical `CHANGELOG.md` intentionally uses trailing two spaces after the Phase line for Markdown hard break. Generic `git diff --check` will flag that; do not manually strip canonical generated hard-breaks. When needed, use diff-check excluding CHANGELOG or understand this is generated behavior.

## 23. Things that should NOT be done

- Do not put experiments back under `Kernel`.
- Do not add standalone handwritten README/doc files under implementation roots.
- Do not make `AGENTS.md` semantic authority.
- Do not treat `AGENTS.md > 10k` as permission to arbitrarily move Protocol into Governance.
- Do not make MCP mandatory now.
- Do not duplicate semantic context separately in LSP and other adapters; the typed `Context` resolver should own it.
- Do not let LSP independently redefine governance semantics. It is an anticipatory adapter/boundary.
- Do not claim a partial assurance fully discharges an established GV unless it actually does.
- Do not mutate an introduced GV definition in a later commit; GV54 rejects it. Rewrite unmerged candidate history when correcting the initial definition.
- Do not rely only on green automated checks; semantically compare candidate changes against established governance.
- Do not consider a PR ready if `main` advanced after validation; rebase/rematerialize/recheck.

## 24. Best next discussion

The next clean session should likely continue conceptually before implementing a large new subsystem.

Recommended next question:

> What is the minimum typed model needed to derive `Context` from `Architecture + operation + subjects`, while reusing GV33/GV88 and without prematurely implementing the final LSP?

Likely sequence:

1. Define what a `Subject` is globally.
2. Define how Architecture maps paths/modules to Subjects/roles.
3. Define how Governance/Protocol/Assurance relate to Subjects.
4. Define `Action` / operation semantics.
5. Define `ContextRequest`.
6. Define `Context`.
7. Prove/decide relevance deterministically.
8. Project Context for LSP.
9. Keep `AGENTS.md` as interim bootstrap with ≤10k constraint.
10. Later shrink AGENTS as LSP context becomes available.

A separate question should determine whether the new AGENTS ≤10k rule is GV100 or whether numbering changed after any concurrent main work.

## 25. User preferences / design style for continuation

The user:

- values semantic rigor;
- catches conceptual inconsistencies quickly;
- prefers repository inspection before implementation;
- wants Agda invariants near compile time;
- prefers earliest sound enforcement;
- wants LSP used not only for humans but also for AI agents;
- does not want unnecessary MCP work now;
- likes canonical typed ownership and generated projections;
- dislikes special-case files;
- wants `*.lagda.md` for normative human-facing semantics;
- wants implementation documentation colocated in the code;
- wants all canonical counterexamples separated in per-GV `Counterexample/` directories;
- prefers a minimal/temporary AGENTS rather than allowing it to become a permanent giant instruction dump;
- wants to know when a PR is **really** ready, not merely when CI is green.

