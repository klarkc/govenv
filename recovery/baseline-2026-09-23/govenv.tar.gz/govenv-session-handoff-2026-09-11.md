# Govenv session handoff — 2026-09-11

## Purpose

This file compacts the current Govenv session so work can continue in a new ChatGPT session without losing architectural decisions, workflow constraints, release state, or unfinished work.

---

## Repository / workflow context

Repository:

- `klarkc/govenv`
- local repo previously used: `/home/klarkc/Sources/klarkc/govenv`
- Desktop Commander was previously connected to device `solo098`
- current session could not use the local checkout, so GV83 work was done on a GitHub branch/PR instead
- local Assurance WIP must remain isolated from release/projection work

### Hard workflow rules

- **Never create/publish a release without explicit user approval**, except when the user themselves merges the Release Please PR and thereby intentionally starts the normal automated Release Please flow.
- Do not manually create an alternate tag/release when Release Please is expected to do it.
- Do not manually edit a Release Please release PR. Push governed source to `main`; CI/Release Please/materialization should update generated artifacts.
- Never mark a GV `✓` by editorial roadmap change alone. Completion must be backed by governed evidence.
- No `amended` state. Any correction, including wording/orthography, requires a newer GV plus supersession.
- Removal of committed governance identities is forbidden. Obsolete without replacement = cancelled.
- Persistent `✓` invariant remains in force.
- **Never modify GV71 wording.**

### Architecture boundaries

- Materialization/domain owns semantics, structure, ordering, policy, and capability decisions.
- Projection owns target-format representation only.
- Adapter owns irreducible effects, observation, and read-back.
- Never parse `CHANGELOG.md` back into governance semantics.
- `CHANGELOG.md` is canonical portable Markdown for typed release content.
- Release Please PR + published GitHub Release use the richer GitHub projection of the same typed release document.
- GitHub-only HTML/MathJax belongs only in the enriched renderer.

---

## Release architecture already established

The release architecture was implemented before this session in commits including:

- `1664c89 gov(release): separate canonical and GitHub projections`
- `78923b0 chore(materialize): update governed materializations`
- `d18a4a3 gov(release): decouple canonical changelog target`

The typed release governance document currently has three targets:

1. `CHANGELOG.md`
   - canonical versioned portable materialization
   - repository-file section
   - standard Markdown

2. Release Please PR body
   - enriched GitHub projection
   - same typed semantic document

3. Published GitHub Release body
   - starts from carried portable changelog section
   - replaces that marker section in place with enriched GitHub projection
   - verifies the external GitHub Release section by read-back equality

Relevant target model:

```agda
data RepositoryFileSection : Set where
  releaseGovernanceImpactInChangelog : RepositoryFileSection

data RepositoryFileSectionPlacement : Set where
  afterReleaseHeadingInFile : RepositoryFileSectionPlacement

data GithubPullRequestSection : Set where
  releaseGovernanceImpact : GithubPullRequestSection

data GithubReleaseSection : Set where
  releaseGovernanceImpactInRelease : GithubReleaseSection

data GithubPullRequestBodyPlacement : Set where
  afterReleaseHeadingInBody : GithubPullRequestBodyPlacement

data GithubReleaseBodyPlacement : Set where
  replaceCarriedChangelogSection : GithubReleaseBodyPlacement
```

The final GitHub Release adapter:

- reads existing release body
- requires the governance marker to already exist
- replaces the marker section in place
- runs `gh release edit`
- reads back the section
- compares exact equality
- does not invent placement independently

---

## Rich release rendering decisions

Approved GitHub visual style:

```markdown
<div align="center">

| **GV14 ↪ GV60** |
| :---: |
| $`{\color{red}\mathtt{-}}`$ ... |
| $`{\color{green}\mathtt{+}}`$ ... |

</div>
```

General rich layout:

```markdown
### Governance impact

**Phase:** ...
**Items:** ...

#### Introduced · N

| GV | Proposition |
| :---: | --- |

#### Superseded · N

<div align="center">
...
</div>
```

Important rendering constraints:

- no `<details>`
- cards centered with `<div align="center">`
- no fragile width tricks
- removed spans red, added spans green
- portable changelog must remain pure portable Markdown
- portable supersession proposition changes use `diff` fences
- GitHub PR body acts as preview of the final GitHub Release projection

---

## Governance items relevant to release work

### GV75

```text
GV 75 "Render release governance item changes as compact semantic diffs: remove redundant per-item progress labels, align before/after propositions for supersessions, visually distinguish only changed spans, and deterministically wrap or elide common context while preserving the full typed governance delta." ◇
```

### GV76

```text
GV 76 "Make governance references in Git-derived projections revision-aware and navigable: linked identities, lifecycle states and operators, transitions, and elisions must resolve to documentation derived from the immutable Git revision or delta they represent; before-state references use the base revision and after-state references use the candidate or head revision." ◇
```

### GV77

```text
GV 77 "Make `CHANGELOG.md` the canonical versioned portable materialization of each typed release entry, while the Release Please pull request and published GitHub Release project the same typed release content through a shared enriched GitHub renderer; external GitHub Release application must be verified by read-back equality." ◇
```

These remain pending unless governed evidence explicitly establishes them.

### GV71 — NEVER MODIFY

```text
GV 71 "Restrict handwritten versioned repository content to Agda and Markdown only. Any generated or governed materialization may use its required target format. Until GV38 is completed, the only handwritten bootstrap escape hatch is root-level `devenv.nix`, `devenv.yaml`, and `devenv.lock`; all other implementation languages and handwritten configuration formats, including Nix elsewhere, are forbidden." ◇
```

### GV72

```text
GV 72 "Require every versioned repository artifact not permitted as handwritten source by GV71, except the temporary root-level `devenv.nix`, `devenv.yaml`, and `devenv.lock` bootstrap escape hatch, to be produced by exactly one governed `Govenv.Materialization.*` definition and verified against its materialized state; transient `.govenv` state is forbidden from being versioned." ◇
```

### GV73

```text
GV 73 "Require every persisted supporting artifact, including snapshots, fixtures, baselines, schemas, test vectors, and evidence, to be colocated with the module that semantically owns it; catch-all artifact directories are forbidden unless the artifact is genuinely project-global." ◇
```

### GV74

```text
GV 74 "Make governance completion evidence-bearing and persistent: a governance item may transition to `done` only when governed evidence establishes its proposition for the candidate repository state, and every non-superseded `done` item, including items completed before this rule, must remain satisfied in every subsequent valid repository state." ◇
```

### Supersession chains already established

```text
47→68
49→69
9→57
10→58
11→59
17→61→62
14→60
23→63
48→70
7→55
8→56
25→64
27→65
28→66
40→67
```

---

## Assurance WIP — keep separate

Prior local working tree had unfinished Assurance work:

```text
 M src/Govenv/Kernel/Assurance.agda
?? Govenv/Assurance/GV60.lagda.md
```

Important:

- do not accidentally stage/commit those files with release work
- `src/Govenv/Kernel/Assurance.agda` contains unfinished `establishObserved`
- `Govenv/Assurance/GV60.lagda.md` is incomplete/unregistered
- do not register GV60 checked completion yet

Historical inherited completions currently enumerated:

```text
GV0 GV1 GV2 GV19 GV22 GV44 GV45 GV51 GV60
```

`migrationComplete assurances ≡ false`.

GV74 therefore remains pending until inherited completion migration and candidate validation are complete.

---

## Release 0.2.0 state from earlier in the session

The user personally merged Release Please PR #2:

- PR: `chore(main): release 0.2.0`
- merged by user
- merge commit:
  `0e03a8cfe4c4c89f83f390346e9ff26b0d5389fc`
- merged at:
  `2026-09-11T12:03:50Z`

Observed workflow chain after merge:

```text
merge PR #2
→ Materialize
→ Release workflow
→ Release Please
→ create v0.2.0
→ Materialize published release governance
```

At the time of the earlier check, Release Please had not yet reached its release-creation step. The architecture intentionally makes Release wait for Materialize.

Do not manually create a competing `v0.2.0`; diagnose the automated flow first if needed.

---

# Current session work: GV83 sparse supersession projection

## Problem being solved

The previous supersession rendering showed a neutral text such as:

```text
proposition unchanged
```

for cases such as `GV40 ↪ GV67`.

The desired semantics are now **sparse**:

- if phase changed but proposition did not: show only phase transition
- if proposition changed but phase did not: show only proposition diff
- if both changed: show both
- unchanged dimensions are implicit and are not rendered

The key architectural requirement is that Projection must not independently decide what semantically changed.

## Working branch / PR

Branch:

```text
gov/gv83-sparse-delta-projection
```

PR:

```text
#4 — gov(release): render sparse governance deltas
https://github.com/klarkc/govenv/pull/4
```

Current PR state at end of session:

- open
- draft
- mergeable
- not merged
- changed files: 3
- latest important head:
  `def28bb898870b8232a7d96c6f77705f35b61593`

Do **not** merge until user explicitly approves.

## Files changed in PR #4

```text
Govenv/Materialization/ReleaseGovernance.lagda.md
Govenv/Release.lagda.md
src/Govenv/Projection/ReleaseGovernance.agda
```

## Core design implemented

`Govenv.Materialization.ReleaseGovernance` now owns the semantic classification:

```agda
record PhaseChange : Set where
  constructor phaseChange
  field
    previousPhase : SomePhaseId
    currentPhase : SomePhaseId

record PropositionChange : Set where
  constructor propositionChange
  field
    previousProposition : String
    currentProposition : String

data SupersessionDelta : Set where
  resolvedSupersession :
    SomeGovernanceId →
    SomeGovernanceId →
    Maybe PhaseChange →
    Maybe PropositionChange →
    SupersessionDelta

  unresolvedSupersession :
    SomeGovernanceId →
    GovernanceRef →
    SupersessionDelta
```

`ReleaseDocument` carries:

```agda
supersessions : List SupersessionDelta
```

The Materialization layer:

- resolves supersession target
- determines previous/current owning phase
- compares phase identity
- compares proposition text
- converts unchanged dimensions to `nothing`
- produces typed `SupersessionDelta`

A subsequent refactor removed raw `roadmap : Roadmap` from `ReleaseDocument`, so Projection cannot recompute this semantic classification.

Latest architecture commit:

```text
def28bb8 refactor(release): close projection over typed delta

Refs: GV51 GV83
```

This is important: it better enforces GV51 because Projection receives already-classified semantic delta rather than raw roadmap data.

## Projection behavior now

GitHub phase rendering:

```agda
renderGithubPhaseChange : Maybe PhaseChange → String
renderGithubPhaseChange nothing = ""
renderGithubPhaseChange (just (phaseChange previous current)) =
  "| **Phase:** " ++ renderPhaseId previous ++ " → " ++ renderPhaseId current ++ " |\n"
```

GitHub proposition rendering:

```agda
renderGithubPropositionChange : Maybe PropositionChange → String
renderGithubPropositionChange nothing = ""
renderGithubPropositionChange
  (just (propositionChange previous current)) =
    "| " ++ renderDiffRow removed oldSide spans ++ " |\n" ++
    "| " ++ renderDiffRow added newSide spans ++ " |\n"
```

Portable changelog phase rendering:

```agda
renderPortablePhaseChange : Maybe PhaseChange → String
renderPortablePhaseChange nothing = ""
renderPortablePhaseChange (just (phaseChange previous current)) =
  "**Phase:** " ++ renderPhaseId previous ++ " → " ++ renderPhaseId current ++ "\n\n"
```

Portable proposition rendering:

```agda
renderPortablePropositionChange : Maybe PropositionChange → String
renderPortablePropositionChange nothing = ""
renderPortablePropositionChange
  (just (propositionChange previous current)) =
    "```diff\n- " ++ previous ++ "\n+ " ++ current ++ "\n```\n\n"
```

Therefore the renderer has no `"proposition unchanged"` path anymore.

## Expected `GV40 ↪ GV67` result

Rich GitHub projection:

```markdown
<div align="center">

| **GV40 ↪ GV67** |
| :---: |
| **Phase:** P6 → P5 |

</div>
```

Portable `CHANGELOG.md` projection:

```markdown
##### GV40 ↪ GV67

**Phase:** P6 → P5
```

Interpretation:

- supersession identity gives the context
- phase ownership changed
- proposition is implicitly unchanged because there is no proposition delta

This preview was placed directly in PR #4 body for visual inspection.

## Documentation updated

`Govenv/Release.lagda.md` was updated so the documented behavior matches the new sparse semantics. It should no longer imply that every supersession always renders aligned proposition text.

---

## CI / review status for PR #4

Latest relevant CI run:

```text
Test #80
run id: 34612506699
head: def28bb898870b8232a7d96c6f77705f35b61593
```

Final result:

```text
completed
success
```

Every observed step completed successfully:

```text
Set up job                         success
Checkout                           success
Install Nix                        success
Cache Nix                          success
Materialize constitution           success
Verify committed materializations success
Run tests                          success
Post Cache Nix                     success
Post Install Nix                   success
Post Checkout                      success
Complete job                       success
```

So for this PR we can truthfully say CI completed full materialization verification and tests successfully.

### CodeRabbit

A manual CodeRabbit review was requested because the PR is draft.

At the final session check:

- review processing had started
- no review threads were present yet
- no actionable findings had yet been returned

Before merging, check CodeRabbit one more time.

---

## What to do next in the new session

Recommended order:

1. Open/check PR #4.
2. Re-check CodeRabbit review result and any inline threads.
3. Review the `GV40 ↪ GV67` preview visually with the user.
4. If the user approves:
   - optionally move PR out of draft if desired
   - merge only with explicit user authorization
5. After merge:
   - observe Materialize/Test/Release Please flows rather than bypassing them
   - do not mark GV83 `✓` merely because implementation merged
   - completion requires governed evidence under the project’s assurance model
6. Keep Assurance local WIP entirely separate.

---

## Important conceptual conclusion from this session

The chosen model for GV83 is:

```text
semantic source
    ↓
Materialization.ReleaseGovernance
    classifies phase/proposition changes
    ↓
SupersessionDelta
    Maybe PhaseChange
    Maybe PropositionChange
    ↓
Projection
    renders only present dimensions
```

This is preferable to:

```text
Projection
    receives raw roadmap
    compares semantics itself
```

because the latter violates the project boundary that Projection represents already-decided semantics rather than deciding them.

---

## Do not forget

- PR #4 is still draft and unmerged.
- Latest tested head is `def28bb8`.
- CI Test #80 passed completely.
- `GV40 ↪ GV67` should show only `Phase: P6 → P5`.
- No `proposition unchanged`.
- Do not mark GV83 done without evidence.
- Do not touch GV71 wording.
- Preserve separate Assurance WIP.
- No release/merge actions without user approval where approval is required.
