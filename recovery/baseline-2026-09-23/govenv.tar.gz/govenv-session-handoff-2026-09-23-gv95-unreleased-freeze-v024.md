# Govenv session handoff — GV95 exact Unreleased freeze and v0.2.4 publication

Date: 2026-09-23  
Repository: `klarkc/govenv`

## Critical operational rule

Never merge a PR or publish a GitHub Release without explicit user approval.  
The user performs final merges/releases.

---

## Project direction

Govenv is governance-as-code using Agda + Nix/devenv + generated GitHub automation.

Core model:

`Invariant → Obligation → Materialization → Evidence → Assurance`

Key principles already established:

- Govenv owns semantics; adapters only observe/apply/verify effects.
- Constitutional GVs are cumulative and immutable.
- Human authorization originates only from exact repository state accepted by explicit human PR merge.
- Derived materialization commits create no independent semantic authority.
- Release Please determines SemVer / Conventional Commit analysis / candidate-tag-release lifecycle.
- Govenv is sole semantic owner of canonical changelog/release document.
- PR-only authorization and capability scoping are fundamental.
- GV84 requires observed invariant regressions to become preserved counterexamples, with repaired assurance boundary and recurrence rejection.
- GV90 models `AuthorizedRevision` and derived causal provenance.
- GV95 governs canonical changelog/release lifecycle.

---

# GV95 contract

Current GV95 proposition:

> Make Govenv the sole semantic owner of the canonical changelog: derive the governed `Unreleased` state deterministically from the latest published release boundary to the current authorized revision, preserve every historical release entry immutably and reconstructibly, freeze that exact governed state into the Release Please candidate version before human approval, and preserve the approved freeze unchanged across the merge-to-publication boundary. Release Please may determine SemVer, analyze Conventional Commits, and coordinate the candidate/tag/release lifecycle, but its rendered notes are observational input rather than independent changelog authority; the pull-request body and published GitHub Release must project the same authorized typed release document and external publication must be verified by read-back equality.

GV77 was superseded by GV95.

---

# Regression discovered in this session

The user noticed that semantic commit:

`c41881fb5fcb8cb3eef5ea945ca7eeb8be67cdc6`

with message:

`fix(release): require verified publication boundary`

never appeared as a release-note entry in `## [Unreleased]`.

At canonical commit:

`5983ff63b9279919a4e9b2fec655c7f2acdeeaaa`

the `Unreleased` section only contained the governance impact/range:

`e76acb1..c41881f`

but did **not** list:

`fix(release): require verified publication boundary`

That release-note entry appeared only later when Release Please created/froze the 0.2.3 candidate.

## Root cause

The implementation treated:

- `Unreleased` = governance document only
- `frozenCandidate` = governance document + release notes

The type encoded that interpretation:

```agda
data ChangelogCurrent : Set where
  emptyUnreleased : ChangelogCurrent
  unreleased :
    ReleaseDocument →
    ChangelogCurrent

  frozenCandidate :
    CandidateBoundary →
    ReleaseDocument →
    String →
    ChangelogCurrent
```

The extra `String` was candidate-only release notes.

The shell also explicitly discarded notes for Unreleased:

```bash
if [[ "${release_version}" == "Unreleased" ]]; then
  release_heading="## [Unreleased]"
  release_notes=""
fi
```

## Classification

This was judged primarily as an **implementation/interpretation regression of GV95**, not a defect in the GV95 contract.

The decisive contract phrase is:

`freeze that exact governed state`

The correct lifecycle should be:

```text
canonical Unreleased
  - governance impact
  - canonical conventional release notes
          |
          | freeze
          v
candidate
  - exact same payload
  - only candidate/version metadata added
```

not:

```text
Unreleased
  - governance only
          |
          v
candidate
  - governance
  - NEW release-note content
```

This regression is closed under GV84 + GV95, without superseding GV95.

---

# PR #25 — fix/release: freeze exact Unreleased notes

PR:

`#25 — fix(release): freeze exact Unreleased notes`

Branch originally:

`fix/gv95-unreleased-notes`

Original semantic commit before merge:

`2a9a761a5045c65e0da37442bfc8721cc74a689b`

Original derived commit before merge:

`db6e61d1239471c555a1077ae368c825ef49b275`

## Structural changes

The fix was deliberately stronger than a shell patch.

### 1. Shared typed release entry

`Unreleased` and `frozenCandidate` now share the same typed `ReleaseEntry`.

Conceptually:

```agda
ReleaseEntry
  = governance document
  + typed release notes

unreleased :
  ReleaseEntry →
  ChangelogCurrent

frozenCandidate :
  CandidateBoundary →
  ReleaseEntry →
  ChangelogCurrent
```

The candidate no longer has a structurally separate notes payload.

### 2. Adapter only observes facts

Shell/adapters observe Conventional Commit facts such as:

- type
- scope
- description
- SHA
- whether commit is derived

Agda owns:

- inclusion/exclusion
- grouping
- ordering
- section labels
- URL construction
- derived commit exclusion

This aligns with GV51/GV59.

### 3. Derived materializations excluded

Commits carrying:

`Derived-From-Parent: true`

are excluded from canonical current release-note content according to GV90, because including the materialization commit that writes the changelog would create a self-reference problem and would incorrectly treat derived state as fresh semantic content.

### 4. Release Please becomes observational

Release Please may still analyze Conventional Commits and initially render its own candidate notes, but Govenv rewrites the candidate PR to the canonical release entry.

Release Please does not become independent changelog authority.

### 5. Full candidate/release projection

The Release Please PR and published GitHub Release project/read-back the complete canonical release entry, not just the governance-impact block.

### 6. Persistent historical counterexample

A regression fixture/counterexample was added for the exact historical problem:

`v0.2.2 .. c41881f`

It verifies:

- `c41881f` exists in `Unreleased`;
- derived `chore(materialize)` entries do not appear in canonical current notes;
- `Unreleased` payload and frozen 0.2.3 payload are byte-identical after stripping only candidate-specific metadata.

---

# End-to-end proof before PR #25 merge

After semantic commit:

`2a9a761a5045c65e0da37442bfc8721cc74a689b`

and before any candidate existed, materialization produced:

```markdown
## [Unreleased]

### Bug Fixes

* **release:** freeze exact Unreleased notes ([2a9a761](...))
```

This was the first practical proof that semantic commits now appear in canonical `Unreleased` before candidate creation.

Validation passed:

- shell syntax checks
- `govenv:check`
- `govenv:materialize` → `govenv:check`
- `devenv test`

---

# PR #25 merge result

User merged #25.

Rebase rewrote the semantic commit to:

`034324bdfcc3af0d698121a266e31f5279b71510`

The derived PR commit became:

`85e2cf16be8fcbefacbfd806897b43b8e7c29e9c`

Because the generated changelog still referenced pre-rebase SHA `2a9a761`, the automatic materializer reconciled it with one derived commit:

`74f088141ae9cdbbafd6200a85d8774d33f83e38`

That materialization changed only `CHANGELOG.md`, replacing:

`2a9a761` → `034324b`

both in release-note link and governance range.

A reproduction against the exact post-rebase main independently passed `govenv:check`.

## Materialize #56

Run:

`35234327451`

Head:

`74f088141ae9cdbbafd6200a85d8774d33f83e38`

Result:

**success**

Important details:

- materialize: success
- commit derived materializations: **skipped**
- therefore zero drift
- test: success
- pages build/deploy: success
- release workflow: success
- candidate-test: success
- post-release-materialize: success
- release-reconcile: skipped

---

# PR #26 — release 0.2.4 candidate

Release Please created:

`#26 — chore(main): release 0.2.4`

Initial candidate raw body from Release Please included:

### Bug Fixes

- semantic fix `034324b`

### Miscellaneous

- derived `74f0881`
- derived `85e2cf1`

This raw Release Please output was intentionally only an **observation**.

The governed `Materialize release governance` step rewrote PR #26 so that the canonical candidate contained:

- governance impact
- only the semantic `fix(release)` note

and removed the derived `Miscellaneous` entries.

Candidate head after governed rewrite:

`a2c9d6702324b581fd433a3869b0e3888a77aea3`

The candidate contains:

```markdown
## [0.2.4](https://github.com/klarkc/govenv/compare/v0.2.3...v0.2.4) (2026-09-17)
<!-- govenv-release-freeze: version=0.2.4 base=v0.2.3 authorized=034324bdfcc3af0d698121a266e31f5279b71510 -->
```

and:

```markdown
### Bug Fixes

* **release:** freeze exact Unreleased notes ([034324b](...))
```

No current derived materialization commits remained in candidate notes.

## Exact payload proof

The canonical `Unreleased` payload at:

`74f088141ae9cdbbafd6200a85d8774d33f83e38`

was compared byte-for-byte with the frozen 0.2.4 candidate payload at:

`a2c9d6702324b581fd433a3869b0e3888a77aea3`

after removing only candidate-specific metadata.

Result:

`PAYLOAD_EQUAL`

Both SHA256:

`b4d0b92d50a268aaca40b35851a7f72a4762c5f09c3eb645fd27efd3e51c2c21`

Thus the candidate became a true exact freeze of canonical `Unreleased`.

## Candidate-test

The reusable candidate test explicitly checked out:

`a2c9d6702324b581fd433a3869b0e3888a77aea3`

and passed:

- `govenv:check`
- `devenv test`

This proved the exact frozen candidate revision.

User was told PR #26 was ready, and then merged it.

---

# PR #26 merge — current state where this session stopped

User said `merged`.

GitHub confirms:

- PR #26 closed
- merged = true
- merged_at: `2026-09-17T18:02:46Z`

The merge used rebase semantics.

## Final rebased commits on main

First release commit:

`4a848a08e572a2db6eef2f4c7c5ba8ef976a5e93`

message:

`chore(main): release 0.2.4`

It changes only:

`.github/release-please/manifest.json`

from:

`0.2.3` → `0.2.4`

Parent:

`74f088141ae9cdbbafd6200a85d8774d33f83e38`

Second/final freeze commit:

`f8202bcf9ef85b40257f6562d1af76eaec94ef64`

message:

`chore(materialize): freeze canonical release changelog`

Parent:

`4a848a08e572a2db6eef2f4c7c5ba8ef976a5e93`

At the point this session stopped, `main` was exactly:

`f8202bcf9ef85b40257f6562d1af76eaec94ef64`

## Strong preservation proof already observed

Candidate approved commit:

`a2c9d6702324b581fd433a3869b0e3888a77aea3`

and merged/final main commit:

`f8202bcf9ef85b40257f6562d1af76eaec94ef64`

have the **same tree SHA**:

`ec5c8a87249353a9aeb5f438f5b95e7d8375c220`

This means rebase changed commit identity but preserved the entire repository state byte-for-byte.

That directly supports the GV95 requirement:

`preserve the approved freeze unchanged across the merge-to-publication boundary`

The freeze commit patch only adds the 0.2.4 heading/marker over the previous `Unreleased` payload.

---

# Materialize #57 — currently in progress when session was compacted

Run:

`35256420319`

Run number:

`57`

Head:

`f8202bcf9ef85b40257f6562d1af76eaec94ef64`

Event:

`push`

Status at last observation:

`in_progress`

Latest observed job:

`materialize`

Progress seen:

- Set up job ✅
- Checkout authorized revision ✅
- Install Nix ✅
- Cache Nix ✅
- Materialize constitution: **in progress**
- later steps not yet observed in this session

At the last check, the `v0.2.4` tag did **not yet exist** (`refs/tags/v0.2.4` returned 404), which is expected because the release workflow had not yet reached publication.

---

# What must be validated next

Resume from Materialize run #57:

`https://github.com/klarkc/govenv/actions/runs/35256420319`

Need verify all of:

1. Initial materialize on `f8202bc...`
   - ideally zero drift
   - if a derived reconciliation commit appears, inspect exactly why

2. Test workflow green on exact effective revision

3. Release Please publication of `v0.2.4`

4. Tag target
   - verify `refs/tags/v0.2.4`
   - expected important property:
     the tag should point to the approved frozen merged state, not a later unrelated derived semantic state

5. GitHub Release
   - published
   - body exactly equal to governed 0.2.4 release entry
   - no derived `Miscellaneous` notes from 74f0881 / 85e2cf1
   - read-back equality step green
   - ideally immutable=true as prior releases

6. `post-release-materialize`
   - should run only after reusable Release success (fail-closed GV95 guard)
   - detect boundary `v0.2.3 → v0.2.4`
   - determine whether publication requires any byte changes
   - based on previous 0.2.3 behavior, likely zero post-release drift because frozen bytes can become historical purely by tag existence

7. `release-reconcile`
   - expected skipped if no post-release derived commit

8. Final canonical `main`
   - capture exact SHA
   - compare `CHANGELOG.md` / tree to approved freeze
   - verify 0.2.4 is now immutable history and `Unreleased` is empty

---

# Historical release context

## v0.2.2

Tag:

`v0.2.2`

points exactly to:

`e76acb119c6514e93ef90312f1c956f308a42a42`

Release ID:

`390308298`

Important fixes around 0.2.2:

- PR #17 causal provenance rebase-stable
- PR #18 Pages full history
- PR #19 read-only frozen candidate validation
- PR #20 exact reusable revision checkout
- PR #21 temp-file/atomic post-merge freeze materialization
- PR #23 post-publication convergence
- PR #24 fail-closed verified publication boundary

## v0.2.3

Tag:

`v0.2.3`

points exactly to:

`8728e3d939183290fbc9713eb9dbb1f581a99035`

Release ID:

`390729719`

Main and tag were identical at publication.

Post-release boundary advancement produced **zero drift**.

This showed the semantic state can transition:

`frozenCandidate → historical release`

because of tag existence without changing canonical bytes.

---

# Remaining robustness concerns from earlier sessions

These are not blockers for #25/#26 but remain useful architectural notes.

## 1. Latent concurrency case

If a future `post-release-materialize` actually creates a derived commit:

- Materialize uses `cancel-in-progress: true`
- derived SSH push empirically triggers another Materialize even with `skip-checks: true`

This could cancel the parent run before `release-reconcile`.

Normal 0.2.3 publication had zero post-release drift, so this branch was not empirically exercised.

## 2. Latest-tag detection

Some logic appeared to use:

`git describe --tags --abbrev=0`

Future arbitrary non-release tags could confuse boundary selection.

Potential robustness improvement:

- filter SemVer/release tags
- or reuse exact release-boundary logic everywhere

Not a current blocker.

## 3. Magic Nix Cache delays

Several runs had long `Post Cache Nix` periods and occasional GitHub cache rate limiting.

Functional checks still passed.

Treat as infrastructure behavior unless it affects workflow correctness.

---

# Conceptual thread to resume after release work

The broader governance model discussion was heading toward:

`Proposition → Obligation → Disposition`

Important agreed direction:

- `Obligation` may inherently mean established; avoid redundant established status.
- `pending` likely belongs to Proposition/evidence lifecycle rather than obligation establishment.
- `Proposition` is a claim/intent that can move between GVs through disposition.
- Governance lifecycle should be separated from obligation lineage/evidence.
- Supersession is explicit typed lineage, not arbitrary dependency.
- New GV can supersede old at a later effective point.
- Old GVs are never mutated/deleted.
- IDs should use constructors like `GV n`, `P n`, etc., not constructor-per-number.
- The `String` in `Nat -> String -> Set` is the human-readable contract between developer and AI; agent writes summary, human/other agent verifies it matches propositions.
- Roadmap rendering should place status first and aligned, e.g.:
  `status GV10: contract`
- Changelog and GitHub Release project the same governed release document.
- Avoid HTML-specific changelog semantics where portability matters.

Relevant old handoffs:

- `govenv-session-handoff-2026-09-16-proposition-supersession-roadmap-delta(1).md`
- `govenv-session-handoff-2026-09-16-proposition-obligation-disposition(1).md`

---

# Suggested first action in next session

1. Inspect Materialize run #57 (`35256420319`)
2. Validate `v0.2.4` tag/release/read-back/post-release convergence
3. Record final SHAs
4. If everything passes, consider GV95 regression fully closed in production
5. Then return to Proposition/Obligation/Disposition modeling
