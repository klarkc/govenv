# Govenv — Session Handoff
**Date:** 2026-09-14  
**Repository:** `klarkc/govenv`

## 1. Current repository state

Remote `main` is currently:

```text
346aee0928d29bb385c7fc37c21eacc2e34b9259
fix(authorization): support private materializer app
```

The Stage A.1 PR was merged:

- PR #7 — `fix(authorization): support private materializer app`
- merged into `main`
- merge SHA: `346aee0928d29bb385c7fc37c21eacc2e34b9259`
- 2 files changed
- it added the governed `GOVENV_MATERIALIZER_CLIENT_ID` environment variable alongside `GOVENV_MATERIALIZER_PRIVATE_KEY`.

The canonical Release Please PR remains open:

- PR #3 — `chore(main): release 0.2.1`
- **do not merge yet**
- Release Please should remain the only release mechanism.
- Do not manually create tags/releases or edit the Release Please PR body.

## 2. Stage A / bootstrap execution status

Stage A itself was previously completed successfully:

- Admin Materialize run #5
- run id: `34851815045`
- commit: `6e35290ae3219d4f36d414a7a368416e2fbeda32`
- target: `admin-environment`
- result: success
- `admin-materialization` was self-hardened and read-back verified.

The current `admin-materialization` boundary therefore exists and is main-only.

### Stage A.1 bootstrap attempt

After PR #7 was merged, Admin Materialize was dispatched with:

```text
target = materializer-environment
```

Run:

- Admin Materialize #6
- run id: `34855448607`
- commit: `346aee0928d29bb385c7fc37c21eacc2e34b9259`

Observed result:

- repository check: success
- admin adapters build: success
- `Apply and verify target`: failure
- evidence step skipped

External state was independently checked and showed:

```text
environment: authorized-materialization
branch policy: main only
secrets: []
variables: []
```

This was the expected partial bootstrap under the then-current design.

However, **do not continue this bootstrap**. We subsequently changed the architecture.

## 3. Important latest external-state change

The previously created GitHub App:

```text
govenv-materializer
```

was **deleted by the user**.

Treat that App as nonexistent.

Do not recreate it manually in the next session unless the redesigned governed architecture explicitly requires it.

The existing `authorized-materialization` environment may remain empty and main-only. The future convergent admin setup should reconcile it.

## 4. Major architectural decision: one human administrative root

We discovered that the current bootstrap was too manual:

- create GitHub App manually
- install it manually
- generate PEM manually
- copy Client ID manually
- provision environment secret manually
- provision environment variable manually
- dispatch several administrative targets one by one

The user explicitly rejected this model.

The agreed constitutional direction is:

> There must be exactly one human-supplied administrative root authority: `GOVENV_ADMIN_TOKEN`. Everything else must be derived, materialized, provisioned, ordered, rotated, and read-back verified by Govenv itself.

This should become **GV92**.

### Proposed GV92 wording

Recommended current wording:

> **GV92** — Require administrative bootstrap and continued administration to have exactly one human-supplied root authority, `GOVENV_ADMIN_TOKEN`. Its creation, replacement, or rotation preserves the identity of that same administrative root and must never constitute a new independent authority. From this root and an `AuthorizedRevision`, `Admin Materialize` must deterministically derive, materialize, provision, rotate, order, and read-back verify every subordinate credential, capability boundary, identity, environment, variable, secret, policy, and persistent administrative effect required by Govenv. No additional manually supplied credential, token, key, secret, application identity, environment mutation, or per-target administrative intervention may become a prerequisite for normal operation. Any required authority that cannot be derived from this root must be treated as an architectural incompleteness unless the hosting platform's impossibility is explicitly governed.

Key semantic distinction:

```text
AdministrativeRoot
AdministrativeCredential
```

`GOVENV_ADMIN_TOKEN` is the current credential representing the single administrative root.

Rotating the token changes the credential, **not** the identity of the authority.

## 5. Relationship to existing governance

The global coherence review concluded:

### GV42

Already says:

> Make repository bootstrap, integrations, secrets/environments setup, and privileged materialization declarative and reproducible through Govenv rather than repository-specific manual steps.

GV92 is **not a duplicate**. It strengthens GV42 with:

- exactly one human root;
- no later manual credentials;
- no later manual provisioning;
- no manual per-target admin operation;
- derived subordinate authority only.

### GV90

Still coherent.

It defines human authorization via `AuthorizedRevision` and separates candidate authors, human authorizers, and post-authorization materializers.

### GV91

Still coherent.

It governs monotonic, non-self-locking authority migrations and preserves recovery paths.

### GV22

Currently says admin-privileged external materializations run only through the manual, target-restricted `Admin Materialize` workflow.

This remains compatible **if the only human-visible target becomes a single composed `setup`**.

Individual environment/ruleset effects may remain internal materialization primitives.

### GV45

Still coherent.

Every administrative effect must retain apply → read-back → equality → evidence.

### GV51 / GV59 / GV88

Still coherent.

The future setup plan must remain governed semantic state; adapters only perform effects/observation.

## 6. Desired future Admin Materialize UX

The current UI is conceptually wrong:

```text
Admin Materialize
  target:
    admin-environment
    materializer-environment
    authorized-effects-environment
    pages-environment
    ...
```

The desired human interface is effectively:

```text
Admin Materialize
  setup
```

or ideally no target choice at all.

`setup` should be:

- deterministic;
- convergent;
- idempotent;
- revision-bound;
- ordered according to GV91;
- read-back verified after every externally observable effect;
- capable of reconciling partially configured state.

Conceptually:

```text
Human
  |
  +-- GOVENV_ADMIN_TOKEN   <- only root input
            |
            v
      Admin Materialize
            |
            +-- derive
            +-- materialize
            +-- provision
            +-- rotate
            +-- apply
            +-- read-back
            +-- prove
```

No later manual secret copying, App creation, token creation, environment editing, or individual target dispatches should be required.

## 7. `GOVENV_ADMIN_TOKEN` permissions

Current/previous intended fine-grained PAT scope:

```text
Repository access:
  only klarkc/govenv

Administration:
  Read and write

Environments:
  Read
```

For the redesigned convergent admin setup, the expected minimal change is:

```text
Repository access:
  only klarkc/govenv

Administration:
  Read and write

Environments:
  Read and write
```

Do **not** add these merely for convenience:

- Actions
- Contents
- Workflows

Earlier investigation showed `Actions: read` was unnecessary.

Reason for `Environments: write`:

- Admin Materialize should itself create/update environment secrets and variables.
- Humans should not provision those values manually through repository Settings.

The root admin credential must remain isolated from normal runtime workflows.

## 8. Materializer identity must be redesigned

The prior Stage B assumed a private GitHub App:

```text
govenv-materializer
```

with:

- Contents: write
- Workflows: write
- no Administration

The App was intended to mint short-lived installation tokens for normal post-merge materialization.

Under GV92, this architecture is valid **only if that subordinate identity can itself be derived/materialized from the one root interaction**.

If GitHub requires a second independent manual ceremony to create the App, that is now treated as architectural incompleteness rather than an automatically accepted bootstrap exception.

Because the App was deleted, the next session should evaluate replacement designs from first principles.

One candidate raised during the review:

### Write deploy key as derived materializer credential

Possible setup:

1. `Admin Materialize/setup` generates an SSH keypair.
2. Uses `Administration: write` to create a repository deploy key with write access.
3. Uses `Environments: write` to save the private key directly as an environment secret.
4. Normal Materialize uses only that narrow credential.

Potential issue:

GitHub ruleset bypass for `DeployKey` may apply to the deploy-key actor category rather than one exact key, so this must be modeled carefully before adoption.

In particular, do not accidentally allow a future candidate-author credential to inherit the same bypass.

This needs architectural review before implementation.

## 9. Stage B / C / D status

### Stage B

Current clean WIP:

```text
/home/klarkc/Sources/klarkc/govenv-gv90-stage-b-clean
branch: wip/gv90-stage-b-clean
commit: 109afb5
```

Purpose was:

- replace legacy Materialize/Test/Release/Pages flow;
- bind post-merge effects to exact authorized revision;
- use a dedicated materializer identity;
- chain Materialize → Test → {Release, Pages}.

**Do not publish/merge it as-is.**

It still assumes `govenv-materializer` App semantics and needs redesign under GV92.

### Stage C

```text
/home/klarkc/Sources/klarkc/govenv-gv90-stage-c
branch: wip/gv90-stage-c
commit: 69a4525
```

Contains executable main ruleset targets:

1. `main-integrity-ruleset`
2. `main-authorization-ruleset`
3. `main-authority-ruleset`

Activation order remains conceptually:

1. integrity
2. authorization
3. authority

But Stage C must be revisited because its bypass actor model currently depends on the materializer identity selected by Stage B.

### Stage D

Previously planned automated candidate-author identity `govenv-author`.

Under GV92, Stage D also needs redesign:

- the author credential must be derived from the same admin root;
- it must not require a second manual App/token ceremony;
- it must not gain main bypass authority.

## 10. Release 0.2.1 — do not release yet

The user asked whether to release `0.2.1` now.

Conclusion: **No.**

There are two independent blockers.

### Blocker A — architecture changed before release

`main` currently contains administration prose and bootstrap semantics that say:

- create/install `govenv-materializer` manually;
- provision `GOVENV_MATERIALIZER_PRIVATE_KEY` manually;
- provision `GOVENV_MATERIALIZER_CLIENT_ID` manually.

We now know this architecture is going to be replaced by GV92.

Publishing it in 0.2.1 would knowingly release an administrative bootstrap model we have already rejected.

### Blocker B — Release Please CHANGELOG placement bug

PR #3 currently has a mismatch:

- its PR body shows the `0.2.1` Governance Impact in the expected place;
- but the candidate `CHANGELOG.md` patch inserts the Governance Impact block **below the `0.2.0` heading**.

That conflicts directly with GV77's goal of `CHANGELOG.md` as canonical portable release materialization.

Do not merge PR #3 until this is corrected.

Let Release Please update the canonical PR after the governed correction lands; do not manually rewrite the PR body.

## 11. `govenv:check` status

A fresh check was run from the clean analysis worktree based on current `origin/main`:

```text
govenv:check
```

Result:

```text
success
exit code 0
{}
```

So the repository is mechanically consistent according to the currently implemented checker.

The issues identified above are semantic/governance gaps not yet encoded as enforced checks.

## 12. Current worktrees

Observed worktrees:

```text
/home/klarkc/Sources/klarkc/govenv
  d18a4a3 [main]
  DO NOT TOUCH: primary worktree has intentional WIP

/home/klarkc/Sources/klarkc/govenv-admin-readback-fix
  5809e04 [gov/materializer-client-id-boundary]

/home/klarkc/Sources/klarkc/govenv-admin-setup
  346aee0 [gov/admin-setup-bootstrap]

/home/klarkc/Sources/klarkc/govenv-gv84
  3467b29 [gov/gv84-counterexample-closure]

/home/klarkc/Sources/klarkc/govenv-gv90-stage-b
  500e3e7 [wip/gv90-stage-b]

/home/klarkc/Sources/klarkc/govenv-gv90-stage-b-clean
  109afb5 [wip/gv90-stage-b-clean]

/home/klarkc/Sources/klarkc/govenv-gv90-stage-c
  69a4525 [wip/gv90-stage-c]

/home/klarkc/Sources/klarkc/govenv-pr5-verify
  8dadeb6 (detached HEAD)
```

Primary worktree remains protected because it contains intentional local WIP.

## 13. Existing known open correctness items

Carry these forward:

1. GV54 phase-description counterexample:
   - snapshot currently preserves only Nat phase ID in a relevant path;
   - must preserve full phase identity;
   - never modify GV54 wording.

2. Snapshot codec duplication.

3. Evidence currently bound by GV number rather than exact Claim:
   - desired shape: `Evidence Claim`;
   - blocks proper GV74 completion semantics.

4. GV62 architecture matrix stale / Assurance role.

5. Supersession target liveness.

6. ReleaseKind provenance.

7. Explicit capability activation.

8. Semantic Conventional Commit type.

9. GV87 typed/persistent Governance Impact check not implemented.

10. GV88 earliest-enforcement inventory not implemented.

11. GV89 standalone `fix` regression signal not implemented.

12. Candidate materializer identity external verification must be redesigned under GV92.

13. Ruleset adapters remain only externally provable after actual activation/read-back.

14. `Govenv/Administration.lagda.md` still contains historically stale prose describing `admin-materialization` as not yet self-hardened, despite Admin Materialize run #5 having succeeded.

15. Current Stage A.1 commit uses Conventional Commit type `fix(authorization)`.
    GV89 is not implemented yet, but this is semantically notable for future regression-signal enforcement.

## 14. Key governance items that must not be casually changed

### GV71 — wording is frozen

Do not modify its wording:

> Restrict handwritten versioned repository content to Agda and Markdown only. Any generated or governed materialization may use its required target format. Until GV38 is completed, the only handwritten bootstrap escape hatch is root-level `devenv.nix`, `devenv.yaml`, and `devenv.lock`; all other implementation languages and handwritten configuration formats, including Nix elsewhere, are forbidden.

### GV84

Observed invariant regressions require counterexample closure.

### GV86

Governance items are cumulative constitutional decisions; lifecycle state controls operative effect, not constitutional membership.

### GV87

Typed candidate governance delta must be projected as a GitHub-native check; transient artifacts cannot be sole authoritative evidence.

### GV88

Enforce governable obligations at earliest sound information boundary; `govenv check` remains authoritative repository evaluation.

### GV89

Standalone `fix` in governed commit messages is a conservative regression signal.

### GV90

Human authorization is `AuthorizedRevision`; machine candidates, human authorizers, and post-authorization materializers remain distinct.

### GV91

Authority-boundary migrations must be monotonic and non-self-locking.

### GV92

To be introduced next: singular human administrative root / all subordinate authority derived from `GOVENV_ADMIN_TOKEN`.

## 15. Non-negotiable operating rules

- Never merge a PR without explicit user approval.
- Never publish/create a release without explicit user approval.
- Never manually create a competing tag/release.
- Never edit the Release Please PR body manually.
- Never mark a GV done merely because implementation exists; completion needs governed evidence.
- Never use `amended`; corrected governance uses supersession.
- Never modify GV71 wording.
- Never modify the primary worktree's intentional WIP.
- Never conflate local semantic definitions with applied GitHub state.
- External effects require staged application and read-back verification.
- Do not add `Actions: read` to the admin token.
- Never ask the user to paste PATs/private keys into chat.
- Do not recreate `govenv-materializer` manually.
- Do not continue `materializer-environment` bootstrap in the old model.
- Keep `admin-materialization` as the only human administrative root boundary.

## 16. Recommended next-session sequence

1. Introduce **GV92** in the roadmap with final wording.
2. Re-run global coherence review after insertion.
3. Redesign `Govenv.Administration` around:
   - one `AdministrativeRoot`;
   - one `AdministrativeCredential`;
   - `GOVENV_ADMIN_TOKEN` as the only human-provided credential;
   - subordinate credentials derived/materialized by Govenv.
4. Redesign `Admin Materialize` into one convergent/idempotent `setup`.
5. Decide the narrow runtime materializer mechanism:
   - derive a deploy key, or
   - another subordinate identity that can genuinely be materialized from the admin root.
6. Update credential profiles and admin-token permission model:
   - Administration: read/write
   - Environments: read/write
   - no unnecessary Actions/Contents/Workflows on the root token.
7. Rebase/redesign Stage B against the new materializer model.
8. Revisit Stage C bypass actors.
9. Revisit Stage D candidate-author identity under GV92.
10. Fix the release Governance Impact placement bug.
11. Let Release Please refresh PR #3.
12. Re-run:
    - `govenv:materialize`
    - `govenv:check`
    - release projection verification
    - global coherence review.
13. Only then consider merging Release Please PR #3 and publishing 0.2.1.

## 17. Short conceptual summary

The architecture is moving from:

```text
human
  +-- admin PAT
  +-- create App
  +-- create PEM
  +-- copy Client ID
  +-- provision secrets
  +-- provision variables
  +-- run several admin targets
```

to:

```text
human
  |
  +-- GOVENV_ADMIN_TOKEN
            |
            v
      Admin Materialize / setup
            |
            +-- derives subordinate credentials
            +-- materializes environments
            +-- provisions secrets/variables
            +-- configures policies
            +-- applies ordered effects
            +-- verifies read-back equality
            +-- records evidence
```

The invariant to preserve is:

> **There is one human administrative authority. Credentials may rotate; authority must not multiply.**
