# Govenv session handoff — proposition identity, supersession, disposition and roadmap/delta projection

**Date:** 2026-09-16  
**Repository:** `klarkc/govenv`  
**Purpose:** Resume the governance-lineage redesign in a new session without losing the refinements made after the previous handoff.  
**Important:** No repository changes were made in this session.

---

## 1. Starting point

The previous handoff established the semantic spine:

```text
Governance
    ↓ declares
Proposition
    ↓ evidence/proof
Obligation
    ↓ constitutional evolution
Disposition
```

with these major conclusions:

```text
1. Governance should not own a fundamental lifecycle state.

2. Governance declares Propositions.

3. Proposition is the governed logical statement.

4. Obligation means a Proposition has been established with evidence/proof.

5. Therefore an Obligation is already normatively in force.

6. There is no pending/staged/non-operative Obligation.

7. Pending is derived:
   no Obligation + no terminal pre-establishment disposition.

8. Disposition is about the constitutional destiny of a Proposition.

9. abandoned:
   Proposition never became an Obligation.

10. preserved / reformulated / withdrawn:
    concern constitutional continuation after establishment,
    except preserved may also carry a pending Proposition unchanged.

11. Governance glyphs are derived:
    ◇ ✓ ✓* ×.

12. Supersession planning has no operative effect.

13. Effective supersession should be modeled as a typed constitutional transition.

14. No general GV dependency graph.

15. Proposition/Obligation lineage is the long-term graph.

16. Delta is derived from typed constitutional transitions.

17. CHANGELOG / PR / Release are projections only.
```

---

## 2. Current repository facts reconfirmed

The current implementation still has:

```agda
data ItemState : Set where
  done todo cancelled : ItemState
  superseded : GovernanceRef → ItemState
```

and:

```agda
data ItemProgress : Set where
  completed advanced introduced cancelledProgress : ItemProgress
  supersededProgress : GovernanceRef → ItemProgress
```

The roadmap DSL currently stores item state:

```agda
GV ... ✓
GV ... ◇
GV ... ×
GV ... ↪ GVR ...
```

while README renders state before the GV:

```text
✓ GV3 ...
◇ GV57 ...
↪ GV47 ... → GV68
```

This session reinforced that the stored `ItemState` model is the part that should eventually disappear.

---

## 3. `GovernanceId : Nat → String → Set` remains intentional

We discussed whether:

```agda
GovernanceId : Nat → String → Set
```

is excessive.

Conclusion: keep it.

The `String` is not merely a label. It is the **human/AI contract** for the Governance.

Conceptually:

```text
GV 95 "human-readable contract"
```

contains two representations of the same governed intent:

```text
                Governance
              /            \
             /              \
human contract              formal semantics
   String                   Propositions
```

Meaning:

```text
Nat
  = which Governance?

String
  = what the human/agent contract claims it means?

Propositions
  = what it formally means?
```

Another agent and the human reviewer check that:

```text
contract(GV)
    ≈
formal meaning of its Propositions
```

This correspondence cannot be fully established by Agda because one side is natural language.

Therefore `String` being part of the dependent identity is valuable: silently changing the contract changes the type.

---

## 4. Do not conflate Proposition identity with current Governance responsibility

An important correction occurred.

Initially we considered:

```text
P(GV10, 0)
```

as Proposition identity.

This became awkward once `preserved` was allowed to move a Proposition from one Governance to another.

Example:

```text
GV10
└── Proposition X

GV10 ↪ GV20
    preserved X
```

The same Proposition survives but responsibility changes.

Therefore distinguish:

```text
origin(Proposition)
currentResponsibility(Proposition)
```

where:

```text
origin
  = immutable

currentResponsibility
  = derived from constitutional history
```

A Proposition may be:

```text
origin = GV10
establishedBy = GV20
currentResponsibility = GV30
```

after successive transitions.

---

## 5. Proposition IDs should be globally unique

The session converged on:

> `PropositionId` should be a global immutable identity.

Avoid:

```text
P(GV10, 0)
```

as the primary external identity.

Prefer something like:

```text
Prop 7
Prop 8
Prop 12
```

with uniqueness across the Constitution.

Reason:

```text
GV10
  introduces Prop7

GV10 ↪ GV20
  preserves Prop7

GV20 ↪ GV30
  preserves Prop7
```

The identity is still:

```text
Prop7
```

while:

```text
origin(Prop7)                = GV10
currentResponsibility(Prop7) = GV30
```

This makes Proposition transfer natural.

---

## 6. Avoid `P` as Proposition constructor

The repository already uses:

```agda
P 1 "..."
```

for `PhaseId`.

So Proposition should not also use `P`.

Preferred candidate notation:

```agda
Prop 17
```

Potential type direction:

```agda
data PropositionId : Nat → Set where
  Prop : (idx : Nat) → PropositionId idx
```

or potentially extend the generic identifier machinery, but **do not automatically add a String contract to PropositionId**.

The Governance has the human-readable contract.

The Proposition has its formal statement/type.

---

## 7. Governance introduces vs inherits Propositions

A Governance can have two conceptually different sets:

```text
introduced propositions
inherited propositions
```

Example:

```text
GV20
├── introduces Prop12
├── introduces Prop13
└── inherits Prop7
```

But `inherits` should preferably be derived from history rather than stored redundantly.

Only propositions first created under GV20 are introduced by GV20.

A preserved Proposition retains its original identity and origin.

---

## 8. Obligation identity likely does not need a separate ID

The preferred idea remains:

```text
Obligation Prop7
```

rather than:

```text
ObligationId 123
```

An Obligation is the constitutional establishment of an existing Proposition.

Potential conceptual shape:

```agda
record Obligation (p : Proposition) : Set₁ where
  field
    evidence : Evidence p
```

Important distinction:

```text
Evidence Prop7 may exist
without
Obligation Prop7 existing constitutionally yet.
```

Creating/recording the Obligation is itself the constitutional establishment.

Therefore do not reintroduce:

```text
staged Obligation
ready Obligation
operative Bool
established Bool
```

---

## 9. A Proposition should be established at most once

Strong candidate invariant:

```text
∀ Prop:
  at most one Obligation(Prop)
```

If an old obligation was withdrawn and later the same semantic rule is reintroduced, create a new Proposition identity.

Example:

```text
Prop10
  └── Obligation
      └── withdrawn

Prop200
  └── Obligation
```

Even if the statements are logically/textually equal.

This preserves append-only constitutional history.

---

## 10. `Disposition` is an event in a transition, not a static status

A further refinement:

Plain:

```text
Disposition Prop7
```

is insufficient because the same Proposition may be preserved multiple times:

```text
GV10 ↪ GV20
  preserve Prop7

GV20 ↪ GV30
  preserve Prop7
```

Therefore the conceptual form should be:

```text
Disposition Transition Prop
```

or equivalent.

Example:

```text
Disposition T1 Prop7 = preserved
Disposition T2 Prop7 = preserved
```

This keeps `Disposition` from becoming another lifecycle status enum.

Definition:

> **Disposition = the constitutional destiny assigned to a Proposition in a specific transition.**

---

## 11. Current disposition vocabulary

Preferred constructors / semantic cases:

```text
preserved
reformulated
withdrawn
abandoned
```

with these meanings.

### preserved

Same Proposition identity survives.

```text
Prop7 ≡ Prop7
```

Responsibility may move:

```text
GV10 ↪ GV20
    ≡ Prop7
```

This can apply to either:

```text
pending Proposition
or
established Proposition
```

because carrying an unresolved Proposition unchanged is meaningful.

### reformulated

An established Proposition is replaced by one or more new Propositions.

```text
Prop17 ⇒ Prop23
```

or split:

```text
Prop17 ⇒ Prop23, Prop24
```

A reformulation changes proposition identity.

Current preferred restriction:

```text
reformulated
  requires an existing active Obligation
```

If a pending Proposition changes before establishment, prefer:

```text
old Prop abandoned
new Prop introduced
```

rather than calling that reformulation.

### withdrawn

The Proposition had an Obligation and its normative force is intentionally removed.

```text
⊘ Prop15
```

Meaning:

```text
the proposition did become an obligation,
then ceased to be constitutionally required.
```

### abandoned

The Proposition never became an Obligation.

```text
× Prop41
```

Meaning:

```text
the proposition was intentionally not established.
```

---

## 12. Abandoned vs withdrawn remains fundamental

Keep this distinction rigid:

```text
abandoned
= proposition never became an obligation

withdrawn
= proposition became an obligation,
  then normative force was intentionally removed
```

Missing handling is never implicit abandonment or withdrawal.

---

## 13. Do not model abandonment as absolute `NoObligation p`

We reconsidered a candidate like:

```agda
abandoned :
  NoObligation p →
  Disposition t p
```

This is too strong if `NoObligation p` means:

```text
Obligation p → ⊥
```

What is needed is historical state:

```text
PendingBefore t p
```

meaning:

```text
up to the transition,
no constitutional Obligation had been established for p.
```

Then abandonment closes that pending proposition.

So validity conditions should be transition-relative, not logical impossibility proofs.

---

## 14. Suggested typed validity matrix

Conceptually:

```text
pending before transition:
    preserved   ✓
    abandoned   ✓
    reformulated ✗ (prefer abandon + introduce)
    withdrawn   ✗

active obligation before transition:
    preserved     ✓
    reformulated  ✓
    withdrawn     ✓
    abandoned     ✗
```

Candidate conceptual type:

```agda
data Disposition
     (t : Transition)
     (p : Proposition)
     : Set where

  preserved :
    LiveBefore t p →
    Disposition t p

  abandoned :
    PendingBefore t p →
    Disposition t p

  reformulated :
    ActiveBefore t p →
    NonEmpty Proposition →
    Disposition t p

  withdrawn :
    ActiveBefore t p →
    Disposition t p
```

Exact syntax/names remain open.

---

## 15. Split and merge come naturally from reformulation

Split:

```text
Prop10
  ⇒ Prop100
  ⇒ Prop101
```

can be:

```text
Disposition T Prop10 =
  reformulated [Prop100, Prop101]
```

Merge:

```text
Prop10 ┐
Prop20 ├⇒ Prop100
Prop30 ┘
```

can be represented as:

```text
Disposition T Prop10 = reformulated [Prop100]
Disposition T Prop20 = reformulated [Prop100]
Disposition T Prop30 = reformulated [Prop100]
```

No special split/merge constructors are required.

---

## 16. Preserve the term `superseded`

The user explicitly wants to keep **superseded/supersession** because it deliberately echoes ADR terminology.

Conclusion:

> Do not remove the term.

But move it out of GV lifecycle state.

Instead:

```text
Supersession
= historical/constitutional relation between Governance items
```

Example:

```text
GV47 ↪ GV68
GV77 ↪ GV95
```

Meaning:

```text
GV47 is superseded by GV68
GV68 supersedes GV47
```

This is analogous to:

```text
ADR-001: accepted
ADR-002: supersedes ADR-001
```

The difference is that Govenv also describes what happened to individual Propositions through Dispositions.

---

## 17. `↪` should mean supersession between GVs

Preferred operator:

```text
↪
```

Use it specifically for:

```text
GVold ↪ GVnew
```

Do not use `↪` as the status glyph of the old GV.

This is a major semantic cleanup.

Example:

```text
✓ GV47 ↪ GV68
```

means:

```text
GV47 was successfully resolved/established,
and later GV68 superseded it.
```

Not:

```text
GV47's state is "superseded".
```

This makes the model much closer to ADR semantics.

---

## 18. Supersession and Disposition coexist

Example:

```text
GV10 ↪ GV20
```

may contain:

```text
≡ Prop7
⇒ Prop8 → Prop12
× Prop9
```

So:

```text
Supersession
= relation between GVs

Disposition
= fate of Propositions within that constitutional transition
```

This separation is central.

---

## 19. Planned vs effective supersession

The previous distinction still stands:

```text
↝ planned supersession
↪ effective supersession
```

A planned supersession has no operative effect.

Potential conceptual separation:

```text
SupersessionPlan
Supersession
```

rather than:

```text
SupersessionState = planned | effective
```

because the latter recreates another lifecycle enum.

---

## 20. Effective supersession should be atomic

Conceptually:

```text
Supersession GV10 GV20
{
    establish successor obligations
    dispose outgoing propositions
    transfer preserved responsibility
}
```

Example reformulation:

```text
before:
  GV10 responsible for Prop10
  Obligation Prop10 active
  GV20 has Prop20 + evidence ready

cutover:
  establish Obligation Prop20
  Prop10 ⇒ Prop20
  GV10 ↪ GV20

after:
  Obligation Prop10 historical
  Obligation Prop20 active
```

The constitutional transition should not publish an intermediate state with a gap.

---

## 21. Current responsibility is the key to supersession coverage

A Governance must not only deal with Propositions it originally introduced.

It must cover every live Proposition for which it is currently responsible.

Example:

```text
GV10
└── introduces Prop7

GV10 ↪ GV20
    ≡ Prop7

GV20
├── inherits Prop7
└── introduces Prop12
```

When:

```text
GV20 ↪ GV30
```

the transition must cover both:

```text
Prop7
Prop12
```

because both are currently GV20's responsibility.

---

## 22. Replacement/Supersession coverage

Preferred definition direction:

```text
SupersessionCoverage(GV20 ↪ GV30)
=
all live Propositions p such that
currentResponsibility(p) = GV20
```

For each such Proposition exactly one valid disposition is required.

Pending:

```text
preserved
or
abandoned
```

Established/active:

```text
preserved
or
reformulated
or
withdrawn
```

This automatically handles inherited responsibility transitively without a GV dependency DAG.

---

## 23. Governance glyphs remain derived

Preferred glyphs:

```text
◇   at least one Proposition still pending

✓   all relevant Propositions established,
    none abandoned

✓*  no pending Proposition remains,
    at least one established,
    at least one abandoned

×   all declared/resolved Propositions abandoned
```

Important:

```text
later reformulation/withdrawal of an obligation
does not retroactively change ✓ to ✓*
```

`✓*` only records abandonment before establishment.

---

## 24. Important visual semantic change for superseded GVs

Under the new model:

```text
GV47
```

can remain:

```text
✓ GV47
```

even after:

```text
GV47 ↪ GV68
```

because:

```text
✓
= how GV47's own propositions resolved

↪ GV68
= historical supersession relation
```

Likewise a GV whose only pending proposition was abandoned may show:

```text
× GV77 ↪ GV95
```

This is more informative than old:

```text
↪ GV77 → GV95
```

because it separates resolution from supersession.

---

## 25. Preferred visual operator vocabulary

Current promising language:

```text
Phases
------

■   finished
▣   active
□   future


Governance / Proposition resolution
-----------------------------------

✓   established/resolved
✓*  resolved with at least one abandoned proposition
◇   pending
×   abandoned before establishment


Constitutional evolution
------------------------

↪   supersedes / superseded by
≡   preserved
⇒   reformulated
⊘   withdrawn
```

Exact glyphs remain revisable, but this direction was positively received.

---

## 26. Preferred README visual layout

The user specifically wants status and GV numbering aligned.

Preferred shape:

```text
▣ P1 : Formal governance model and repository closure

✓   GV3             : `Verdict`: `holds`, `violated`, and `unknown`.
✓   GV4             : Minimal `Rule` abstraction.
✓   GV47   ↪ GV68   : Type roadmap governance identifiers using `✓`/`○`.
✓   GV68            : Type roadmap governance identifiers using `✓`/`◇`.
◇   GV57            : Inventory repository behavior and policy.
×   GV77   ↪ GV95   : Make `CHANGELOG.md` the canonical portable release entry.
◇   GV95            : Make Govenv the sole semantic owner of the changelog.
✓*  GV100           : Example governance with partially abandoned scope.
```

Semantic columns:

```text
status | identity | supersession | contract
```

Do **not** change canonical IDs to zero-padded forms like:

```text
GV003
GV047
```

Alignment belongs to rendering, not identity.

A Markdown table is a good candidate:

```markdown
| | Governance | | Contract |
| :---: | :--- | :---: | --- |
| ✓ | **GV47** | ↪ **GV68** | ... |
| ✓ | **GV68** | | ... |
| × | **GV77** | ↪ **GV95** | ... |
| ◇ | **GV95** | | ... |
```

Potentially render without prominent headers if a cleaner roadmap look is desired.

---

## 27. `Govenv.Roadmap` should eventually stop storing status

The user liked the new layout, but the formal source should not simply move status to the front.

Do **not** turn:

```agda
GV 3 "..." ✓
```

into:

```agda
✓ GV 3 "..."
```

as a permanent semantic model.

The stronger direction is:

```agda
GV 3 "..."
GV 4 "..."
GV 47 "..."
```

with statuses derived from Constitution facts:

```text
Propositions
Obligations
Dispositions
Supersessions
```

So roadmap source is declaration/planning structure, while README displays derived state.

---

## 28. Contract terminology in projections

Current release rendering labels the second column:

```text
Proposition
```

but fills it with:

```text
descriptionOf governanceId
```

Now that `Proposition` becomes a real formal concept, this is semantically wrong.

Preferred projection terminology:

```text
Contract
```

Therefore:

```markdown
| GV | Contract |
```

or aligned:

```markdown
| Status | GV | Supersession | Contract |
```

The Governance String is the contract.

Formal `Prop n` is the Proposition.

Do not conflate them.

---

## 29. Proposed future GovernanceDelta redesign

Current:

```text
ItemProgress
  completed
  advanced
  introduced
  cancelledProgress
  supersededProgress
```

is tied to the old `ItemState` model.

New conceptual direction:

```agda
record GovernanceDelta : Set where
  field
    introducedGovernance : List SomeGovernanceId
    establishments       : List Establishment
    dispositions         : List DispositionEvent
    supersessions        : List SupersessionEvent
    phaseProgress        : PhaseProgress
```

Possible events:

```text
introduced
established
preserved
reformulated
withdrawn
abandoned
superseded
phase progression
```

`advanced` should probably disappear from the constitutional delta because work/reference activity is not itself a constitutional semantic change.

Commit notes can still show ordinary development activity separately.

---

## 30. Delta should stay sparse

Keep GV83-like semantics:

> only project semantic dimensions that changed.

Examples:

```text
Governance: 1 introduced
Propositions: 1 established
```

or:

```text
Governance: 1 superseded
Propositions: 1 preserved
```

Do not render empty categories.

---

## 31. Preferred CHANGELOG portable examples

### Supersession + reformulation

```text
### Governance delta

▣   P1     : unchanged

#### Superseded

✓   GV47   ↪ GV68
    ⇒   Prop17 → Prop23

Contract:

- Type roadmap governance identifiers and use readable `✓`/`○` notation.
+ Type roadmap governance identifiers and use readable `✓`/`◇` notation.
```

### Supersession + abandonment

```text
#### Superseded

×   GV77   ↪ GV95
    ×   Prop41

Contract:

- Make `CHANGELOG.md` the canonical versioned portable release entry.
+ Make Govenv the sole semantic owner of the canonical changelog.
```

### Supersession + preservation

```text
#### Superseded

✓   GV10   ↪ GV20
    ≡   Prop7
```

Keep portable CHANGELOG free of GitHub-specific HTML.

---

## 32. Preferred GitHub PR / Release projection

Use the same typed release document, but richer rendering.

Example:

```text
Governance
──────────

✓   GV47   ↪ GV68
    ⇒   Prop17 → Prop23
    reformulated

×   GV77   ↪ GV95
    ×   Prop41
    abandoned

✓   GV10   ↪ GV20
    ≡   Prop7
    preserved
```

Summary example:

```text
Phase         ▣ P1
Governance    2 superseded · 1 introduced
Propositions  1 preserved · 1 reformulated · 1 abandoned
```

This retains the existing desirable architecture:

```text
typed ReleaseDocument
       |
       +--> portable renderer --> CHANGELOG
       |
       +--> enriched renderer --> PR / GitHub Release
```

---

## 33. Example of `✓*`

Suppose:

```text
GV100
├── ✓ Prop50
├── ✓ Prop51
└── × Prop52
```

Then README:

```text
✓*  GV100 : Govern A, B and C.
```

Detailed projection:

```text
✓*  GV100 : Govern A, B and C.

    ✓   Prop50
    ✓   Prop51
    ×   Prop52
```

The `*` should eventually be navigable to the specific abandoned propositions.

---

## 34. Real historical supersessions under the emerging model

### GV47 ↪ GV68

Likely:

```text
✓ GV47 ↪ GV68
✓ GV68

Prop17 ⇒ Prop23
```

or equivalent IDs after actual migration.

This is true reformulation because the old obligation had been established.

### GV49 ↪ GV69

Likely another:

```text
reformulated
```

### GV48 ↪ GV70

Likely:

```text
reformulated
```

with a derived strengthening relation if:

```text
Statement Prop70 → Statement Prop48
```

“strengthened” should remain a derived logical relation, not necessarily a primitive Disposition.

### GV77 ↪ GV95

GV77 was unresolved.

Likely:

```text
× GV77 ↪ GV95
◇ GV95
```

with:

```text
Prop(old GV77) abandoned
```

rather than pretending an obligation was reformulated.

---

## 35. Distinguish supersession from Proposition disposition in prose

Preferred terminology:

```text
GV68 supersedes GV47.
Prop17 was reformulated as Prop23.

GV95 supersedes GV77.
Prop41 was abandoned.

GV20 supersedes GV10.
Prop7 was preserved.
```

Avoid using:

```text
"Prop7 was superseded"
```

unless a future design explicitly introduces Proposition-level supersession.

Current preference:

```text
superseded
  belongs to Governance relation

preserved/reformulated/withdrawn/abandoned
  belong to Proposition disposition
```

---

## 36. Current preferred topology

```text
                         Constitution
                              |
                         Governance
                    /            \
               contract          introduces
               String               |
                                    v
                                Proposition
                                Prop n
                               /      \
                              /        \
                       Evidence       Transition
                          |               |
                          v               v
                     Obligation       Disposition
                                      /   |   |   \
                              preserve reform withdraw abandon
```

Governance evolution:

```text
GVold ↪ GVnew
   |
   +--> Supersession
   |
   +--> dispositions over every live Prop
        for which GVold currently has responsibility
```

Derived:

```text
currentResponsibility
Governance glyphs
OperativeConstitution
GovernanceDelta
README
CHANGELOG
PR
Release
```

---

## 37. Things explicitly rejected / avoid reintroducing

Do not reintroduce without strong justification:

```text
ObligationState
pending Obligation
staged Obligation
established-but-not-operative Obligation
GV fundamental ItemState
Maybe Abandonment
P(GV n, localIndex) as the primary Proposition identity
superseded as the GV's lifecycle status
advanced as a constitutional semantic event
general GV dependency DAG
```

---

## 38. Naming currently preferred

```text
GovernanceId
GV

PhaseId
P

PropositionId
Prop

Obligation
Disposition
Transition
Supersession
SupersessionPlan
```

Keep:

```text
superseded
supersedes
superseded by
```

because the ADR analogy is intentional and useful.

---

## 39. Open questions for next session

### A. Exact Proposition representation

Need to decide:

```text
PropositionId : Nat → Set ?
Prop : Nat → PropositionId n ?

Where does Statement live?
record Proposition?
indexed family?
```

Need to preserve global identity and formal statement association cleanly.

### B. Exact relation Governance → introduced Propositions

Need a minimal representation that can prove:

```text
origin(Prop)
```

without coupling identity to current responsibility.

### C. Exact Obligation representation

Need to integrate with current:

```text
StaticEvidence
ObservedEvidence
CompletionAssurance
```

without recreating lifecycle state.

### D. Exact Transition / Disposition type

Need final Agda shape for:

```text
preserved
reformulated
withdrawn
abandoned
```

with transition-relative validity.

### E. Exact Supersession type

Need to formalize:

```text
SupersessionPlan
Supersession
```

and whether an effective supersession itself is the `Transition`.

### F. SupersessionCoverage

Formalize:

```text
all live Propositions with
currentResponsibility = old GV
must receive exactly one valid Disposition.
```

This is probably the next high-value formal step.

### G. Current responsibility

Need to derive:

```text
currentResponsibility : Proposition → Governance
```

from history, including preserved chains.

### H. Governance glyph derivation

Formalize:

```text
◇ ✓ ✓* ×
```

without `ItemState`.

### I. README renderer

Prototype aligned projection:

```text
status | GV | supersession | contract
```

possibly Markdown table, while keeping two visible roadmap levels.

### J. GovernanceDelta redesign

Replace item-progress semantics with real constitutional events.

### K. Migration strategy

The current repository has immutable historical GVs and GV54 constraints.

Need carefully determine how the new model is introduced without rewriting historical identity or prematurely constitutionalizing an unstable design.

---

## 40. Suggested next work sequence

Do **not** implement immediately.

### Step 1 — formal Proposition identity spike

Study minimal candidate types for:

```text
PropositionId
Proposition
origin
Statement
```

with global `Prop n`.

### Step 2 — formal Supersession/Disposition spike

Model:

```text
GVold ↪ GVnew
≡ preserved
⇒ reformulated
⊘ withdrawn
× abandoned
```

without roadmap lifecycle state.

### Step 3 — define SupersessionCoverage

Prove coverage over currently responsible live Propositions.

### Step 4 — exercise real history

Test:

```text
GV47 ↪ GV68
GV49 ↪ GV69
GV48 ↪ GV70
GV77 ↪ GV95
```

### Step 5 — derive Governance glyphs

Prove:

```text
◇ ✓ ✓* ×
```

from proposition history.

### Step 6 — redesign typed GovernanceDelta

Use constitutional events instead of `ItemProgress`.

### Step 7 — prototype README / CHANGELOG / Release projections

Use the agreed aligned visual language.

### Step 8 — only then define new governance items / implementation migration

Because immutable governance definitions make premature constitutionalization expensive.

---

## 41. No repository changes made

This session was design analysis only.

No new GV was created.  
No branch was created.  
No PR was opened.  
No code was modified.  
No release was created or triggered.  
No existing local work was overwritten.

Resume next session from:

> **Global `Prop n` identity + exact `Supersession` / `Disposition` types + `SupersessionCoverage`, then derive glyphs and projections.**
