# Govenv — session handoff
## 2026-09-15 — release history regression, `Unreleased`, roadmap `Current`, Stage B

This file compacts the current working session so the next session can continue without re-discovery.

---

## 1. Non-negotiable user constraints

- **Never merge a PR without explicit user approval.**
- **Never create/publish a GitHub Release without explicit user approval.**
- The user normally performs merges themselves.
- “continue”, “prossiga”, “ok”, or “e agora?” are **not** merge/release authorization.
- Prefer formal invariants, typed identities/lifecycle, deterministic materialization, exact revision binding, persistent counterexamples, read-back verification, and minimum ungoverned semantics.
- Candidate PRs should expose the final semantic state for human review whenever possible.
- Avoid touching unrelated dirty changes in the original worktree.

---

## 2. Repository / current public state

Repository:

- `klarkc/govenv`
- Tagline: “A type system for your repository. Formally define what your project is allowed to become.”

Current `main`:

- `733c8126375b9b322de505fae7b5471f796af1fb`
- commit: `chore(materialize): update release governance impact`

The Release Please PR #3 (`chore(main): release 0.2.1`) was merged using rebase-style history and entered `main` as two commits:

1. `10887c2e898cba8587d7f79f2dec144afe242d33`
   - `chore(main): release 0.2.1`
2. `733c8126375b9b322de505fae7b5471f796af1fb`
   - `chore(materialize): update release governance impact`

Important: `733c812` was already part of the release PR branch. It is **not** evidence of a post-merge derived materialization push through the deploy key.

Traditional branch protection still showed `main` as not protected before Stage C. Stage C is intentionally not active yet.

---

## 3. Release `v0.2.1`

`v0.2.1` now exists and is published.

- tag/release: `v0.2.1`
- target commit:
  `733c8126375b9b322de505fae7b5471f796af1fb`
- immutable GitHub Release: yes
- published by GitHub Actions
- published at approximately `2026-09-15T20:05:55Z`

The published release body contains the expected Governance Impact for `0.2.1`.

The `0.2.1` Governance Impact currently reports:

- Phase: `▣ P1 — unchanged`
- Items: `4 advanced · 15 introduced · 2 superseded`
- advanced: GV59, GV63, GV77, GV42
- introduced: GV84, GV86, GV87, GV90, GV91, GV92, GV93, GV83, GV78, GV79, GV80, GV81, GV82, GV89, GV88
- superseded:
  - GV85 → GV89
  - GV76 → GV78

---

## 4. Materialize #37 — fully successful

Workflow run:

- workflow: `Materialize`
- run ID: `35015821441`
- run number: `#37`
- head SHA: `733c8126375b9b322de505fae7b5471f796af1fb`

Final result: **success**

Jobs:

### materialize
Success.

Important steps:

- Checkout authorized revision ✅
- Materialize constitution ✅
- Check materialized state ✅
- Detect materialization drift ✅
- `Commit derived materializations` → **skipped**
- Record effective materialized revision ✅

Therefore there was **zero post-merge materialization drift** on this run.

### test / test
Success.

### pages / build
Success.

### release / release-please
Success.

Important steps:

- Release Please ✅
- Materialize release governance → skipped
  - expected because the release PR had already been merged
- Materialize published release governance ✅
  - this is the successful published-release read-back path

### pages / deploy
Success.

Thus the full `v0.2.1` release path finished successfully.

---

## 5. Stage A / Stage B status

### Stage A — complete and proven

Single-root admin model was previously applied and externally read back.

Relevant state:

- one human-supplied root:
  `GOVENV_ADMIN_TOKEN`
- exactly one writable deploy key:
  `govenv-materializer`
- environment boundaries:
  - `admin-materialization`
  - `authorized-materialization`
  - `authorized-effects`
  - `github-pages`

GV92/GV93 model is in place.

### Stage B — implementation largely proven

Already proven:

- exact AuthorizedRevision binding
- Test path
- Pages build/deploy
- Release Please branch mutation using explicit ephemeral Git credential bridge
- Release Governance read-back
- published GitHub Release governance read-back (`#37`)

Still **not proven live**:

> derived-main materialization push through the `govenv-materializer` deploy key.

Why:

- Materialize #35: no materialization drift
- Materialize #36: no materialization drift
- Materialize #37: no materialization drift

So `Commit derived materializations` has remained skipped on the important Stage B runs.

Do **not** activate Stage C before this path is genuinely exercised and verified, because GV91 requires authority-boundary migrations to be monotonic/non-self-locking.

---

## 6. Important regression found in `CHANGELOG.md`

During this session the user noticed that only the newest release seemed to retain Governance Impact.

This was confirmed.

Current `CHANGELOG.md` on `main`:

- `0.2.1` contains its Governance Impact.
- `0.2.0` lost its historical Governance Impact.

Before `0.2.1`, at SHA `30fc755`, `0.2.0` still contained its Governance Impact.

### Root cause

`src/Govenv/Adapter/release-governance-pr.sh` used a global operation:

```sh
strip_section() {
  awk '
    /<!-- govenv-governance-impact:start -->/ { skip = 1; next }
    /<!-- govenv-governance-impact:end -->/ { skip = 0; next }
    !skip { print }
  ' "$1"
}
```

That removed **all** Governance Impact sections from the whole changelog.

Then `materialize_section_at_release` inserted only the current release section.

Worse, `verify_section_at_release` enforced a document-global invariant equivalent to:

> `marker_count == 1`

So the adapter formally encoded the wrong behavior: exactly one Governance Impact section in the entire changelog.

This conflicts with the intended meaning of GV77:

> `CHANGELOG.md` is the canonical versioned portable materialization of each typed release entry.

Expected historical shape:

```text
## [0.2.1]
  Governance impact for 0.2.1
  changes

## [0.2.0]
  Governance impact for 0.2.0
  changes
```

This is considered a real **GV84 regression**.

---

## 7. Local exploratory fix worktree

A clean worktree was created to investigate/fix this regression:

- path:
  `/home/klarkc/Sources/klarkc/govenv-release-history-fix`
- branch:
  `fix/release-governance-history`
- base:
  `733c8126375b9b322de505fae7b5471f796af1fb`

Current local status:

```text
 M CHANGELOG.md
 M Govenv/Materialization/ReleaseGovernance.lagda.md
 M devenv.nix
 M src/Govenv/Adapter/release-governance-pr.sh
?? Govenv/Materialization/ReleaseGovernance/history-preservation-counterexample.md
```

Current diffstat:

```text
CHANGELOG.md                                      | 184 ++++++++++++++++++
Govenv/Materialization/ReleaseGovernance.lagda.md |   2 +-
devenv.nix                                        |   6 +
src/Govenv/Adapter/release-governance-pr.sh       | 222 ++++++++++++++++++----
```

These changes are **not committed or pushed**.

Important: this exploratory implementation should **not automatically become the final PR**, because later in the conversation we decided a stronger `Unreleased` architecture is preferable.

Preserve it as investigation/counterexample work until the new model is designed.

---

## 8. What the exploratory fix already established

The local adapter was changed experimentally so that:

- extraction is release-specific
- verification is release-specific
- marker cardinality means:
  - one target release heading
  - one Governance Impact start marker inside that release
  - one corresponding end marker
- historical release sections are preserved
- a target-specific misplaced identical block can be removed without globally destroying unrelated historical blocks

A new counterexample was added:

`Govenv/Materialization/ReleaseGovernance/history-preservation-counterexample.md`

Its purpose:

- contain at least `0.2.1` and `0.2.0`
- update the `0.2.1` block
- assert `0.2.0` remains byte-for-byte unchanged

All three local regression fixtures passed together:

1. release placement counterexample ✅
2. release history preservation counterexample ✅
3. release push authorization counterexample ✅

The `0.2.0` Governance Impact was restored locally byte-for-byte from immutable tag `v0.2.0`, while preserving the `0.2.1` block.

Canonical validation also passed:

```text
nix run github:cachix/devenv/v2.3 -- tasks run govenv:check
```

Result:

```json
{}
```

However, again: treat this implementation as **exploratory**, because of the new `Unreleased` design below.

---

## 9. Important discovery: the formal target was already version-specific

The Agda materialization model was already conceptually correct.

`Govenv.Materialization.ReleaseGovernance.changelog` targets:

```text
repositoryFileSection "CHANGELOG.md"
  releaseGovernanceImpactInChangelog
  (afterReleaseHeadingInFile releaseVersion)
```

So the formal semantic target is already:

> the Governance Impact section belonging to one specific release version.

The bug was primarily in the shell adapter, which behaved globally.

This is useful because it means the regression does not necessarily require inventing a new basic rule merely to say “release sections are version-specific”.

---

## 10. New architecture agreed: canonical `Unreleased`

The user asked whether Release Please can coexist with an `Unreleased` head.

The architecture now preferred is:

- Release Please remains the version/release coordinator.
- Release Please does **not** own `CHANGELOG.md`.
- Govenv becomes the sole owner of the canonical changelog.
- `CHANGELOG.md` contains a canonical `## [Unreleased]`.
- Govenv continually derives `Unreleased` from:
  `latest release boundary .. current AuthorizedRevision`.
- Historical release entries are immutable.
- When Release Please opens/updates a release PR, Govenv freezes the `Unreleased` state into the candidate version **inside the release PR before human approval**.

### Ownership split

Release Please:

- analyzes Conventional Commits
- determines SemVer bump
- opens/updates release PR
- updates manifest/version files
- creates tag
- creates GitHub Release

Govenv:

- owns `CHANGELOG.md`
- owns `## [Unreleased]`
- derives Unreleased contents
- derives Governance Impact
- freezes Unreleased into candidate release entry
- preserves historical releases
- projects release content into GitHub PR/release surfaces
- verifies external effects by read-back

Release Please should be configured so it no longer edits `CHANGELOG.md`, likely through its supported changelog-skip configuration.

Do not assume the exact final configuration has already been implemented; it has not.

---

## 11. Agreed future release flow

The user restated the proposed flow and it was refined.

### Normal commit enters `main`

Suppose latest release is `v0.2.1`.

A/B/C enter main.

Govenv materializes:

```text
# Changelog

## [Unreleased]

### Governance impact
...
range: v0.2.1..HEAD

### Features
- ...

### Bug Fixes
- ...

## [0.2.1]
...

## [0.2.0]
...
```

At the same time, Release Please detects the commits and opens/updates its normal release PR.

Release Please does **not** edit the changelog.

### Release Please decides candidate version

Suppose candidate is `0.3.0`.

Govenv recognizes the release PR and materializes **on the release PR branch**:

```text
# Changelog

## [Unreleased]

## [0.3.0]

### Governance impact
...

### Features
- A
- B
- C

## [0.2.1]
...

## [0.2.0]
...
```

Conceptually:

```text
Unreleased --freeze--> 0.3.0
```

### Human authorization

The human reviews and merges a PR that already contains:

- version bump
- manifest changes
- final candidate changelog entry
- Governance Impact
- empty/new Unreleased head

Thus the exact final release content is part of the human-approved `AuthorizedRevision`.

This is better than performing the semantic freeze only after merge.

### After merge

Release Please creates:

- tag `v0.3.0`
- GitHub Release `v0.3.0`

Govenv reads back the GitHub Release and verifies equality with the governed release document.

### Next commit

After commit D:

```text
## [Unreleased]
D

## [0.3.0]
A
B
C

## [0.2.1]
...
```

Cycle repeats.

### If a new commit arrives while the release PR is open

Release Please updates the same PR and may even change the candidate SemVer.

Govenv simply re-derives the frozen candidate from the new delta.

No imperative/manual “moving text” should be semantically authoritative.

---

## 12. Why the new design is preferred

It gives a cleaner model:

```text
Unreleased = f(lastPublishedRelease, currentRevision)

Released[X] = f(previousReleaseBoundary, X)
```

Properties:

- historical entries never need global rewriting
- current work is explicit
- release candidate is reviewable before merge
- human authorization covers version + changelog + governance delta together
- GitHub Release becomes a projection/effect of already-authorized content
- fewer chances for the class of bug where current release materialization deletes historical release content

The previous exploratory adapter fix remains valuable as a GV84 counterexample/analysis, but the final design should solve the larger ownership problem.

---

## 13. New roadmap issue discovered: “Current” can become stale

The user asked whether an existing GV guarantees that roadmap `Current` is actually up to date.

Answer: **not sufficiently**.

### Existing guarantees

#### GV69
Guarantees structural phase progression with exactly one active phase while in progress.

It does **not** necessarily enforce:

> a phase whose items are all terminal cannot remain active.

#### GV52
Guarantees:

- phase/governance indices unique
- phase indices progress monotonically
- a finished phase cannot contain pending items

But this is one-directional.

It does not necessarily force:

> if every item in the active phase is terminal, the active phase must advance.

### README `Current:` is even more vulnerable

`Govenv.Readme.lagda.md` currently has independently maintained prose:

```agda
currentSummary : String
```

Current concrete value still says roughly:

> `Verdict`, typed `Fact`, dependency-indexed `Rule`, typed roadmap structure, materialization closure, roadmap integrity, immutable governance identity, and typed release governance are in place; GV55 release-progress policy and its GV56 self-governing `Rule` are next.

That is stale relative to work already performed through GV84–GV93.

`Govenv.Materialization.Readme` renders:

```text
current (currentOf (currentSummary readme) (roadmap readme))
```

Thus the README `Current:` summary currently has an independent manually maintained semantic source.

This conflicts with the direction of GV51/materialization closure: if the status is derivable from the roadmap, there should not be an independent stale prose source.

---

## 14. Proposed new GV94

Tentative proposition agreed in discussion:

> **GV94 ◇ — Make roadmap current state derived and self-consistent: while governance work remains, the active phase must be the earliest phase containing non-terminal governance work; a phase whose items are all terminal must not remain active, and when no non-terminal work remains the roadmap must be complete. Every `Current` projection, including README status and next-work information, must be derived from this typed roadmap state and may contain no independently maintained progress summary.**

Conceptually valid:

```text
P0 ■  all terminal
P1 ■  all terminal
P2 ▣  contains non-terminal governance work
P3 □
```

Invalid:

```text
P0 ■  all terminal
P1 ▣  all terminal     <- stale active phase
P2 □  contains pending work
```

Also eliminate independent progress prose such as:

```agda
currentSummary = "... GV55 and GV56 are next ..."
```

Instead derive `Current` from typed roadmap state, e.g.:

```text
active phase = P1
pending items = GV57, GV58, GV59, ...
```

The exact projection format is still open and should be designed in the next session.

GV94 should likely be addressed **before** the new release/Unreleased GVs, because it closes a currently observed inconsistency in the core roadmap model.

---

## 15. Likely new GVs after GV94

Do not finalize numbering/text blindly; review constitution and roadmap first.

Tentative direction:

### GV94
Derived/self-consistent roadmap Current state.

### GV95+ — Unreleased/release ownership redesign

Likely governance concepts to encode separately or together:

1. `CHANGELOG.md` has one canonical typed `Unreleased` head derived from the latest published release boundary to the current revision.
2. Historical release entries are immutable/reconstructible release documents.
3. Release Please may determine candidate SemVer and lifecycle but must not independently own/edit canonical changelog content.
4. Release PR materialization freezes the current Unreleased release document into the candidate version before human approval.
5. Published GitHub Release is a projection/effect of the same authorized typed release document and must pass read-back equality.
6. Release-boundary transitions must avoid race/ordering ambiguity between tag existence, main state, Unreleased derivation, and release candidate derivation.
7. Release candidate refresh when new commits enter main must be deterministic and preserve human-review semantics.

Need check whether GV77 should be **superseded** rather than merely advanced, because its current wording says:

> Release Please PR and published GitHub Release project the same typed release content...

and currently implies the changelog is a versioned release entry. The new model introduces a first-class `Unreleased` document and changes ownership responsibilities.

Remember immutable-GV policy:
- do not mutate GV77 in place
- if semantics change, create a new GV and supersede GV77 if necessary.

---

## 16. GV84 implications for the changelog regression

The observed regression must remain preserved.

The final repair should include:

- persisted counterexample showing historical Governance Impact was deleted
- corrected assurance boundary
- candidate validation that rejects recurrence
- deterministic reconstruction of historical release content from revision-addressable governed sources/tags/snapshots
- no reliance on “whatever text happened to survive in CHANGELOG.md”

The local exploratory fixture:
`history-preservation-counterexample.md`
is useful input, even if the adapter implementation is redesigned.

The real observed bad state was:

- `main` at `733c812`
- `0.2.1` Governance Impact present
- `0.2.0` Governance Impact absent
- Materialize #37 still passed with zero drift

That is strong evidence that the previous checks accepted a governed-history loss.

---

## 17. Important Stage B evidence still pending

Before Stage C, intentionally exercise a real **post-merge derived materialization drift**.

Desired live scenario:

1. Human approves a legitimate source/governance change in a PR.
2. The authorized main revision intentionally does not yet contain a deterministic derived materialization that GV18 permits in the immediately following `chore(materialize)` commit.
3. Materialize on `main` detects drift.
4. It creates the deterministic derived commit.
5. It pushes through the `govenv-materializer` deploy key.
6. Verify:
   - causal provenance to authorizing SHA
   - derived commit adds no new semantic authority
   - effective materialized SHA is used by downstream workflows
   - exact deploy-key actor/capability path
   - repository result/read-back is correct

The upcoming `Unreleased` materialization work may provide a **natural, non-artificial opportunity** to exercise this path, but design carefully so it remains consistent with the stronger principle that candidate-final semantic content should be visible to human review when possible.

Do not fabricate meaningless drift just to test the deploy key.

---

## 18. Stage C remains blocked

Do not activate Stage C automatically.

Before Stage C:

- close the changelog historical-regression design
- define/implement GV94
- define/implement Unreleased ownership model
- prove deploy-key derived-main materialization path
- perform global coherence review across all GVs/phases
- review Stage C ruleset design
- confirm:
  - PR-only human semantic authority
  - narrowly scoped deploy-key bypass
  - no broad `contents: write` semantic escalation
  - recovery path exists
  - required checks are established before enforcement
  - closed deploy-key set still verified

Then prepare PR(s) for user review/merge.

---

## 19. Existing security architecture reminder

Current release-branch mutation uses a validated explicit temporary `GIT_ASKPASS` bridge.

Properties:

- checkout uses `persist-credentials: false`
- token is not embedded in remote URL
- no persistent credential helper
- only the specific push gets the ephemeral Git credential bridge
- `BASH_ENV=/dev/null` prevents shell startup from overwriting credential context
- external read-back verifies result

Do not claim the project uses `gh auth git-credential`; that was only discussed and never adopted.

### Sensitive credential incident

During an earlier debug session, shell tracing unexpectedly printed several credential categories from local startup environment.

Never reproduce any values.

If necessary, only refer to categories:
- GitHub
- Atlassian
- model/API providers
- hosting/GPU provider
- Hugging Face
- SSH material
- Google service-account material
- other auth secrets

The user was already warned to rotate them.

---

## 20. Original dirty worktree — do not disturb

Original repo path:

`/home/klarkc/Sources/klarkc/govenv`

It had unrelated dirty state, including:

- modified `src/Govenv/Kernel/Assurance.agda`
- untracked `Govenv/Assurance/GV60.lagda.md`
- nested worktree-related directory

Continue using clean worktrees for repository changes.

Do not accidentally stage/overwrite unrelated original-worktree changes.

---

## 21. Suggested next-session order

Recommended sequence:

### A. Re-open this handoff and inspect live state
- fetch current `main`
- confirm `v0.2.1`
- confirm no unexpected commits since `733c812`
- inspect current local exploratory worktree status

### B. Formalize GV94 first
- inspect GV50/GV52/GV69/GV86/GV88 interactions
- define non-terminal/terminal semantics
- decide whether `cancelled` and `superseded` count terminal (likely yes)
- derive active phase from earliest phase containing non-terminal work
- ensure roadmap `complete` iff no non-terminal work remains
- remove independent `currentSummary` semantic status from README
- derive `Current:` projection from roadmap
- add assurance tests for stale active phase
- add regression/evidence if appropriate

### C. Design the `Unreleased` release model formally
Before coding adapters, decide:
- typed `ReleaseBoundary`
- typed `UnreleasedDocument`
- typed historical `ReleaseEntry`
- how Release Please candidate version is observed
- how freeze from Unreleased → candidate release is represented
- ownership and immutability boundaries
- whether GV77 is superseded
- exact relation between `main`, release PR candidate revision, tag, and published release

### D. Rework the exploratory changelog regression fix
Do not simply commit current shell patch.

Use the persisted counterexample, but make the final implementation reflect the new first-class Unreleased architecture.

### E. Validate locally
- `govenv:check`
- specific counterexamples
- changelog history reconstruction
- release PR candidate refresh
- release body read-back
- no historical release mutation

### F. Prepare PR(s)
Prefer small reviewable PRs if dependencies allow:
1. roadmap-current GV94
2. release/Unreleased governance + model
3. adapter/materialization migration if separation is coherent

Do not merge without explicit approval.

### G. Later: live deploy-key materialization proof
Exercise Stage B’s still-unproven derived-main push path.

### H. Only then Stage C
After coherence review and user approval.

---

## 22. Core conceptual model to preserve

Govenv authorization:

```text
Human-approved PR
      |
      v
AuthorizedRevision
      |
      +--> deterministic repository materializations
      |
      +--> deterministic external effects
```

Derived effects/materialization commits do not create semantic authority.

Admin bootstrap:

```text
AdministrativeRoot
      |
      v
AdministrativeCredential / root authority
      |
      v
derived scoped credentials + capability boundaries
```

Release model being proposed:

```text
latest published release ----> current AuthorizedRevision
            \_____________________/
                      |
                      v
                  Unreleased

Release Please determines candidate version
                      |
                      v
Govenv freezes Unreleased into candidate release
inside the release PR
                      |
                      v
human approves exact final release state
                      |
                      v
tag + GitHub Release
                      |
                      v
read-back equality
```

Roadmap model desired after GV94:

```text
Current := derived from typed roadmap
```

not:

```text
Current := manually maintained prose
```

---

## 23. Immediate warning for next assistant

Do **not** see the existing local branch `fix/release-governance-history` and assume it should simply be committed.

It was written before the architectural decision to introduce first-class `Unreleased`.

Its useful assets are:

- observed regression analysis
- counterexample
- release-specific verification ideas
- proof that historical `0.2.0` can be reconstructed from immutable release history
- successful local `govenv:check`

Its adapter design should be reevaluated against the new architecture.

Also do **not** implement GV94 by merely rewriting README prose. The point is to remove the independent semantic source and derive `Current` from typed roadmap state.

---

## 24. User’s last decision

User agreed with:

1. first-class `Unreleased` design;
2. Release Please still opens/updates the release PR;
3. Release Please should not own the changelog;
4. Govenv freezes Unreleased into the candidate version **inside the release PR before human approval**;
5. `Current` in the roadmap/README should be made genuinely up-to-date by derivation rather than manual prose;
6. start the combined work in a **new session**.

This handoff is the starting point for that new session.
