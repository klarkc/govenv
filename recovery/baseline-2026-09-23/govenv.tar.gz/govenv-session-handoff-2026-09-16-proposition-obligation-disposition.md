# Govenv session handoff — propositions, obligations, disposition and derived governance state

**Date:** 2026-09-16  
**Repository:** `klarkc/govenv`  
**Purpose:** Resume the obligation-lineage design from the previous handoff, incorporating the refinements from this session.  
**Important:** No repository changes were made in this session.

---

## 1. Starting point from the previous handoff

The previous session established that the current model has a gap around supersession:

- current `ItemState` mixes lifecycle and supersession;
- assurance coverage requires evidence only for `done`;
- `superseded` items are skipped by assurance coverage;
- therefore an established governance obligation can disappear when its GV is superseded unless continuity/disposition is formalized.

The previous conceptual direction was:

```text
Constitution
  = immutable constitutional history

OperativeConstitution
  = currently effective obligations

Replacement / supersession
  = typed constitutional transition

Disposition
  = destiny of inherited obligations

Delta
  = typed constitutional transition projection

CHANGELOG / PR / Release
  = projections only
```

The previous handoff also distinguished:

```text
↝ planned replacement
↪ effective supersession
```

and rejected a general GV dependency DAG.

---

## 2. Repository observations confirmed in this session

Reading `origin/main` confirmed:

```agda
data ItemState : Set where
  done todo cancelled : ItemState
  superseded : GovernanceRef → ItemState
```

This currently mixes:

```text
GV establishment/progress
+
relation to another GV
```

`Release.ItemProgress` repeats the same coupling through:

```text
completed
advanced
introduced
cancelledProgress
supersededProgress
```

Current assurance coverage still ignores superseded items.

The working tree was not modified. The local `main` was behind `origin/main` and had unrelated local changes, so all analysis used `origin/main` / `git show` without resetting or checking out over user work.

---

## 3. Important real historical cases

We rechecked the existing supersessions:

```text
GV47 -> GV68
GV49 -> GV69
GV48 -> GV70
GV77 -> GV95
```

Historical distinction:

```text
47 -> 68 : old GV was done
49 -> 69 : old GV was done
48 -> 70 : old GV was done
77 -> 95 : old GV was todo
```

This originally suggested two cases:

```text
established obligation being replaced
vs
planned governance being replaced before establishment
```

That distinction later evolved into the Proposition/Obligation model below.

---

## 4. First refinement: governance state should derive from lower-level semantics

We questioned whether:

```text
todo
done
cancelled
```

should really be fundamental states of a Governance item.

The new direction is:

> Governance should not own a fundamental lifecycle state.
> Its displayed state should be derived from the fate of the propositions it declares.

This avoids two machines that must stay synchronized:

```text
GV done
+
obligation established
```

Instead:

```text
lower-level semantic facts
    ↓
derived governance glyph
```

---

## 5. `✓*` was introduced as a derived projection

We agreed that a Governance may finish with some declared items intentionally abandoned.

Projected glyphs:

```text
◇   at least one declared proposition is still pending

✓   all declared propositions became obligations

✓*  no proposition remains pending,
    at least one became an obligation,
    and at least one was abandoned

×   all declared propositions were abandoned
```

Example:

```text
GV100
├── P100.0 -> Obligation
├── P100.1 -> Obligation
└── P100.2 -> abandoned

=> ✓* GV100
```

The `*` should be navigable/explainable and identify exactly which propositions were abandoned.

Important:

```text
later withdrawal/reformulation of an already-established obligation
does NOT turn ✓ into ✓*
```

`✓*` is specifically about propositions that never became obligations.

---

## 6. Major conceptual correction: an Obligation is already established

A key confusion was resolved.

We initially considered:

```text
Obligation
  pending
  established
  abandoned
```

This was rejected.

If something is called an `Obligation`, it should already imply:

```text
established
normatively in force
```

Therefore there should be no:

```text
pending Obligation
staged Obligation
established-but-not-operative Obligation
```

Those concepts were artificial and should be removed.

---

## 7. Evidence belongs in Obligation

We also refined the relation between proof/evidence and obligation.

The preferred conceptual shape is:

```agda
record Obligation (p : Proposition) : Set₁ where
  field
    evidence : Evidence p
```

or equivalently, at the Curry–Howard level:

```text
Proposition = statement/type
Obligation  = proposition + evidence/proof
```

So:

```text
Obligation(P)
=> P has sufficient evidence
=> P is established
=> P has normative force
```

No separate:

```text
established : Bool
```

is needed.

---

## 8. Why Proposition exists

We temporarily considered `ObligationSpec`, but rejected the name.

`Proposition` is the better concept.

Reason:

Before something becomes an Obligation, the Governance still needs to declare what it intends to establish.

Conceptually:

```text
Governance
    ↓ declares
Proposition
    ↓ evidence/proof
Obligation
```

A Proposition is simply the governed statement.

In Agda/Curry–Howard terms:

```agda
P : Set
proof : P
```

The project-level `Proposition` may carry identity/origin, but it should not become an unnecessarily heavyweight domain abstraction.

Preferred identity shape:

```text
P(GV100, 0)
P(GV100, 1)
P(GV100, 2)
```

rather than immediately inventing an unrelated global proposition identifier space.

---

## 9. Abandonment belongs before Obligation

If a proposition is discarded before it becomes an Obligation:

```text
P -> abandoned
```

That is not a disposition of an Obligation because the Obligation never existed.

This clarified the semantic distinction:

```text
abandoned
= the proposition never became an obligation

withdrawn
= the proposition did become an obligation,
  and that normative force was later intentionally removed
```

We briefly considered:

```text
abandoned : Bool
```

and agreed the semantics are essentially boolean/monotonic.

However, implementation provenance can be decided later.
We explicitly rejected overcomplicating this with ugly structures such as:

```text
Maybe Abandonment
```

unless later implementation needs provenance.

---

## 10. Unification: Disposition moved to Proposition

The user proposed that a common `Disposition` might cover both pre-obligation and post-obligation outcomes.

We agreed this is a useful simplification.

Instead of:

```text
Proposition
  └── abandoned

Obligation
  ├── preserved
  ├── reformulated
  └── withdrawn
```

use one indexed concept:

```text
Disposition P
├── abandoned
├── preserved
├── reformulated
└── withdrawn
```

But with typed validity conditions:

```text
abandoned
  only valid if no Obligation P ever existed

preserved
  requires Obligation P

reformulated
  requires Obligation P

withdrawn
  requires Obligation P
```

Conceptual Agda shape:

```agda
data Disposition (p : Proposition) : Set₁ where

  abandoned :
    NoObligation p ->
    Disposition p

  preserved :
    Obligation p ->
    Disposition p

  reformulated :
    Obligation p ->
    (next : Proposition) ->
    Disposition p

  withdrawn :
    Obligation p ->
    Disposition p
```

Exact syntax is NOT finalized.

The key reason for indexing by Proposition:

> Proposition is the entity that exists both before and after establishment.

Obligation remains semantically important because some dispositions require one.

---

## 11. Meaning of `Disposition` on a Proposition

We explicitly questioned whether the name still makes sense after moving the index from Obligation to Proposition.

Conclusion:

Yes, provisionally.

Definition:

> **Disposition = the constitutional destiny of a governed Proposition.**

Important semantic clarification:

```text
withdrawn P
```

does NOT mean:

```text
P became false
```

It means:

```text
P ceased to be constitutionally required.
```

Likewise:

```text
abandoned P
```

means:

```text
P never acquired constitutional obligation force.
```

Alternative names considered:

```text
Resolution
Outcome
Transition
Status
Fate
ConstitutionalDisposition
```

`Disposition` remained the preferred short name.

---

## 12. Current preferred semantic spine

The cleanest topology reached in this session is:

```text
Governance
    ↓ declares
Proposition
    ↓ evidence/proof
Obligation
    ↓ constitutional evolution
Disposition
```

More explicitly:

```text
Governance
    |
    +-- Proposition P0
    |
    +-- Proposition P1
    |
    +-- Proposition P2
```

For each Proposition:

```text
no Obligation
no Disposition
=> pending

Disposition = abandoned
=> abandoned before establishment

Obligation exists
=> established / normatively in force

after Obligation exists:
Disposition may be:
  preserved
  reformulated
  withdrawn
```

Derived pending rule:

```text
pending(P)
=
  no Obligation(P)
  AND
  no Disposition(P)
```

This is cleaner than storing `pending`.

---

## 13. Derived Governance glyphs

Given all propositions declared by a Governance:

```text
◇
= exists pending Proposition

✓
= all Propositions have Obligations
  and none were abandoned

✓*
= no pending Proposition
  + at least one Proposition has an Obligation
  + at least one Proposition is abandoned

×
= all Propositions are abandoned
```

Important invariant:

```text
Obligation(P)
and
abandoned(P)
```

must be impossible.

---

## 14. Replacement/supersession interaction was partially explored

The previous model had introduced confusing notions such as:

```text
staged
operative
established but non-operative
```

Those were explicitly rejected.

Corrected rule:

> If an Obligation exists, it is already established and normatively in force.

Before a replacement cutover, the replacement Governance may have Propositions and evidence may be prepared, but no successor Obligation should exist yet if establishing it would prematurely create normative force.

So:

```text
GV10
└── P10 -> O10

GV100
└── P100
```

With:

```text
GV10 ↝ GV100
```

we may prepare evidence for `P100`, but:

```text
O100
```

should not exist until the effective constitutional transition if it would conflict with `O10`.

This means:

```text
proof/evidence readiness
!=
Obligation existence
```

because Obligation creation itself is the constitutional establishment.

---

## 15. Effective supersession as atomic constitutional transition

The promising direction is to treat:

```text
GV10 ↪ GV100
```

as an atomic constitutional cutover.

For reformulation:

```text
before:
O10 exists
P100 declared
evidence100 available

transition:
create O100
Disposition P10 = reformulatedAs P100/O100

after:
O10 remains historical
O100 is now the active obligation
```

This prevents:

```text
gap with no obligation
```

and prevents:

```text
premature simultaneous incompatible obligations
```

Exact activation mechanics are still NOT finalized.

---

## 16. Preserved / reformulated / withdrawn semantics

Current intended meanings:

### preserved

The same obligation survives.

Potentially:

```text
origin(O10) = GV10
currentResponsibility(O10) = GV100
```

after:

```text
GV10 ↪ GV100
Disposition P10 = preserved
```

No artificial new obligation identity is needed if the normative statement is literally preserved.

### reformulated

A new Proposition/Obligation identity replaces the old one.

Example:

```text
P47 = "use ✓/○"
P68 = "use ✓/◇"

Disposition P47 =
  reformulatedAs P68
```

Possible split:

```text
P10 -> [P100, P101]
```

Possible merge:

```text
P10 \
P20  -> P100
P30 /
```

Exact arity/type representation remains open.

### withdrawn

The proposition had an Obligation and later intentionally ceases to be constitutionally required.

No successor obligation is required.

Important:

```text
missing coverage
!= withdrawn
```

Withdrawal must be explicit/governed.

---

## 17. Abandoned vs withdrawn — final distinction from this session

This distinction is now central:

```text
abandoned
= proposition never became an obligation

withdrawn
= proposition did become an obligation
  and later ceased to have normative force
```

This is cleaner than treating both as generic lifecycle states.

---

## 18. Real cases under the new model

### GV47 -> GV68

Old:

```text
P47 = use ✓/○
O47 existed
```

New:

```text
P68 = use ✓/◇
```

Likely:

```text
Disposition P47 =
  reformulatedAs P68
```

### GV49 -> GV69

Old:

```text
P49 = ■/▶/□
```

New:

```text
P69 = ■/▣/□
```

Likely:

```text
reformulated
```

### GV48 -> GV70

GV70 is semantically stronger than GV48.

Likely still:

```text
reformulated
```

with a proof that the new proposition implies the old proposition:

```text
P70 -> P48
```

“strengthened” should probably be a derived relation/property, not a primitive disposition constructor.

### GV77 -> GV95

GV77 was not completed.

Under the new model:

```text
its declared proposition(s) never became obligations
```

so effective replacement would likely give:

```text
Disposition P77 = abandoned
```

rather than pretending a non-existent obligation was superseded.

This is a major improvement over the old:

```text
todo -> superseded(todo)
```

state transition.

---

## 19. Current preferred topology

```text
                         Constitution
                              |
                         Governance
                              |
                           declares
                              |
                              v
                         Proposition
                         /          \
                        /            \
              evidence/proof      Disposition
                    |             /    |    |    \
                    v      abandoned preserved reformulated withdrawn
               Obligation
```

Typed restrictions:

```text
abandoned
  requires no Obligation existed

preserved
  requires Obligation existed

reformulated
  requires Obligation existed

withdrawn
  requires Obligation existed
```

Derived:

```text
pending
◇ ✓ ✓* ×
current responsibility
OperativeConstitution
GovernanceDelta
```

None of those need to be fundamental lifecycle enums.

---

## 20. Important concepts removed during this session

Do NOT reintroduce these without strong justification:

```text
ObligationState
pending Obligation
staged Obligation
established-but-not-operative Obligation
GV fundamental ItemState
Maybe Abandonment
```

The session explicitly moved away from these because they duplicated or blurred semantics.

---

## 21. Naming decisions currently preferred

Use:

```text
Governance
Proposition
Obligation
Disposition
Replacement
```

Avoid for now:

```text
ObligationSpec
```

`Proposition` was preferred because:

- it matches the logical meaning;
- it exists before proof/evidence;
- it maps naturally to Agda `Set`;
- it is the common identity across pre- and post-establishment history.

`Disposition` remains acceptable as:

```text
constitutional destiny of a governed Proposition
```

---

## 22. Open questions for the next session

Do NOT implement yet.

### A. Exact Proposition type

Need to study:

```text
How is Proposition identified?
Is identity structurally derived as P(GV, slot)?
What exactly is Statement : Set?
Does Proposition carry only identity + Statement?
```

### B. Exact Obligation type

Likely:

```text
Obligation P
  contains evidence/proof of P
```

Need to determine how this fits current:

```text
StaticEvidence
ObservedEvidence
CompletionAssurance
```

### C. Exact Disposition type

Need to formalize:

```text
abandoned
preserved
reformulated
withdrawn
```

with type-level validity conditions.

Questions:

```text
Does reformulated target Proposition(s) or Obligation(s)?
How are split/merge represented?
Does preserved move responsibility without changing ObligationId?
```

### D. Planned vs effective Replacement

Need to define precisely:

```text
↝ planned replacement
↪ effective replacement
```

without creating premature Obligations.

A planned replacement should have no operative effect.

### E. Effective replacement atomicity

Need to decide whether an effective replacement transaction contains:

```text
new Obligation establishment
+
old Proposition dispositions
+
responsibility transfer
```

as one typed transition.

### F. Current responsibility / OperativeConstitution

Need to formalize:

```text
currentResponsibility : Obligation -> Governance
```

or equivalent.

Preserved chains should derive transitively without GV dependency DAGs.

### G. Governance glyph derivation

Formalize:

```text
◇
✓
✓*
×
```

from Propositions / Obligations / Dispositions.

`✓*` must identify abandoned propositions in documentation/projection.

### H. Delta redesign

Likely direction still:

```text
GovernanceDelta
├── Proposition/Obligation impacts
├── Replacement relation impacts
└── Phase progress
```

Supersession should no longer be an `ItemProgress`.

---

## 23. Design principles currently agreed

```text
1. Governance history remains append-only.

2. Governance should not own a fundamental lifecycle state.

3. Governance declares Propositions.

4. Proposition is the governed logical statement.

5. Obligation means a Proposition has been established with evidence/proof.

6. Therefore an Obligation is already normatively in force.

7. There is no pending/staged/non-operative Obligation.

8. Pending is derived:
   no Obligation + no Disposition.

9. Disposition is indexed by Proposition.

10. abandoned:
    Proposition never became an Obligation.

11. preserved/reformulated/withdrawn:
    require that an Obligation existed.

12. withdrawn:
    established obligation intentionally ceases to govern.

13. abandoned:
    intended proposition is intentionally not established.

14. Missing handling is never implicit withdrawal/abandonment.

15. Governance glyphs are derived:
    ◇ ✓ ✓* ×.

16. ✓* means resolved Governance with at least one abandoned Proposition.

17. Replacement planning has no operative effect.

18. Effective replacement should be modeled as a typed constitutional transition.

19. No general GV dependency graph.

20. Obligation lineage, not GV dependency, is the long-term graph.

21. Delta is derived from typed constitutional transition.

22. CHANGELOG / PR / Release only project the typed delta.
```

---

## 24. Suggested next work sequence

Resume with a **formal type-design spike only**.

### Step 1 — candidate minimal types on paper

Study candidate shapes for:

```text
Governance
Proposition
Obligation
Disposition
Replacement
```

Avoid implementation changes.

### Step 2 — derive glyphs

Prove the classification logic for:

```text
◇ ✓ ✓* ×
```

including multi-proposition GVs.

### Step 3 — exercise the four real supersessions

Use:

```text
47 -> 68
49 -> 69
48 -> 70
77 -> 95
```

under the new Proposition/Obligation/Disposition model.

### Step 4 — close replacement matrix

Test:

```text
planned replacement
planned replacement abandoned
effective replacement
replacement of already-completed Governance
replacement of unresolved Governance
preserved obligation
reformulation
withdrawal
abandonment
chain
split
merge
replacement-of-replacement
```

### Step 5 — define OperativeConstitution

Only after the above semantics are stable.

### Step 6 — only then create new governance items

Because GV54 makes definitions immutable, do not constitutionalize the model prematurely.

---

## 25. No repository changes made

This entire session was design analysis only.

No new GV was added.  
No branch or PR was created.  
No kernel code was modified.  
No release was created or triggered.  
No local user changes were overwritten.

The next session should resume from:

> **Formal candidate types for Governance → Proposition → Obligation → Disposition, then replacement activation.**
