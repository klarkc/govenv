# Govenv session handoff — assurance / GV71–GV74 / materialization

Date: 2026-09-23
Repository: `klarkc/govenv`
Local repo: `/home/klarkc/Sources/klarkc/govenv`

## Purpose

Continue in a clean session without losing the governance decisions, Git state, assurance architecture, materialization decisions, release constraints, and exact unfinished work from this session.

Do not assume unfinished work is valid merely because a file exists. Re-check the repository state before continuing.

## Operating rules

- Discussion in Portuguese; source code and commit messages in English.
- Use Desktop Commander for local repo work and GitHub connector for GitHub state.
- Do not use Python for repo work.
- Before creating/tagging/publishing a new release, notify the user and ask approval.
- Never claim full validation unless it actually ran successfully.
- GV71 wording is frozen: **do not change GV71 anymore**.

## Core governance model agreed

GVs are cumulative, ADR-like governance decisions.

A new GV is interpreted in the context of all preceding still-effective governance. A generic dependency graph is therefore not required by default.

A GV may be completed in any order if its proposition is actually satisfied under the full preceding governance context.

Semantic dependencies should normally emerge from the proposition itself, not metadata such as `dependsOn`.

Example: GV32 cannot truthfully become done if its proposition requires a working incremental checker from GV31 and no such evidence exists.

Cross-GV references remain appropriate when the semantic rule itself names another GV, e.g. GV71's temporary bootstrap exception lasting until GV38 is completed.

The previously suggested “GV74 = explicit dependency graph” idea was discarded.

## Critical discovery: `✓` cannot remain a manual checkbox

Historically, someone could change a GV from `◇` to `✓` without the roadmap proving that the proposition had become true.

A completed GV must instead mean:

> This governance proposition has governed evidence establishing it for the candidate repository state, and it remains an invariant in all subsequent valid states until superseded.

Two properties matter:

1. historical immutability — a past `✓` cannot silently regress;
2. persistent truth — the repository must continue satisfying every live completed GV.

The second property was the missing foundation.

## GV73

Current text:

```text
GV 73 "Require every persisted supporting artifact, including snapshots, fixtures, baselines, schemas, test vectors, and evidence, to be colocated with the module that semantically owns it; catch-all artifact directories are forbidden unless the artifact is genuinely project-global." ◇
```

Intent:

- fixtures, snapshots, baselines, schemas, test vectors, generated expectations, evidence, etc. live with their semantic owner;
- avoid catch-all `.govenv`, `.snapshots`, `.fixtures`, `test-data`, etc.;
- truly project-global artifacts are the exception;
- final materialized targets may still live at their required target path.

## GV74

Current text:

```text
GV 74 "Make governance completion evidence-bearing and persistent: a governance item may transition to `done` only when governed evidence establishes its proposition for the candidate repository state, and every non-superseded `done` item, including items completed before this rule, must remain satisfied in every subsequent valid repository state." ◇
```

GV74 is **not done**.

Do not mark it done until:

- every historical completed GV has been migrated away from legacy escape hatches;
- candidate-state assurance is wired so observed rules must actually hold;
- completion coverage checks the project roadmap;
- subsequent repository states continuously re-establish live completed GVs.

## GV71 — frozen wording

Do **not** change this text:

```text
GV 71 "Restrict handwritten versioned repository content to Agda and Markdown only. Any generated or governed materialization may use its required target format. Until GV38 is completed, the only handwritten bootstrap escape hatch is root-level `devenv.nix`, `devenv.yaml`, and `devenv.lock`; all other implementation languages and handwritten configuration formats, including Nix elsewhere, are forbidden." ◇
```

Meaning:

- handwritten tracked source may be Agda or Markdown;
- temporary root bootstrap exception: `devenv.nix`, `devenv.yaml`, `devenv.lock`;
- other tracked target formats must be governed materializations;
- generated/materialized targets may use whatever target format is required.

## GV72

Current text:

```text
GV 72 "Require every versioned repository artifact not permitted as handwritten source by GV71, except the temporary root-level `devenv.nix`, `devenv.yaml`, and `devenv.lock` bootstrap escape hatch, to be produced by exactly one governed `Govenv.Materialization.*` definition and verified against its materialized state; transient `.govenv` state is forbidden from being versioned." ◇
```

Architecture:

- handwritten versioned source: Agda + Markdown only;
- temporary bootstrap: root `devenv.{nix,yaml,lock}`;
- every other tracked artifact must have exactly one canonical `Govenv.Materialization.*`;
- `.govenv` must disappear as a versioned catch-all;
- generated output is not automatically compliant: it must be a governed materialization.

## Materialization model

`Govenv.Materialization.*` is the canonical semantic owner.

GV51 base rule: every materialized state has exactly one canonical `Govenv.Materialization.*` definition containing semantic content, structure, ordering, inclusion, policy, and required capability decisions. Projections only encode target-format representation. Adapters only observe, apply, or verify effects.

Target mapping direction:

- `.github/workflows/test.yml` → `Govenv.Materialization.Github.Workflows.Test`
- `.github/workflows/pages.yml` → `Govenv.Materialization.Github.Workflows.Pages`
- `.github/workflows/release.yml` → `Govenv.Materialization.Github.Workflows.Release`
- `.github/workflows/materialize.yml` → `Govenv.Materialization.Github.Workflows.Materialize`
- `.github/workflows/admin-materialize.yml` → `Govenv.Materialization.Github.Workflows.AdminMaterialize`
- `.github/release-please/config.json` → likely `Govenv.Materialization.Github.ReleasePlease.Config`
- `.github/release-please/manifest.json` → likely `Govenv.Materialization.Github.ReleasePlease.Manifest`
- `.gitignore` → `Govenv.Materialization.Gitignore`
- `LICENSE` → `Govenv.Materialization.License`
- README already → `Govenv.Materialization.Readme`

Do not move semantic policy into YAML/JSON/Nix/shell merely to satisfy generation mechanically.

## `.govenv` decision

- versioned `.govenv/roadmap.snapshot` must go away;
- preferably `.govenv` disappears entirely rather than becoming a generic scratch directory;
- transient build state should use proper temporary/build locations;
- persisted support artifacts should follow GV73 colocation.

Release governance should derive previous typed roadmap state from Git history/revisions, not from a tracked `.govenv/roadmap.snapshot`.

GV70 does not need supersession merely because the persisted snapshot file disappears; a typed roadmap snapshot can be derived in memory from old/current Git revisions.

## Shell adapters

Tracked handwritten shell files still exist:

- `src/Govenv/Adapter/release-governance-pr.sh`
- `src/Govenv/Adapter/release-governance.sh`
- `src/Govenv/Adapter/roadmap-evolution.sh`

These conflict with intended GV71/GV72 architecture.

Do not grandfather them.

Preferred direction:

- move semantics/computation into Agda;
- keep adapters limited to irreducible observation/effects;
- generated shell inside a materialized workflow is acceptable only as target encoding/effect glue;
- root `devenv.nix` may temporarily perform Stage-0 orchestration, but semantic decisions stay governed.

## Assurance architecture

The assurance work was refactored so `Govenv.Roadmap` does **not** depend on `Govenv.Assurance`.

Reason: assurances may depend on roadmap/materializations, so the reverse dependency created a cycle.

Correct direction:

```text
Govenv.Roadmap
      ↓
Govenv.Assurance
      ↓
closure root proves completed-item coverage
```

`Govenv.Assurance` imports the roadmap and establishes:

```agda
projectCompletionCovered : completionCoverage assurances roadmap ≡ true
```

This keeps the roadmap ADR-like while making unassured `✓` fail the project closure.

## Assurance kernel concepts implemented

- `StaticEvidence idx`
  - carries an Agda proposition and proof;
- `ObservedEvidence idx`
  - carries Subject, Observation, dependencies, Diagnostic, Obligation, and a governed `Rule`;
- `CompletionAssurance`
  - `inherited`
  - `statically`
  - `checked`
- `ObservedWitness`
  - contains candidate `Facts`;
  - contains proof that `Rule.check rule facts ≡ holds`;
- `CandidateEvidence`
  - static evidence can establish directly;
  - observed evidence requires an `ObservedWitness`;
  - there is intentionally **no constructor for inherited completions**.

Also implemented and validated:

```agda
establishObserved
```

It evaluates the governed rule against facts and produces:

- `just ObservedWitness` only for `holds`;
- `nothing` for `violated`;
- `nothing` for `unknown`.

The equality proof is obtained from Agda's `with ... in verdictEquality`, not a postulate.

## Gating semantics demonstrated

- a pending GV without assurance is allowed;
- the same GV switched to `✓` without assurance makes completion coverage false;
- project completion coverage currently succeeds because historical done items still have either real or legacy assurance entries.

This is transitional, not final GV74 compliance.

## Historical completed GVs already migrated to real static assurance

Dedicated modules exist for:

- GV3
- GV4
- GV5
- GV6
- GV15
- GV16
- GV20
- GV21
- GV50
- GV52
- GV54
- GV68
- GV69
- GV70

They live under `Govenv/Assurance/GV<N>.lagda.md`.

Highlights:

- GV52 proves rejection of duplicate GV IDs, backward phase order, pending items in finished phases, and acceptance of a valid progression;
- GV54 proves rejection of removal, definition mutation, phase mutation, completion regression, reopening cancellation, and supersession-target mutation;
- GV70 covers release-delta classifications and keeps SemVer independent;
- GV15/GV16 cover README projection/materialization structure;
- GV20/GV21 cover project identity and canonical description projection.

## Remaining historical legacy completions

Exactly these 9 remained inherited:

- GV0
- GV1
- GV2
- GV19
- GV22
- GV44
- GV45
- GV51
- GV60

This is intentional: these are mostly repository/workflow/materialization facts and should not be “proved” with fake `⊤` evidence.

They need real observed or structural assurance over candidate repository/external state.

## GV60 — work stopped mid-file

User explicitly said to stop while GV60 was being implemented.

Current file:

```text
Govenv/Assurance/GV60.lagda.md
```

is untracked / not committed and **incomplete / not validated**.

Current design direction:

- subject: `readmeFile`;
- observation: `String`;
- dependency: README file;
- diagnostic: `readmeDrift`;
- rule compares observed README contents to canonical `renderReadme`;
- exact equality → `holds`;
- mismatch → `violated readmeDrift`;
- defines `ObservedEvidence 60`;
- defines `candidateFacts : String → Facts ...`.

Do **not** assume this file typechecks. Read it first.

The intended next step was an Agda adapter that only performs IO to read candidate `README.md`, then feeds the string to the pure rule / `establishObserved`.

GV59 boundary:

- reading the file is effect/observation;
- deciding whether it is correct belongs to the pure governed rule;
- no comparison/policy should be hidden in FFI/shell.

## Local Git state at handoff

Latest confirmed local history:

```text
b50e8ef gov(assurance): require candidate witnesses
419c35c gov(assurance): separate completion evidence
faa1e59 gov(assurance): gate completed governance
37255ae gov(release): classify terminal introductions
ed1c61c gov(release): clarify governance impact
03b2d54 gov(roadmap): preserve immutable governance history
```

At latest check, local `main` was `0 behind / 3 ahead of origin/main`.

The three assurance commits were local only:

- `faa1e59`
- `419c35c`
- `b50e8ef`

Do not assume this is still true in a new session: run `git status` and compare local vs remote before acting.

No push was performed for those assurance commits in this session.

## Current uncommitted working tree at handoff

Latest confirmed status:

```text
 M Govenv/Materialization.lagda.md
 M Govenv/Materialization/ReleaseGovernance.lagda.md
 M src/Govenv/Kernel/Assurance.agda
?? Govenv/Assurance/GV60.lagda.md
```

### `Govenv/Materialization.lagda.md`

Pending rename:

```agda
afterReleasePleaseBody
```

→

```agda
afterReleaseHeadingInBody
```

### `Govenv/Materialization/ReleaseGovernance.lagda.md`

Consumer updated to use `afterReleaseHeadingInBody`.

These materialization changes predate the final assurance work and were intentionally kept out of assurance commits.

### `src/Govenv/Kernel/Assurance.agda`

Contains uncommitted `establishObserved`.

This part **did** typecheck at the root before stopping.

### `Govenv/Assurance/GV60.lagda.md`

New untracked, incomplete, not validated.

## Validation history

Successful during the session:

- root `Govenv.lagda.md` typechecked after assurance separation;
- root typechecked after migrating GV15/16/20/21/54/70;
- root typechecked after `CandidateEvidence`;
- root typechecked after `establishObserved` using `with ... in verdictEquality`;
- individual assurances such as GV54, GV70, GV15 also typechecked.

Caveats:

- do not claim full `devenv test` passed;
- latest GV60 file was not validated;
- current working tree after GV60 creation was not revalidated as a whole;
- `devenv` commands sometimes modified `devenv.lock` incidentally; restore such noise if it appears.

## GitHub release PR #2

Release Please PR:

```text
https://github.com/klarkc/govenv/pull/2
```

Latest checked state:

- open;
- not merged;
- mergeable;
- release target 0.2.0.

Do **not** approve/merge it yet.

Known problem: governance impact currently appears before the Release Please bot text/release heading.

Current shape:

```text
## Governance impact
...
🤖 I have created a release...
## [0.2.0] ...
```

Desired:

```text
🤖 I have created a release...

## [0.2.0] (...)

### Governance impact
...

### Features
...
```

Local placement rename is part of fixing that, but insertion behavior still needs verification.

Tell the user when the release PR is ready for review/approval. Never merge/tag/publish without approval.

## Release governance architecture

Current release delta model:

- based on typed roadmap state;
- distinguishes introduced, advanced, completed, cancelled, superseded, and phase progression;
- rejects governance identity mutation/removal;
- SemVer remains independent.

`src/Govenv/Kernel/Release.agda` correctly classifies identities first observed in terminal state as cancelled/superseded rather than introduced.

A persisted `.govenv/roadmap.snapshot` implementation remains in the codebase, but intended architecture is Git-history-derived typed state.

## Current tracked inventory requiring GV71/GV72 cleanup

Non-Agda/Markdown/bootstrap tracked files included:

```text
.github/release-please/config.json
.github/release-please/manifest.json
.github/workflows/admin-materialize.yml
.github/workflows/materialize.yml
.github/workflows/pages.yml
.github/workflows/release.yml
.github/workflows/test.yml
.gitignore
.govenv/roadmap.snapshot
LICENSE
src/Govenv/Adapter/release-governance-pr.sh
src/Govenv/Adapter/release-governance.sh
src/Govenv/Adapter/roadmap-evolution.sh
```

Required direction:

- workflows → governed materializations;
- release-please JSON → governed materializations;
- `.gitignore` → governed materialization;
- `LICENSE` → governed materialization;
- `.govenv/roadmap.snapshot` → remove;
- handwritten `.sh` adapters → remove/reimplement with Agda semantics/effect boundary.

Do not mark GV71/GV72 done before the repository genuinely conforms and enforcement exists.

## Supersession policy

There is no amended state.

Once committed, a GV's identity, definition, and owning phase are immutable and it cannot be removed.

Obsolete without replacement → cancelled.

Corrected/replaced → superseded by a newer existing GovernanceId.

Relevant chains:

```text
47 → 68
49 → 69
9 → 57
10 → 58
11 → 59
17 → 61 → 62
14 → 60
23 → 63
48 → 70
7 → 55
8 → 56
25 → 64
27 → 65
28 → 66
40 → 67
```

## Recommended next-session order

1. Connect Desktop Commander and GitHub.
2. Run `git status` and compare local `main` to `origin/main`.
3. Read:
   - `Govenv/Assurance/GV60.lagda.md`
   - `src/Govenv/Kernel/Assurance.agda`
   - `Govenv/Assurance.lagda.md`
4. Confirm the uncommitted materialization placement rename still exists.
5. Do **not** modify GV71.
6. Finish GV60 as the first real observed invariant:
   - pure rule compares candidate README to `renderReadme`;
   - adapter only observes file contents;
   - produce candidate witness only on `holds`;
   - add regression showing drift cannot establish evidence.
7. Wire observed candidate evidence into global assurance validation.
8. Migrate remaining legacy completions one by one using real evidence, not `⊤` placeholders:
   - GV0, GV1, GV2, GV19, GV22, GV44, GV45, GV51, GV60.
9. `migrationComplete assurances` must eventually become `true`.
10. Only then consider completing GV74.
11. After GV74 foundation is correct, resume:
   - GV73 artifact ownership/colocation;
   - GV71/GV72 repository-wide materialization cleanup;
   - `.govenv` removal;
   - shell adapter elimination;
   - workflow/JSON/gitignore/LICENSE materialization.
12. Fix/revalidate release-governance placement.
13. Run targeted Agda/root validation and `git diff --check`.
14. Commit with English message and appropriate `Refs: GV...`.
15. Push only after local state is coherent.
16. Reinspect PR #2 and tell the user when ready for approval.
17. Do not merge/release without explicit approval.

## Architectural warning

Do not weaken GV74 into “there is an assurance object with the same ID”.

Coverage by ID is necessary but not sufficient.

Final semantics must distinguish:

```text
completed GV has assurance definition
```

from:

```text
completed GV is established for THIS candidate state
```

Static assurances are established by their Agda proof.

Observed assurances are established only by candidate facts causing the governed rule to return `holds`, producing an `ObservedWitness`.

Historical `inherited` entries are migration debt and cannot be accepted as final candidate evidence.

That distinction is the central architectural result of this session.
