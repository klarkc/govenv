# Govenv session handoff — 2026-09-15 — GV95 / canonical Unreleased

## Critical rule
Never merge a PR or create/publish a GitHub Release without explicit user approval. Generic “ok”, “continue”, “prossiga”, or “e agora?” is not authorization. PR #15 must remain open/unmerged until the release/changelog architecture is corrected and reviewed.

## Current state
Repo: `klarkc/govenv`
Main/base: `a85ba42f29f472dc1afe6302c181b01a2a8ac440` (`gov(roadmap): derive current state`), after merged GV94.

Clean worktree created for this task:
- `/home/klarkc/Sources/klarkc/govenv-unreleased-history`
- branch `gov/unreleased-history`
- based on `origin/main` at `a85ba42`

Do not use/revert the original dirty worktree `/home/klarkc/Sources/klarkc/govenv`.

Older exploratory worktree:
- `/home/klarkc/Sources/klarkc/govenv-release-history-fix`
- branch `fix/release-governance-history`
- older base `733c812`
- contains a symptom-level historical-preservation experiment and useful counterexample
- inspect only as reference; do not automatically commit/push it.

## GV94
PR #14 was merged by the user. GV94 makes roadmap Current/README state derived from typed roadmap and prevents an active phase with no non-terminal work. Materialize #38 passed completely with zero drift.

## PR #15
Release Please PR #15:
`https://github.com/klarkc/govenv/pull/15`
Title: `chore(main): release 0.2.2`.
It includes GV94 in Governance Impact.
DO NOT MERGE YET.

## Changelog regression still on main
Current main has the 0.2.1 Governance Impact but the historical 0.2.0 Governance Impact disappeared. At SHA `30fc755`, 0.2.0 still contained it.

Root cause: `src/Govenv/Adapter/release-governance-pr.sh`.

Its `strip_section()` globally removes every `<!-- govenv-governance-impact:start --> ... end` block before inserting the current release block. `verify_section_at_release` also wrongly requires global marker count == 1.

The Agda target itself was already version-specific:
`repositoryFileSection "CHANGELOG.md" ... (afterReleaseHeadingInFile releaseVersion)`.
Therefore the formal target and shell adapter disagree. This is a real observed regression relevant to GV84.

## Architectural decision: canonical Unreleased
We decided not to merely patch `strip_section()`.

Release Please owns:
- Conventional Commit analysis
- SemVer choice
- opening/updating release PR
- manifest/version lifecycle
- tag/release coordination

Govenv owns:
- canonical `CHANGELOG.md`
- canonical `Unreleased`
- typed release semantics / Governance Impact
- immutable/reconstructible historical release entries
- freezing Unreleased into the Release Please candidate version before human approval
- PR and GitHub Release projections of the same typed document
- external read-back equality

Conceptually:
`Unreleased = f(lastPublishedRelease, currentAuthorizedRevision)`
`Released[X] = f(previousReleaseBoundary, X)`

Example ongoing main:
```
## [Unreleased]
... changes since v0.2.1 ...

## [0.2.1]
... immutable historical entry ...

## [0.2.0]
... immutable historical entry ...
```

When Release Please chooses e.g. 0.3.0, Govenv deterministically freezes that candidate on the release PR before human approval:
```
## [Unreleased]

## [0.3.0]
... exact candidate content ...

## [0.2.1]
...
```

If main changes while the release PR is open, Release Please may refresh version/candidate and Govenv re-derives deterministically.

## Work done in this session
Inspected:
- `Govenv/Roadmap.lagda.md`
- `Govenv/Release.lagda.md`
- `Govenv/Materialization/ReleaseGovernance.lagda.md`
- `Govenv/Materialization/Github/Workflows/Release.lagda.md`
- `src/Govenv/Adapter/release-governance.sh`
- `src/Govenv/Adapter/release-governance-pr.sh`
- `.github/release-please/config.json`

Current Release Please config still normally owns changelog generation and has `changelog-sections`. Verify the supported Release Please v5 option/syntax for disabling changelog changes before editing it; do not guess.

### Local GV95 draft
Because governance identities are immutable, GV77 was not mutated. In the clean worktree it is locally superseded by GV95:

```
GV 77 ... ↪ GVR 95
GV 95 "Make Govenv the sole semantic owner of the canonical changelog: derive `Unreleased` deterministically from the latest published release boundary to the current authorized revision, preserve every historical release entry immutably and reconstructibly, and freeze that exact derived state into the Release Please candidate version before human approval. Release Please may determine SemVer and coordinate the candidate/tag/release lifecycle but may not independently author changelog semantics; the pull-request body and published GitHub Release must project the same authorized typed release document and external publication must be verified by read-back equality." ◇
```

At session end `git status --short` in the clean worktree showed only:
` M Govenv/Roadmap.lagda.md`

No commit, push, or PR was created for GV95.

## Next design review
Before implementing heavily, check whether GV95 is too broad and should become GV95/GV96/etc. Possible separable obligations:
1. sole Govenv ownership + typed Unreleased
2. immutable/reconstructible release history
3. Release Please SemVer/lifecycle-only ownership
4. candidate freeze before human approval
5. same typed document projected to PR/release + read-back
6. deterministic race/update semantics while release PR is open

Review coherence with GV77, GV84, GV86, GV87, GV90, GV91 and GV94. Since GV77 is todo, superseding it is consistent with immutable-GV policy.

## Counterexample requirement
The actual 0.2.0-loss regression must become persistent governed evidence.

Observed bad state:
- main around `733c812`
- 0.2.1 impact present
- 0.2.0 impact absent
- Materialize #37 passed with zero drift

The exploratory worktree has:
`Govenv/Materialization/ReleaseGovernance/history-preservation-counterexample.md`
and an experimental adapter correction that preserved history, restored 0.2.0 byte-for-byte from immutable v0.2.0, and passed placement/history/push-auth fixtures. Reuse the evidence idea, not necessarily that implementation.

Corrected assurance must establish:
- candidate materialization cannot erase historical entries
- historical entries are reconstructible from immutable revision-addressable boundaries
- verification is release-specific, not globally one marker
- the observed 0.2.0-loss state is rejected before release workflow succeeds

## Existing release model
`Govenv/Materialization/ReleaseGovernance.lagda.md` currently defines a Governance-Impact-focused `ReleaseDocument` with three section targets:
- `pullRequestBody`
- `changelog`
- `githubRelease`

The changelog target is only a section beneath a release heading, not full changelog ownership. This needs redesign.

`src/Govenv/Adapter/release-governance.sh` already:
- finds previous tag/release base
- loads typed previous roadmap snapshot
- gathers governed `Refs: GV…` commits
- generates Agda observation
- compiles body/changelog/release projections

This machinery may remain useful as input/delta derivation.

Release workflow currently:
1. check repository
2. run Release Please
3. if PR created, run `release-governance-pr.sh`
4. if release created, run `release-governance-release.sh`

Eventually candidate branch must contain the deterministic Govenv freeze before human approval.

## Stage B / authority
Stage A complete. Stage B mostly proven: AuthorizedRevision binding, tests, Pages, Release Please branch mutation via ephemeral explicit Git credential bridge, governance read-back, published-release read-back.

Still not live-proven: deterministic derived-main push through deploy key `govenv-materializer`; runs #35–#38 had zero drift and skipped the commit. Canonical Unreleased may naturally exercise this. Do not fabricate drift just to test it.

Stage C remains inactive.

Preserve release branch credential architecture:
- checkout `persist-credentials: false`
- token not embedded in remote
- no persistent credential helper
- temporary GIT_ASKPASS only for specific push
- `BASH_ENV=/dev/null`
- read-back verification

## Original dirty worktree
`/home/klarkc/Sources/klarkc/govenv` had unrelated modified/untracked files including `src/Govenv/Kernel/Assurance.agda` and `Govenv/Assurance/GV60.lagda.md`. Do not overwrite/revert them.

## Recommended next actions
1. Resume `/home/klarkc/Sources/klarkc/govenv-unreleased-history`.
2. Confirm status/base.
3. Re-read GV77/GV84/GV86/GV87/GV90/GV91/GV94 and release model.
4. Globally review GV95 scope; split if formal coherence is better.
5. Preserve the real historical-loss counterexample.
6. Design typed changelog state: release boundary, Unreleased, immutable history, candidate freeze, published relation.
7. Make history reconstructible from Git/release boundaries rather than trusting surviving changelog text.
8. Verify Release Please v5 supported skip-changelog config.
9. Implement canonical changelog ownership.
10. Remove/eliminate global section stripping responsibility.
11. Add assurance rejecting recurrence.
12. Materialize/check locally and run fixtures.
13. Verify 0.2.0 + 0.2.1 survive and Unreleased is correct.
14. Only after local coherence, create/push a PR for review.
15. Do not merge it.
16. After user-approved merge, let Release Please refresh #15.
17. Use refreshed 0.2.2 candidate as end-to-end test.
18. Still require explicit user approval before merging #15 or publishing release.

## User interaction
User wants autonomous repo work and said to notify them only if something is needed from them. Ordinary local edits/checks do not need repeated permission. Protected external effects (merge/release) always require explicit approval.
