# Govenv — Session Handoff
**Date:** 2026-09-23  
**Repository:** `klarkc/govenv`  
**Purpose of this handoff:** resume in a clean session immediately after PR #39, preserving all architectural decisions and the exact next step.

---

## 1. Current repository state

PR **#39 — `gov(project): unify purpose and add protocol vigilance`** was merged.

- PR: https://github.com/klarkc/govenv/pull/39
- PR merge commit: `163e2c473153c9cc1b55bf619e716dfe989570b5`
- Current `main` at handoff: `af6a2e02f09c9d1b3161b915cce3ba0631b3a3c2`
- `af6a2e0` is the automatic post-merge materialization commit.
- Parent of `af6a2e0`: `163e2c473153c9cc1b55bf619e716dfe989570b5`
- Materialization commit message:
  - `chore(materialize): update governed materializations`
  - `Derived-From-Parent: true`
  - `Refs: GV44 GV51 GV90 GV92 GV93`
  - `skip-checks: true`

At the moment of handoff, workflow run `35873098820` was still technically `in_progress`, but all substantive paths had already succeeded:
- `materialize` job: success
- repository metadata adapter build: success
- repository metadata apply + read-back verification: success
- repository metadata evidence recording: success
- repository state check: success
- tests: success
- only cleanup/post steps remained in progress

A second Materialize run on the derived commit `af6a2e0` was correctly skipped.

---

## 2. Canonical project purpose

`Govenv.Project.purpose` is now the **single canonical public project statement**.

Current purpose:

> Turn every repository into a self-governing developer environment: define what valid means once, catch problems early, and reproduce the same tooling, automation, and runtime anywhere.

Properties:
- developer-first product positioning
- intentionally understandable without knowing Agda, Governance, Protocol, GVs, or the roadmap
- durable across the complete P0–P6 product direction
- <= 250 characters
- projected verbatim to:
  - README hero/tagline
  - GitHub repository `description`

There is no longer an independent semantic `Govenv.Project.description`.

GitHub metadata was automatically reconciled post-merge and read back successfully:
- description = exact `Govenv.Project.purpose`
- website = `https://klarkc.github.io/govenv/`
- topics:
  - `agda`
  - `ai-agents`
  - `devenv`
  - `formal-methods`
  - `nix`
  - `repository-governance`

Do **not** run Admin Materialize for ordinary project metadata. GV108 established that ordinary deterministic metadata reconciliation is automatic after an authorized revision.

---

## 3. GV109 — single public purpose

GV109 is done and supersedes GV21 + GV100.

Intent:

> Make `Govenv.Project.purpose` the single canonical public project statement: remove independent `description` state, limit `purpose` to 250 characters, project it verbatim as the README hero and GitHub repository description, and keep `website` plus `topics` as canonical project metadata materialized to GitHub with read-back verification.

Important effects:
- `Govenv.Project.description` removed
- `descriptionCharacterLimit` removed
- `purposeCharacterLimit = 250`
- README `## Purpose` section removed as duplicate
- README hero uses `purpose`
- GitHub repository description materialization consumes `purpose`
- GV21 historical assurance was adapted to remain valid under the superseding model
- GV109 assurance proves:
  - purpose limit = 250
  - GitHub description projection = purpose
  - README hero = purpose
  - website/topics remain canonical
  - target-specific read-back verification remains present

---

## 4. GV110 — Protocol vigilance witnesses

GV110 is done.

Core principle:

Some Protocol obligations require genuine contributor/agent judgment that the compiler cannot honestly prove. However, the **need to exercise that judgment** may have an objective semantic trigger.

Govenv may therefore require a **vigilance witness**:
- the witness proves only that the review was explicitly refreshed after its trigger
- it does **not** prove the subjective judgment was correct
- Protocol remains Protocol
- only witness freshness is machine-checkable/governed
- never auto-advance the witness

This was explicitly inspired by a railway vigilance / dead-man device:
- the system cannot prove the operator is thinking correctly
- it can require an active acknowledgement that the operator is still attending

### Generic counter semantics

`src/Govenv/Kernel/Protocol.agda` defines the generic relation.

For a counter-style witness:

| Trigger changed? | Reviewed subject changed? | Required counter transition |
|---|---|---|
| no | no | preserve counter |
| no | yes | reset to `0` |
| yes | no | increment exactly once |
| yes | yes | reset to `0` |

Ticks must never be derived or incremented automatically.

A witness should be used only when:
- judgment is genuinely non-decidable
- trigger is objective and stable
- forgetting the review has meaningful risk
- signal remains low-noise

Do **not** use vigilance witnesses when:
- desired property is machine-decidable and constitutional → model it directly as Governance
- deterministic documentation/source-layout/dependency/commit rules can be expressed directly
- the trigger is noisy/high-frequency and would become checkbox theater
- completion/regression already has appropriate governed evidence

Possible future candidate:
- reuse-first engineering review, **only after** a stable typed trigger exists for new dependency/custom-infrastructure introductions

Natural future integration point:
- GV104: scoped Protocol advisories
- GV105: coding-agent lifecycle boundaries
- GV88: earliest sound information boundary

---

## 5. First vigilance application: project purpose

`Govenv.Project` now contains:

```agda
purpose : String
purpose = "Turn every repository into a self-governing developer environment: define what valid means once, catch problems early, and reproduce the same tooling, automation, and runtime anywhere."

purposeReviewIndex : Nat
purposeReviewIndex = zero
```

The counter is currently `0` because PR #39 **changed the purpose itself**, therefore this transition is a reset rather than a reaffirmation.

### Mandatory rule from now on

**Every semantic change to `Govenv.Roadmap` must review the current purpose against the complete resulting roadmap, not only the changed item/phase.**

Then:

```text
roadmap changed
    │
    ├─ purpose still accurately represents the complete resulting product
    │      ├─ keep purpose unchanged
    │      └─ purposeReviewIndex := previous + 1
    │
    └─ purpose no longer accurately represents the product
           ├─ update purpose
           └─ purposeReviewIndex := 0
```

If neither roadmap nor purpose changes:
- `purposeReviewIndex` must remain unchanged

The index must never be bumped merely to satisfy the compiler.

### Important consequence for the next session

PR #39 introduced the first governed predecessor snapshot:

`.govenv/project-purpose.snapshot`

Therefore the **next semantic roadmap change is no longer a migration exception**. It must satisfy the vigilance relation.

If the next work adds/changes a GV while keeping the current purpose:
- review the **entire resulting roadmap**
- if purpose is still good, change `purposeReviewIndex` from `0` to `1`

If the purpose changes:
- keep/reset it at `0`

Forgetting both should make validation fail.

---

## 6. How purpose vigilance is checked

New governed snapshot:

`.govenv/project-purpose.snapshot`

Format v1:

```text
govenv-project-purpose-snapshot-v1
review-index 0
purpose "Turn every repository into a self-governing developer environment: define what valid means once, catch problems early, and reproduce the same tooling, automation, and runtime anywhere."
```

Semantic ownership:
- canonical authority remains `Govenv.Project`
- snapshot is only a governed previous-state materialization
- snapshot is not a second semantic authority

Main pieces:

- `src/Govenv/Kernel/Protocol.agda`
  - generic `protocolVigilanceFresh`
- `src/Govenv/Kernel/ProjectPurpose.agda`
  - typed `ProjectPurposeSnapshot`
- `Govenv/Materialization/ProjectPurposeSnapshot.lagda.md`
  - canonical materialization binding
- `src/Govenv/Projection/ProjectPurposeSnapshot.agda`
  - snapshot rendering
- `src/Govenv/Adapter/ProjectPurposeSnapshot.agda`
  - effect/output adapter
- `src/Govenv/Adapter/PurposeVigilance.agda`
  - compile-time vigilance relation against previous state
- `src/Govenv/Adapter/roadmap-evolution.sh`
  - observes previous governed snapshots and injects them into an Agda observation module

The key enforcement is an Agda proof:

```agda
purposeReviewVigilance : purposeReviewFresh ≡ true
purposeReviewVigilance = refl
```

The shell adapter only observes/injects predecessor facts.
The validity relation itself is typed/pure and checked by Agda.

Integration tests performed before merge:

1. **Negative**
   - roadmap changed
   - purpose unchanged
   - previous index = 0
   - current index = 0
   - result: validation failed with exit 4

2. **Positive reset**
   - roadmap changed
   - purpose changed
   - previous index > 0
   - current index = 0
   - result: validation passed

---

## 7. Protocol changes

`Govenv.Protocol` now includes a general section:

### Protocol vigilance witnesses

Meaning:
- use a governed witness only for non-decidable Protocol judgment with objective trigger
- witness freshness can be checked
- correctness of the judgment cannot be pretended/proved
- no automatic witness advancement
- prefer direct Governance whenever the result itself is decidable/constitutional

### Project purpose stewardship

Now requires:
- treat purpose as long-term criterion for roadmap coherence
- every semantic roadmap change reviews purpose against the **complete resulting roadmap**
- material scope/architecture/product-boundary/agent-workflow changes outside the roadmap also review it
- developer-first product positioning
- practical outcome/value first
- concrete language understandable without internal architecture context
- stable product capability over incidental implementation detail
- concise, memorable, credible, technically precise
- avoid hype, unsupported superlatives, vague promises, internal GV IDs, incidental backend/tool names
- project the same canonical purpose verbatim wherever Govenv states the public project statement
- review website/topics when public product identity materially changes

`AGENTS.md` is materialized from this Protocol.

---

## 8. Important architecture / invariants carried forward

### Governance vs Protocol

GV101 is already done:

- Governance = constitutional validity of state/transition/effect/authorization/semantic output
- Protocol = contributor/agent process guidance
- machine-checkability alone does **not** turn Protocol into Governance

GV110 preserves this distinction:
- the **review judgment** remains Protocol
- the **freshness transition of the witness** is governable

### Earliest sound boundary

GV88 is pending, but remains the long-term rule:
- enforce every governable obligation at the earliest sound information boundary
- later boundaries may confirm but must not re-own semantics

Purpose vigilance currently lives in candidate roadmap-evolution validation.
Later it can be anticipated via LSP/agent lifecycle, but the same semantics must be reused.

### Materialization authority

GV102 is the next roadmap item and must maintain this separation:

```text
Governance / Protocol / Project data
           │ semantic authority
           ▼
Govenv.Materialization.*
           │ binds authoritative source to target/application/authority/verification
           ▼
Projection
           │ target-format rendering only
           ▼
Adapter
           │ observe / apply / verify effects only
```

Do not let Materialization re-own domain semantics.
Do not let Projection or Adapter introduce policy.

### Authorized effects

GV108 is done:
- exactly one human administrative root: `GOVENV_ADMIN_TOKEN`
- Admin Materialize only for bootstrap/recovery/rotation
- ordinary authorized deterministic effects reconcile automatically
- GitHub description/website/topics are now confirmed to work via that automatic path
- repository metadata apply + read-back succeeded post-PR39

---

## 9. Relevant governance state

Important established/done:
- GV20 — canonical immutable Govenv project identity
- GV21 — superseded by GV109
- GV45 — admin materialization read-back + evidence
- GV54 — immutable governance identities/definitions/phases
- GV60 — README canonical materialization
- GV68/69 — typed roadmap IDs/operator notation
- GV70 — immutable typed roadmap snapshots + governance deltas
- GV94/95 — authorization-related previous work
- GV101 — Governance / Protocol / effect-boundary partition
- GV108 — bootstrap vs authorized automatic materialization
- GV109 — single public purpose
- GV110 — Protocol vigilance witness mechanism

Important pending/future:
- **GV102 — next**
- GV18
- GV46
- GV63
- GV24
- GV12
- GV13
- GV96
- GV97
- GV98
- GV99
- GV73
- GV74
- GV84
- GV86
- GV87
- GV90
- GV91
- GV93
- P4: GV103, GV104, GV105, GV107, GV88
- P5: runtime compiler / backend / shell integrations
- P6: standalone/self-hosting/distribution/ejectability

---

## 10. Exact next roadmap item: GV102

GV102 definition:

> Separate domain semantic authority from materialization binding: every state materialized by Govenv must have exactly one canonical `Govenv.Materialization.*` definition that binds authoritative semantic sources and any target-specific composition, ordering, or inclusion to its target, application mode, privilege, required authority, and verification; Governance, Protocol, and other governed project data retain ownership of their domain semantics and must not be duplicated or re-owned by materializations, projections, or adapters; projections encode target-format representation and adapters only observe, apply, or verify effects.

This is the normal next item after PR39.

### Crucial before touching GV102

Because implementing/completing/advancing GV102 changes the semantic roadmap:

1. inspect the **complete resulting roadmap**
2. explicitly review current `Govenv.Project.purpose`
3. if purpose still describes the full P0–P6 product direction, increment:
   - `purposeReviewIndex: 0 -> 1`
4. if the purpose should change, update it and keep/reset counter to `0`

Given the current purpose was deliberately reviewed against P0–P6 during this session, expectation is probably that it remains valid, but **do not mechanically assume that**: perform the Protocol review first.

---

## 11. Long-term product objective

The current product direction is broader than “formal checks” or “AI agent hooks”.

Target state:

- one typed/verifiable project model
- Governance defines constitutional validity
- Protocol guides contributor/agent process
- checks/diagnostics/enforcement occur at earliest sound boundaries
- Git, CI, editor/LSP, coding agents, hooks and optional MCP consume the same semantic model
- typed Environment/Runtime IR
- reproducible developer runtime (`shell`, `test`, `up`)
- replaceable runtime backends
- devenv as Stage 0/backend, not permanent semantic authority
- standalone Govenv entrypoint
- self-hosting
- white-label distributions
- declarative bootstrap/integrations/secrets/environments
- ejectability from repository-specific `klarkc/govenv` code

The current public purpose intentionally compresses this into developer-facing product language.

---

## 12. Working conventions for the next session

User expectations:
- Portuguese discussion is fine; identifiers/code in English
- prioritize global architectural coherence over local patches
- formal/type-level invariants preferred where honest
- reuse ecosystem capability before inventing bespoke machinery
- `.lagda.md` for human-facing normative Governance/Protocol/evidence
- implementation details/documentation colocated with owning `.agda`
- do not package/take ownership of coding agents
- MCP remains optional adapter-only
- coding agents are assumed to be launched inside `govenv shell` in the final model
- Git hook is provider-neutral fallback/boundary
- LSP is first-class for agents/editors when supported

Git/review discipline:
- **never merge a PR without explicit user approval**
- use a clean worktree/branch; do not disturb stale changes in the user's original checkout
- separate semantic commit from derived materialization commit
- derived commit body should include:
  - `Derived-From-Parent: true`
- use GitHub connector for repo/PR/workflow operations
- before opening/updating PR, validate:
  - `devenv test`
  - `govenv:check`
  - `git diff --check`
  - clean working tree
  - branch based on current `origin/main`

Current main moved after PR39:
- base new work on `origin/main` at or after `af6a2e02f09c9d1b3161b915cce3ba0631b3a3c2`

---

## 13. Suggested first actions in the new session

1. Fetch current `origin/main`.
2. Confirm post-merge run `35873098820` fully completed; substantive jobs were already green at handoff.
3. Confirm `origin/main` still includes `af6a2e0` or any later expected materialization-only commits.
4. Read GV102 and inspect current `Govenv.Materialization.*` architecture globally.
5. **Before changing the roadmap**, execute the purpose-stewardship review against the complete resulting roadmap.
6. If purpose is reaffirmed, set `purposeReviewIndex = 1` as part of the semantic roadmap change.
7. Continue GV102 without weakening GV101/GV109/GV110.

---

## 14. Key conceptual takeaway from this session

Govenv now has a useful third pattern between “unenforced prose” and “pretend the subjective judgment is formally provable”:

```text
Protocol judgment
    │
    │ subjective / non-decidable
    ▼
explicit vigilance witness
    │
    │ freshness is objective
    ▼
compiler-enforced transition
```

This pattern should remain narrowly used.

For project purpose:

```text
semantic roadmap delta
        ↓
review full resulting roadmap against purpose
        ↓
 purpose still good? ── yes ──> counter + 1
        │
        no
        ↓
 update purpose
 reset counter to 0
```

That is now part of the governed repository model, not just an informal convention.
