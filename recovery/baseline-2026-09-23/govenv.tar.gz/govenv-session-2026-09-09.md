# Govenv — Session handoff
**Date:** 2026-09-09  
**Repository:** `klarkc/govenv`  
**Local path:** `/home/klarkc/Sources/klarkc/govenv`  
**Branch:** `main`

## Project thesis

> A type system for your repository. Formally define what your project is allowed to become.

Canonical architecture:

```text
governed value -> pure projection -> effectful adapter -> target
```

Generic mechanics live under `Govenv.Kernel.*`; project-specific governed source is literate `Govenv/*.lagda.md`.

Materialization architecture:

```text
Govenv.Materialization.*
        -> Govenv.Projection.*
        -> Govenv.Adapter.*
        -> repository / GitHub / external target
```

Important rule already established:

> Every state materialized by Govenv must have exactly one canonical `Govenv.Materialization.*` definition containing semantic content, structure, ordering, inclusion, policy and required capability decisions. Projections only encode target representation; adapters only observe/apply/verify effects.

Examples:

```text
README.md                         -> Govenv.Materialization.Readme
.gitignore                        -> Govenv.Materialization.Gitignore
.github/workflows/test.yml        -> Govenv.Materialization.Github.Workflows.Test
GitHub repository description    -> Govenv.Materialization.Github.Repository.Description
release PR governance section    -> Govenv.Materialization.ReleaseGovernance
.govenv/roadmap.snapshot          -> Govenv.Materialization.RoadmapSnapshot
```

Adapters are not semantic exceptions. Kernel / Constitution / Materialization decide **what** must be true; Projection decides **how** it is represented; Adapter performs/observes/verifies effects.

---

# Roadmap identity model

Typed identifiers:

```agda
data IdentifierKind : Set where
  Phase Governance : IdentifierKind

data Identifier (kind : IdentifierKind) : Nat -> String -> Set where
  identifier :
    (idx : Nat) ->
    (description : String) ->
    Identifier kind idx description

PhaseId : Nat -> String -> Set
PhaseId = Identifier Phase

GovernanceId : Nat -> String -> Set
GovernanceId = Identifier Governance

P  : (idx : Nat) -> (description : String) -> PhaseId idx description
P = identifier

GV : (idx : Nat) -> (description : String) -> GovernanceId idx description
GV = identifier
```

Roadmap DSL:

```agda
roadmap = roadmapOf (
    (P 0 "..." ■
      ┬ GV 0 "..." ✓
      ...)
  ╟ (P 1 "..." ▣
      ...)
  ╟ (P 2 "..." □
      ...)
)
```

Phase marks:

```text
■ finished
▣ active
□ future
```

Item lifecycle now supports:

```text
✓ done
◇ pending
× cancelled
↪ superseded
```

Supersession points explicitly to a replacement governance identity via `GVR`.

Example:

```agda
GV 23 "old definition" ↪ GVR 63
GV 63 "new definition" ◇
```

---

# Key semantic decision from this session

We eliminated `amended` completely.

The rule is now:

> Once introduced, a `GovernanceId`, its definition, and its owning phase are immutable.

Even typo fixes require a new governance identity.

Example:

```text
not allowed:
GV23 "Require every CI wokflow..." -> GV23 "Require every CI workflow..."

required:
GV23 "Require every CI wokflow..." ↪ GV54
GV54 "Require every CI workflow..."
```

Legitimate lifecycle transitions are conceptually:

```text
pending -> done
pending -> cancelled
pending -> superseded GVn
```

Terminal identities stay in history forever.

A removed identity is **not** a normal delta item. It is a governance violation.

Likewise:
- changing the definition of an existing GV is a violation;
- moving an existing GV to another phase is a violation;
- reusing an old identity is forbidden;
- a superseded target must exist.

The project now has append-only semantics for governance identity.

---

# Historical roadmap audit performed in this session

We reviewed the repository history from the point where `GovernanceId` existed.

The following IDs had been mutated historically and therefore, under the new rule, needed explicit supersession:

```text
GV7
GV8
GV9
GV10
GV11
GV14
GV17
GV23
GV25
GV27
GV28
GV40
GV47
GV49
```

State-only transitions such as:

```text
◇ -> ✓
```

were considered legitimate and did not need successor IDs. Examples:

```text
GV44
GV48
GV51
GV52
```

However, GV48 itself needed to be superseded because its **definition** had to evolve to include the new release semantics (`cancelled`, `superseded`, mutation rejection, etc.).

---

# Historical normalization now encoded in the roadmap

Current relevant successor mapping introduced in this session:

```text
GV7  -> GV55
GV8  -> GV56
GV9  -> GV57
GV10 -> GV58
GV11 -> GV59
GV14 -> GV60

GV17 -> GV61 -> GV62

GV23 -> GV63
GV25 -> GV64
GV27 -> GV65
GV28 -> GV66
GV40 -> GV67
GV47 -> GV68
GV49 -> GV69

GV48 -> GV70
```

Important detail:

GV17 had two historical semantic rewrites, so it now has an explicit chain:

```text
GV17 -> GV61 -> GV62
```

This intentionally preserves the intermediate definition rather than collapsing history.

GV27 historically moved from P3 to P2; it is now preserved in P3 as superseded, while GV65 is the new P2 item.

GV40 historically moved from P6 to P5; it is now preserved in P6 as superseded, while GV67 is the new P5 item.

---

# New governance items

## GV54

Current wording:

> Preserve immutable governance identity across roadmap evolution: once introduced, a `GovernanceId`, its definition, and its owning phase may never be removed, reused, or modified; obsolete or corrected governance must remain represented as cancelled or superseded, with supersession explicitly identifying a newer replacement `GovernanceId`.

GV54 is marked complete (`✓`).

## GV70

GV48 was preserved and superseded by GV70.

GV70 wording:

> Project release governance deltas from immutable typed roadmap snapshots and commit references, distinguishing introduced, advanced, completed, cancelled, and superseded items plus phase progression while rejecting identity mutation or removal and keeping SemVer independent.

GV70 is marked complete (`✓`).

---

# Snapshot v2

The roadmap snapshot was upgraded from:

```text
govenv-roadmap-snapshot-v1
phase active 1
item 48 done
```

to a richer v2 that stores:

```text
- governance id
- owning phase
- lifecycle state
- exact immutable definition
- supersession target, where applicable
```

Format example:

```text
govenv-roadmap-snapshot-v2
phase active 1
item 47 phase 1 superseded 68 "Type roadmap governance identifiers ..."
item 68 phase 1 done "Type roadmap governance identifiers ..."
item 55 phase 1 todo "Model the governed release-progress policy ..."
```

Rendered Agda strings use escaped Unicode code points where required.

The v2 snapshot is now enough to detect:
- removal;
- description mutation;
- phase mutation;
- lifecycle regressions;
- supersession.

The old v1 baseline did not contain enough data to prove immutable identity. Therefore the one-way migration v1 -> v2 is treated as a legacy migration / normalization boundary.

---

# Critical validation hardening

A subtle bug was discovered during the final review:

If validation compared the current roadmap only to the snapshot in the **same candidate tree**, someone could mutate a GV and update the snapshot in the same commit, making both agree.

This was fixed.

The roadmap evolution validator now compares against the prior committed snapshot:

```text
dirty working tree:
    candidate roadmap vs HEAD snapshot

clean committed state / CI:
    current commit roadmap vs HEAD^ snapshot
```

This means a mutated roadmap cannot be hidden by updating `.govenv/roadmap.snapshot` in the same commit.

The v1 -> v2 migration is specially recognized because v1 did not preserve definition/phase.

---

# Negative tests actually exercised

These failures were explicitly tested:

```text
1. governance removed
   -> rejected

2. governance definition changed
   -> rejected

3. owning phase changed
   -> rejected

4. superseded points to nonexistent GV
   -> roadmapOf does not produce Roadmap
```

One concrete runtime validation test after the commit temporarily changed GV55. The validator correctly failed with:

```text
Immutable governance definition was changed: GV55
```

The file was then restored and the materialization check passed again.

---

# Release delta semantics after this session

Legitimate item progress classes now are conceptually:

```text
introduced
advanced
completed
cancelled
superseded
```

`removed` is never a normal release impact.

Removal / mutation produces an invalid governance delta.

Also fixed:

> A GV absent from the previous snapshot is always `introduced`, even if the release commits contain `Refs: GV...`.

Commit references provide attribution; they do not imply that a stable identity existed previously.

The release projection now includes counts for:

```text
completed
advanced
introduced
cancelled
superseded
```

Superseded items render with the replacement identity.

Example conceptually:

```text
├ ↪ GV48 — superseded → GV70
└ ✓ GV70 — completed
```

---

# Files added / changed in this session

New files:

```text
src/Govenv/Adapter/RoadmapEvolution.agda
src/Govenv/Adapter/roadmap-evolution.sh
```

Important modified files:

```text
.govenv/roadmap.snapshot

Govenv/Roadmap.lagda.md
Govenv/Release.lagda.md
Govenv/Readme.lagda.md

Govenv/Materialization/RoadmapSnapshot.lagda.md
Govenv/Materialization/ReleaseGovernance.lagda.md

src/Govenv/Kernel/Identifier.agda
src/Govenv/Kernel/Roadmap.agda
src/Govenv/Kernel/Release.agda

src/Govenv/Roadmap/DSL.agda

src/Govenv/Projection/Readme.agda
src/Govenv/Projection/RoadmapSnapshot.agda
src/Govenv/Projection/ReleaseGovernance.agda

src/Govenv/Adapter/release-governance.sh

devenv.nix
README.md
```

---

# Validation commands

Canonical commands:

```sh
nix run github:cachix/devenv/v2.3 -- tasks run govenv:materialize
nix run github:cachix/devenv/v2.3 -- test
```

Also used:

```sh
nix run github:cachix/devenv/v2.3 -- tasks run govenv:materialize:check
```

Before push:
- full test passed;
- materialization check passed;
- negative identity-mutation tests passed.

---

# Commit created in this session

Commit:

```text
03b2d54f830641c32e755fb496bb3a180cdccc31
gov(roadmap): preserve immutable governance history
```

Commit message body:

```text
Normalize previously rewritten roadmap identities through explicit supersession,
establish snapshot v2 with immutable definition and owning-phase evidence,
and validate roadmap evolution before materialization.
```

Refs footer:

```text
Refs: GV54, GV55, GV56, GV57, GV58, GV59, GV60, GV61, GV62,
      GV63, GV64, GV65, GV66, GV67, GV68, GV69, GV70
```

Commit author was correctly:

```text
Walker Leite
walkerleite490@gmail.com
```

The commit was pushed:

```text
b421130..03b2d54  main -> main
```

---

# Remote CI state when the session was stopped

The push triggered:

```text
Workflow: Materialize
Run number: #18
Run id: 34412143987
Commit: 03b2d54f830641c32e755fb496bb3a180cdccc31
```

At the moment the user explicitly said:

> "Pare o que está fazendo"

the workflow was still:

```text
status: in_progress
```

Known step state at that exact point:

```text
Set up job                success
Checkout                  success
Install Nix               success
Cache Nix                 success
Materialize constitution  in progress
Commit materializations   pending
```

No further CI verification was performed after the user asked to stop.

Therefore in the next session:
1. first check workflow run `34412143987`;
2. then inspect downstream Release workflow;
3. then inspect PR #2 governance body / CHANGELOG convergence.

Do not assume CI is green until rechecked.

---

# Release PR

Release PR remains:

```text
PR #2
https://github.com/klarkc/govenv/pull/2
title: chore(main): release 0.2.0
state: open
```

Before this new commit, the PR still showed the old governance section based on the pre-v2 model:

```text
8 completed
3 advanced
43 introduced
```

It had not yet been verified after commit `03b2d54`.

The user previously asked to be notified only when a release is actually ready for approval.

Do not merge or approve the release on the user's behalf.

---

# Roadmap state relevant for continuation

P1 is still active:

```text
P1 — Formal governance model and repository closure
```

Important live successors:

```text
GV55  release-progress policy                  ◇
GV56  self-governing Rule over GV55           ◇
GV57  repository behavior/policy inventory    ◇
GV58  inventory backed by governed data/rule  ◇
GV59  minimize ungoverned surface             ◇
GV62  architecture role enforcement           ◇
GV63  close GitHub Actions inventory          ◇
GV64  pure repository evaluator               ◇ (P2)
GV65  pure diagnostic provenance              ◇ (P2)
GV66  governed commit policy                  ◇ (P3)
GV67  replaceable runtime backends            ◇ (P5)
GV68  typed governance IDs + ✓/◇ notation     ✓
GV69  current phase glyph semantics           ✓
GV70  immutable typed release delta           ✓
GV54  immutable governance identity           ✓
```

GV48 remains in history but is now:

```text
GV48 ↪ GV70
```

GV7 / GV8 remain in history but are now:

```text
GV7 ↪ GV55
GV8 ↪ GV56
```

Future work should refer to GV55/GV56, not mutate GV7/GV8.

Likewise use all successor IDs above rather than editing superseded predecessors.

---

# Important project rules to preserve

1. Never mutate an existing governance definition.
2. Never move an existing GV between phases.
3. Never delete a GV.
4. Never reuse a GV ID.
5. Corrections, even typo-only, require a new GV and supersession.
6. `cancelled` means no successor.
7. `superseded GVR n` means a newer explicit replacement exists.
8. Superseded/cancelled are terminal.
9. Previously terminal governance must not regress to pending.
10. Materialization must validate roadmap evolution before overwriting snapshot state.
11. Release delta must fail on invalid historical evolution rather than rendering a normal impact.
12. SemVer remains independent of governance delta.
13. New identity + `Refs:` is still `introduced`.
14. Do not rewrite published Git history.

---

# Exact next step for a new session

Start by checking remote state, not by editing code:

```text
1. Inspect GitHub Actions run 34412143987.
2. If successful, identify the downstream Release run for 03b2d54.
3. Verify PR #2 body and CHANGELOG use the new v2 release-governance model.
4. Verify release materialization is idempotent and no extra bot churn appears.
5. Only when all remote checks are green, tell the user the release is ready for approval.
```

After release convergence, the logical next roadmap work remains the release-progress/self-governing rule, now under:

```text
GV55
GV56
```

not GV7/GV8.

---

# User preference / collaboration style

- Discuss architecture directly and concretely.
- Avoid abstractions that weaken types.
- Stable identity and formal semantics are important.
- When the user says “pode seguir” / equivalent, they expect actual repository edits.
- Do not claim a release is ready while CI / PR convergence is uncertain.
- The user wants to personally approve the new release.
