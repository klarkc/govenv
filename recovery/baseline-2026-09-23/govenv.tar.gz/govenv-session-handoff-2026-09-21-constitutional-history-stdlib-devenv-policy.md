# Govenv session handoff — constitutional history, ecosystem reuse, dependency/devenv policy

**Date:** 2026-09-21  
**Project:** `klarkc/govenv`  
**Purpose:** This file is intended to be sufficient to continue in a new ChatGPT session with effectively zero prior context.

---

## 1. Immediate continuation point

Continue the isolated constitutional-history spike. Do **not** migrate the real kernel yet.

The next technical step is to replace the remaining validity wrapper:

```agda
data Valid : Bool → Set where
  valid : Valid true

ValidEntry : History → HistoryEntry → Set
```

where `ValidEntry` is currently defined by Boolean computations, with a proposition-first design:

```agda
ValidEntry : History → HistoryEntry → Set
validEntry? : (h : History) → (entry : HistoryEntry) → Dec (ValidEntry h entry)
```

The intended separation is:

```text
formal property  ─────────→ Set
                            │
                            └── decidability ─→ Dec
                                                │
                                                └── CLI/check/materializer
```

Do this **inside the spike first**, keep the current baseline and stdlib-backed V2 available for comparison, and require all canonical scenarios to continue compiling.

---

## 2. Repository/worktree state

Main repository:

```text
/home/klarkc/Sources/klarkc/govenv
```

Isolated spike worktree:

```text
/home/klarkc/Sources/klarkc/govenv-history-spike
```

Branch:

```text
spike/constitutional-history
```

Base commit:

```text
8728e3d939183290fbc9713eb9dbb1f581a99035
8728e3d chore(materialize): freeze canonical release changelog
```

Current `git status --short` in the spike worktree:

```text
?? AGENTS.md
?? spike/
```

No commit or push has been made for this spike.

Current spike files:

```text
spike/ConstitutionalHistory.agda
spike/ConstitutionalHistoryScenarios.agda
spike/ConstitutionalHistoryStdlib.agda
spike/ConstitutionalHistoryStdlibScenarios.agda
spike/EcosystemReuse.agda
```

Agda also generated `.agdai` files beside them. Those are compiler artifacts, not source; do not accidentally commit them.

Current line counts observed:

```text
364 spike/ConstitutionalHistory.agda
353 spike/ConstitutionalHistoryStdlib.agda
176 spike/ConstitutionalHistoryScenarios.agda
247 spike/ConstitutionalHistoryStdlibScenarios.agda
 41 spike/EcosystemReuse.agda
```

### Important caution about the original worktree

Earlier work in the original repository had unrelated local changes/untracked files. The isolated worktree exists specifically to avoid touching them. Do not casually modify/reset the original worktree.

Historically observed in the original repository:

```text
M  src/Govenv/Kernel/Assurance.agda
?? Govenv/Assurance/GV60.lagda.md
?? govenv-gv84-release-main/
```

Re-check before touching the original repo rather than assuming this list is still current.

---

## 3. Core constitutional-history design agreed before this session

The conceptual topology being pursued is:

```text
Governance
    ↓ declares
Proposition
    ↓ evidence/proof
Obligation
    ↓ constitutional evolution
Disposition / history transitions
```

But the key correction is that the constitution is **append-only history**, not a snapshot with lifecycle state stored on GV/Obligation.

### 3.1 Proposition identity

`PropositionId` is independent of `GovernanceId`.

Conceptually:

```agda
data PropositionId : Nat → Set where
  Prop : (idx : Nat) → PropositionId idx
```

A Proposition is a governed logical entity:

```agda
record Proposition (idx : Nat) : Set₁ where
  constructor proposition
  field
    propositionId : PropositionId idx
    Statement     : Set
```

Layers:

```text
Prop 17          identity
Proposition 17   constitutional entity
Statement        actual logical proposition
```

Proposition IDs are globally unique.

Do not return to an identity scheme such as `P(GV, localIndex)`.

### 3.2 Governance contract string

A GV retains its human-readable contract string. The string is the human/AI-readable contract summarizing what its Propositions mean.

The formal truth lives in the Propositions. A human/another agent may verify that the string faithfully summarizes them.

A Proposition can later move under another GV's responsibility through disposition/supersession; its identity is not tied to its original GV.

### 3.3 Evidence and Obligation

Existing assurance-local uses of the name `Proposition` were identified as actually meaning `Statement`; that naming should eventually be corrected.

Evidence belongs to a Proposition, not a GV:

```agda
record Evidence {idx : Nat} (p : Proposition idx) : Set₁ where
  field
    proof : Proposition.Statement p
```

An `Obligation p` means that Proposition `p` is constitutionally established and carries evidence.

There is no meaningful “pending Obligation”. Pending belongs to a declared Proposition that has not yet been established.

Avoid:

```text
ObligationState
pending Obligation
staged Obligation
operative Bool
```

The current `Rule/Verdict` payload named `Obligation` likely deserves a different name such as `Requirement`, because it is not the constitutional `Obligation` concept.

### 3.4 History, not state mutation

Constitution should be represented as append-only history:

```agda
data History : Set₁ where
  ε   : History
  _▻_ : History → HistoryEntry → History
```

Validity is separate:

```agda
data ValidHistory : History → Set₁ where
  empty : ValidHistory ε
  extend :
    ValidHistory history →
    (entry : HistoryEntry) →
    ValidEntry history entry →
    ValidHistory (history ▻ entry)
```

Minimal events/entries:

```text
declare
establish
abandon
supersede
```

Do **not** introduce individual `withdrawn`, `reformulated`, or `preserved` history events. Those are atomic dispositions inside a supersession cutover.

Standalone `abandon` exists because a pending Proposition may be abandoned without a supersession.

No `TransitionId` is wanted.

### 3.5 Derived predicates

The desired model derives predicates from history rather than storing lifecycle state:

```text
Declared
EverEstablished
WasAbandoned
WasWithdrawn
WasReformulated
Terminated
Live
Pending
Active
Origin
CurrentResponsibility
Outgoing
```

Semantics:

```text
Terminated = abandoned OR withdrawn OR reformulated
             (preserved is NOT termination)

Live       = Declared AND NOT Terminated

Pending    = Live AND NOT EverEstablished

Active     = Live AND EverEstablished
```

`EverEstablished` is historical/monotonic.

`Active` is current.

`origin` is derived from the unique declaration that introduced the Proposition; do not store it as mutable ownership metadata.

### 3.6 Establishment

An establishment is valid only for a `Pending` Proposition and must carry Evidence.

Standalone abandonment is valid only for `Pending`.

This allows a governance item to resolve as entirely abandoned without pretending it was ever established.

### 3.7 Supersession

Planning and constitutional effect are different:

```text
GV77 ↝ GV95   planned/future relationship
GV77 ↪ GV95   effective constitutional supersession
```

Do not create a `SupersessionState`.

Minimal shape:

```agda
record Supersession : Set₁ where
  field
    previous       : GovernanceRef
    successor      : GovernanceRef
    establishments : List Establishment
    dispositions   : List PropositionDisposition
```

Supersession is atomic.

`outgoing h g` means every currently live Proposition whose current responsibility is `g`, including inherited/preserved Propositions.

Coverage rule:

```text
subjects(dispositions) = outgoing(previous)
```

with each subject handled exactly once.

Disposition validity matrix:

| Previous proposition | preserved | abandoned | withdrawn | reformulated |
|---|---:|---:|---:|---:|
| pending | valid | valid | invalid | invalid |
| active | valid | invalid | valid | valid |

`preserved` transfers current responsibility to the successor.

Do not add a separate owner/transfer fact when it can be derived from history.

For `reformulated`, replacements belong to successor scope and must already be active or be established atomically as part of the same cutover.

Embedded establishments in a supersession must actually be used by a reformulation; do not allow “establishment smuggling”.

Split/merge naturally arise by allowing reformulation target lists.

### 3.8 Governance subjects and glyphs

`GovernanceSubjects` includes:

```text
- Propositions introduced by the GV
- Propositions handled by the GV as a successor
  (including inherited preserved propositions)
```

Derived Proposition resolution is currently:

```text
pending
established
abandoned
```

Withdrawal/reformulation remain historically established, so they do not become a new “not established” resolution.

Desired glyph semantics:

```text
◇   if any subject is pending
×   if none pending and all are abandoned
✓*  if none pending and there is a mix of established + abandoned
✓   if all are established
```

Empty-subject GVs currently map to `◇`; this was intentionally left as something worth testing rather than silently changing.

A pure-preservation successor can be `✓` if the inherited Proposition was already established.

Withdrawal/reformulation do not erase historical establishment.

### 3.9 No general GV dependency DAG

Do not model arbitrary dependency edges between GVs.

The long-lived relation graph is Proposition/Obligation lineage and constitutional history.

Governance items are cumulative constitutional decisions, interpreted against the constitution at that revision.

### 3.10 Prefix/history property

Older “mutation/removal” checks such as GV54 may collapse into a history-prefix property:

```text
previousHistory ⊑ currentHistory
```

Release governance delta can then be derived from appended history entries rather than comparing ad-hoc snapshot `ItemState`s.

`advanced` is activity/projection metadata, not a constitutional event.

A snapshot should represent a semantic history prefix, not Git history.

---

## 4. Canonical scenarios that MUST remain valid

The spike now contains formal compile-time scenarios.

### Scenario 1 — simple establishment

Expected:

```text
GV → ✓
```

A GV declares one Proposition and establishes it.

### Scenario 2 — established + abandoned subjects

A GV declares two Propositions:

```text
Prop A → established
Prop B → abandoned while pending
```

Expected:

```text
GV → ✓*
```

This is a mix across subjects, not one Proposition being both established and abandoned.

### Scenario 3 — GV47 reformulated by GV68

Canonical shape:

```text
GV47 introduces Prop17
Prop17 established
GV68 introduces Prop23
GV47 ↪ GV68
  Prop17 reformulated → Prop23
  Prop23 established atomically in cutover
```

Expected:

```text
GV47 → ✓
GV68 → ✓
```

Current compile-time assertions in V2:

```agda
gv47-glyph : governanceGlyph h47-68 47 ≡ check
gv68-glyph : governanceGlyph h47-68 68 ≡ check
```

### Scenario 4 — GV77 abandoned by GV95

Canonical shape:

```text
GV77 introduces Prop41 (pending)
GV95 introduces Prop60 (pending)

GV77 ↪ GV95
  Prop41 abandoned
```

Expected immediately:

```text
GV77 → ×
GV95 → ◇
```

After Prop60 is established:

```text
GV95 → ✓*
```

Current assertions:

```agda
gv77-glyph : governanceGlyph h77-95 77 ≡ cross
gv95-glyph : governanceGlyph h77-95 95 ≡ diamond
gv95-established-glyph : governanceGlyph h95-established 95 ≡ mixed
```

All these scenarios currently compile with `ValidHistory`.

---

## 5. Current spike files and their roles

### `spike/ConstitutionalHistory.agda`

Baseline implementation.

It compiles and supports the four canonical scenarios, but contains intentional/known shortcuts that should **not** become the final kernel:

- manual Bool combinators
- manual list membership/equality/traversals
- order-sensitive coverage comparison
- internal `PropositionState` snapshot:
  ```text
  unseen | pending | active | abandonedState | retired
  ```
- `Valid (Bool)` wrapper instead of proposition-first validity

Keep it as a behavioral baseline for now.

### `spike/ConstitutionalHistoryScenarios.agda`

Canonical scenarios against the baseline.

Compiles.

### `spike/EcosystemReuse.agda`

Micro-spike proving concrete reuse from Agda stdlib 2.3.

It successfully compiled usage of:

```text
Data.Nat.Properties._≟_
Data.List.Membership.DecPropositional
Data.List.Relation.Unary.All
Data.List.Relation.Unary.Any
Data.List.Relation.Unary.Unique.DecPropositional
Relation.Nullary.Dec
Relation.Nullary.Decidable.does
```

This was used to verify APIs in the actual pinned/available stdlib rather than assuming current `master` APIs.

### `spike/ConstitutionalHistoryStdlib.agda`

The current preferred V2.

Key improvements:

- no `PropositionState`
- predicates derived directly from historical event collections
- stdlib-based Nat equality
- stdlib membership
- stdlib `filterᵇ`
- stdlib `Data.Bool.ListAction.all/any`
- stdlib `Unique`
- stdlib decidable subset `_⊆?_`
- no hand-written `_++_`
- no hand-written Bool `and/or/not`
- no `listNatEqual`

It currently compiles with no warnings.

### `spike/ConstitutionalHistoryStdlibScenarios.agda`

Contains all four canonical scenarios plus extra semantic regression tests.

It compiles with no warnings.

Additional tests:

1. **Duplicate Proposition IDs in one declaration are rejected.**

   Current assertion uses an impossible pattern:

   ```agda
   duplicateIdsRejected :
     ValidEntry ε (declare duplicateDeclaration) → ⊤
   duplicateIdsRejected ()
   ```

2. **Supersession coverage is set-like, not list-order-sensitive.**

   Reordered dispositions compile as a valid history:

   ```agda
   h80-81-reordered-valid : ValidHistory h80-81-reordered
   ```

3. **Duplicate disposition subjects are rejected.**

   Current assertion:

   ```agda
   duplicateDispositionRejected :
     ValidEntry
       (ε ▻ declare g80 ▻ declare g81)
       (supersede s80-81-duplicate-disposition)
       → ⊤
   duplicateDispositionRejected ()
   ```

---

## 6. Ecosystem-reuse policy agreed in this session

The user explicitly requested a standing engineering policy:

> Before reinventing something, always check whether Govenv, Agda/stdlib/external Agda libraries, Nix/Nixpkgs, or devenv already provide it.

This is an **operational engineering policy**, not itself a constitutional GV.

It is now materialized in the new root `AGENTS.md` in the spike worktree.

### 6.1 Reuse preference

Current intended preference:

```text
Govenv
→ Agda builtins / stdlib
→ mature external Agda library
→ Nixpkgs package *
→ explicit external input *
→ bespoke Govenv implementation

* Nixpkgs packages and non-Agda external inputs are only for
  development tools and runtime dependencies.
```

External Agda libraries belong to the formal implementation layer and are not limited to dev/runtime roles.

Before custom code, be able to explain why the ecosystem alternative:

```text
- is semantically insufficient, or
- weakens the model, or
- introduces disproportionate complexity, or
- imposes an unjustified dependency/upgrade.
```

### 6.2 Preserve the Govenv frontend

Reuse should normally happen **below** the Govenv domain/frontend.

Do not distort concepts like:

```text
GV
P
Proposition
Obligation
Disposition
glyphs
roadmap/changelog semantics
```

merely to fit a library API.

Internal representation may become more dependent/sophisticated while the public Govenv DSL remains stable.

Pattern synonyms, modules, hidden arguments, adapters, and projections are all acceptable tools for preserving the frontend.

If an ecosystem abstraction reveals a genuinely better **domain model**, make that conceptual change explicitly rather than accidentally leaking an implementation detail into the frontend.

### 6.3 Refactoring authority

The user explicitly authorized broad refactoring when it removes reinvented infrastructure in favor of mature ecosystem capabilities.

Refactoring may cross:

```text
kernel
adapters
projections
materializations
Nix
devenv
tests
documentation
```

when that is the coherent way to remove duplication.

Do not preserve obsolete machinery with meaningless compatibility wrappers.

---

## 7. Literate Agda policy

A major decision from this session:

> `*.lagda.md` is for governance and semantic/constitutional documentation, not implementation manuals.

This is also recorded in `AGENTS.md`.

Literate Agda should contain:

```text
- governance
- governed domain facts
- constitutional rationale
- human-readable meaning of formal decisions
- enough Agda to state/establish those governed facts
```

It should **not** expose incidental details merely to explain implementation:

```text
- plumbing
- backend mechanics
- library-specific APIs
- rendering algorithms
- materializer internals
- fetch mechanics
- incidental Nix code
```

When implementation details are necessary to establish a governed property, expose only the semantic boundary needed by governance.

The intended split is:

```text
.lagda.md
    governs WHAT and WHY

kernel/model .agda
    represents the formal implementation machinery

projection/materializer
    decides HOW to encode it

devenv.nix
    executes the generated representation
```

`AGENTS.md` is the operational materialization of contributor/agent policy.

Process heuristics and implementation-selection guidance belong in `AGENTS.md`, unless later promoted into a real governed property.

---

## 8. Dependency authority / package-manager decisions

Another explicit policy:

> Never use language/application package managers as dependency authorities in the codebase. Centralize dependency acquisition/resolution through Nix/devenv.

Examples explicitly excluded as dependency authorities:

```text
npm
pnpm
yarn
pip
Poetry
uv
Cargo
Cabal
Stack
Bundler
and equivalents
```

This does **not** mean an executable from one of those ecosystems can never run.

Example:

```text
node provisioned by Nix → may execute
npm install / npx downloading deps → not allowed as dependency authority
```

Nixpkgs should be preferred for development/runtime packages when adequate.

External Agda libraries may be formal dependencies, but should be immutably pinned by governed source.

---

## 9. What should be GV vs what stays policy

Agreed criterion:

> Policy governs how an agent/developer searches for and chooses an implementation.  
> A GV governs which repository/system states/effects are constitutionally permitted.

### Keep in `AGENTS.md`

Examples:

```text
search Govenv first
search stdlib before external Agda libs
prefer mature ecosystem primitives
prefer Nixpkgs when adequate
do not reinvent the wheel
refactor freely when reuse improves the codebase
preserve frontend while refactoring internals
.lagda.md is governance, not implementation documentation
```

These involve judgment or engineering workflow.

### Candidate constitutional properties

The following are much more appropriate as future governed Propositions:

```text
- Govenv has a single dependency authority through Nix/devenv.
- Ecosystem package managers cannot acquire/resolve project dependencies.
- Every external dependency has a governed update policy.
- Versioned environment configuration is a governed materialization.
- Resolver state is derivable/transient and not versioned.
- Environment evaluation is reproducible without impurity.
- Nixpkgs/non-Agda external dependencies are limited to dev/runtime roles.
```

Do **not** add these as new GVs using the old lifecycle model before the constitutional-history redesign is stable.

The first new GV using the new model may reasonably be dependency-authority governance.

---

## 10. devenv / Nix conclusions validated in this session

The user strongly prefers the target state:

```text
versioned:
  devenv.nix   ← materialized by Govenv

not versioned:
  devenv.yaml  ← absent
  devenv.lock  ← transient, gitignored
```

Important correction history:

- A proposal to materialize `devenv.yaml` was rejected.
- The user explicitly wants to avoid a versioned `devenv.yaml` and `devenv.lock`.
- `devenv.lock` may exist locally if it is a deterministic derived artifact and is ignored.

### 10.1 Pure Nix validation

A direct Nix test showed that pure evaluation can import a remotely fetched pinned source when URL/revision and hash are fixed.

A `builtins.fetchTarball`-style test under pure evaluation successfully produced:

```text
hello-2.12.3
```

So “pure” does not require every source to already be local; it requires the source to be sufficiently fixed/reproducible.

### 10.2 devenv without `devenv.yaml`

Tested with only `devenv.nix`.

devenv 2.3 generated a local `devenv.lock` automatically.

Therefore:

```text
no devenv.yaml
```

does **not** mean the devenv CLI stops having resolver state.

But that is acceptable if the lock is deterministic and unversioned.

### 10.3 Deterministic lock regeneration

A no-`devenv.yaml` experiment was run twice with the same pinned devenv bootstrap.

The lockfile hashes were identical:

```text
first  = 3838d7aeadbb540ea9e3b627fabac54da05c5c4cdf01db583d0b013e344656a7
second = 3838d7aeadbb540ea9e3b627fabac54da05c5c4cdf01db583d0b013e344656a7

LOCK_IDENTICAL=yes
```

Observed resolved revisions in that test:

```text
devenv
0fd5e6d3a9b2ae6f10205a3e95e0ca58d526c5a6

devenv-nixpkgs
c2f38fe7f9e04d9aadd354d380f2bd40531d9737

nixpkgs
c7def046b9a883d46974757852106483d741586f
```

The correct conceptual interpretation is:

```text
same governed devenv.nix
+ same pinned devenv bootstrap
─────────────────────────────────
same resolved environment
```

The lock is not the constitutional authority.

### 10.4 Current `.gitignore`

At the latest check, the worktree `.gitignore` contained:

```text
.devenv/
```

but did **not** yet contain `devenv.lock`.

The target design says `devenv.lock` should be ignored once the migration reaches that target state.

Do not silently assume this has already been implemented.

### 10.5 `devenv.nix` as materialization

Target semantics:

```text
Govenv governed source
      ↓
materializer
      ↓
devenv.nix
      ↓
devenv
      ↓
devenv.lock  (local/transient/derived)
```

`devenv.nix` should not become the semantic source of dependency policy.

Dependency/update-policy semantics live in governed source.

Implementation details such as exact fetching/rendering mechanics remain outside literate governance documentation.

---

## 11. UpdatePolicy discussion

Originally there was an idea that every `devenv.yaml` input should carry a human `# NOTE:` saying when a bump is allowed.

That idea evolved.

Since the target has no versioned `devenv.yaml`, and because `.lagda.md` should carry governance/rationale rather than materialized comments, the stronger design is:

```text
governed dependency
├── immutable pin
├── role
└── UpdatePolicy
```

with the **policy itself represented in governed/formal source**, and human rationale documented in literate Agda.

Do not treat a generated Nix comment as authority.

Do not duplicate governance semantics into generated `devenv.nix`.

Conceptually:

```text
formal fact / update constraints  → governed Agda
human rationale                   → literate Agda prose
runtime projection                → devenv.nix
transient resolver state          → devenv.lock
```

The exact implementation types for dependencies/update policy are **not fixed yet**.

Do not prematurely put low-level things such as:

```text
GitHub owner/repo strings
fetchTarball API
sha256 rendering
backend fetch syntax
```

into literate governance documents.

---

## 12. Existing GVs relevant to the dependency/materialization migration

Current roadmap around this area includes at least:

### GV71

Current wording observed:

> Restrict handwritten versioned repository content to Agda and Markdown only. Any generated or governed materialization may use its required target format. Until GV38 is completed, the only handwritten bootstrap escape hatch is root-level `devenv.nix`, `devenv.yaml`, and `devenv.lock`; all other implementation languages and handwritten configuration formats, including Nix elsewhere, are forbidden.

### GV72

Current wording observed:

> Require every versioned repository artifact not permitted as handwritten source by GV71, except the temporary root-level `devenv.nix`, `devenv.yaml`, and `devenv.lock` bootstrap escape hatch, to be produced by exactly one governed `Govenv.Materialization.*` definition and verified against its materialized state; transient `.govenv` state is forbidden from being versioned.

Target state will eventually require revisiting/superseding these because:

```text
devenv.nix  → governed materialization
devenv.yaml → absent
devenv.lock → transient + ignored
```

This removes much of the current bootstrap exception rather than adding more exceptions.

Do not perform that constitutional migration until the new Proposition/history model is stable.

---

## 13. Agda ecosystem investigation

Standing policy: inspect the actual available ecosystem before inventing abstractions.

Current local evaluation:

```text
agdaPackages.standard-library.version = 2.3
agda.version                           = 2.8.0
```

Relevant stdlib 2.3 modules confirmed present:

```text
Data.List.Membership.DecPropositional
Data.List.Membership.Propositional

Data.List.Relation.Unary.All
Data.List.Relation.Unary.Any
Data.List.Relation.Unary.AllPairs

Data.List.Relation.Unary.Unique.Propositional
Data.List.Relation.Unary.Unique.DecPropositional

Data.List.Relation.Binary.Subset.DecPropositional

Data.List.Relation.Binary.Permutation.Propositional
Data.List.Relation.Binary.Prefix.*
Data.List.Relation.Binary.Sublist.*
Data.List.Relation.Binary.Disjoint.*

Data.Nat.Properties

Relation.Nullary
Relation.Nullary.Decidable
```

Useful concrete APIs verified:

```agda
Data.Nat.Properties._≟_

Data.List.Membership.DecPropositional _≟_
  _∈?_
  _∉?_

Data.List.Relation.Unary.Unique.DecPropositional _≟_
  Unique
  unique?

Data.List.Relation.Unary.All
  all?

Data.List.Relation.Unary.Any
  any?

Data.List.Relation.Binary.Subset.DecPropositional _≟_
  _⊆?_

Relation.Nullary.Decidable
  does
```

For Boolean list folds in stdlib 2.3, use:

```agda
Data.Bool.ListAction.all
Data.Bool.ListAction.any
```

Do **not** use deprecated `Data.List.Base.all/any`; the V2 initially did so, produced deprecation warnings, and was corrected.

### Why stdlib reuse materially improved the model

The V2 now uses stdlib to provide:

```text
Nat equality
membership
filtering
all/any traversal
uniqueness
subset checks
```

Two semantic bugs/weaknesses in the baseline were exposed:

1. Baseline freshness only checked IDs against the previous history, so duplicate Proposition IDs inside one new declaration could slip through.
   V2 adds `Unique`.

2. Baseline supersession coverage used positional list equality, so semantically identical dispositions in a different order could fail.
   V2 models set-like coverage with subset in both directions plus uniqueness.

This is exactly the kind of improvement the reuse-first policy is intended to produce.

---

## 14. Current V2 validity design

The V2 still contains:

```agda
data Valid : Bool → Set where
  valid : Valid true

ValidEntry : History → HistoryEntry → Set
ValidEntry h (declare d) = Valid (...)
ValidEntry h (establish e) = Valid (...)
ValidEntry h (abandon p) = Valid (...)
ValidEntry h (supersede s) = Valid (...)
```

This is the major remaining design smell.

The desired next experiment is proposition-first validity.

Potential direction:

```agda
DeclarationValid : History → GovernanceDeclaration → Set
EstablishmentValid : History → Establishment → Set
AbandonmentValid : History → Nat → Set
SupersessionValid : History → Supersession → Set

ValidEntry : History → HistoryEntry → Set
```

and separate deciders:

```agda
declarationValid? : ...
establishmentValid? : ...
abandonmentValid? : ...
supersessionValid? : ...

validEntry? :
  (h : History) →
  (entry : HistoryEntry) →
  Dec (ValidEntry h entry)
```

Use stdlib proposition-level relations (`All`, membership, `Unique`, subset, etc.) wherever they fit.

The goal is that Booleans become an executable **decision projection**, not the formal definition of validity.

Do not prematurely migrate until canonical scenarios prove the proposition-first version preserves intended semantics.

---

## 15. `CurrentResponsibility` / query-layer caution

A stronger desired signature discussed earlier is:

```agda
currentResponsibility :
  (h : History) →
  (p : PropositionRef) →
  Live h p →
  GovernanceRef
```

The current spike uses:

```agda
History → Nat → Maybe Nat
```

for convenience.

This may eventually belong in a query/projection layer rather than the minimal historical kernel.

Do not store current owner/responsibility as source state.

It should remain derivable from declaration + preservation transitions.

---

## 16. Assurance vs evidence

Do not conflate historical evidence persistence with current repository satisfaction.

Useful distinction:

```text
Evidence
  proves/records constitutional establishment historically

Assurance
  checks current repository state against current ActiveObligations
```

This fits the intent behind GV74.

This area has **not** been fully redesigned yet. Avoid solving it prematurely while the history model is still stabilizing.

---

## 17. Things explicitly rejected / avoid reintroducing

Do not reintroduce:

```text
ItemState as constitutional truth
GV lifecycle state as fundamental state
ObligationState
pending/staged Obligation
operative Bool
P(GV, localIndex) identities
TransitionId
general GV dependency DAG
stored owner
stored origin
“superseded GV state”
advanced as constitutional event
manual changelog/release state inference when history can derive it
```

Also avoid making `.lagda.md` into implementation documentation.

---

## 18. Commands known to work for the spike

Baseline scenario check without stdlib dependency:

```bash
cd /home/klarkc/Sources/klarkc/govenv-history-spike

nix shell nixpkgs#agda -c sh -c \
  'agda -i. -isrc spike/ConstitutionalHistoryScenarios.agda'
```

Stdlib V2:

```bash
cd /home/klarkc/Sources/klarkc/govenv-history-spike

STDLIB=$(nix build --no-link --print-out-paths \
  nixpkgs#agdaPackages.standard-library)

nix shell nixpkgs#agda nixpkgs#agdaPackages.standard-library -c sh -c \
  "agda -i. -isrc -i$STDLIB/src spike/ConstitutionalHistoryStdlib.agda &&
   agda -i. -isrc -i$STDLIB/src spike/ConstitutionalHistoryStdlibScenarios.agda"
```

At the end of this session the V2 and V2 scenarios compiled with exit code 0 and no warnings.

A project/devenv command used earlier was:

```bash
nix run github:cachix/devenv/v2.3 -- shell bash -lc \
  'agda -i. -isrc spike/ConstitutionalHistory.agda'
```

but for isolated spike validation, direct `nix shell nixpkgs#agda ...` was faster and avoided unrelated devenv bootstrap/fetch delays.

---

## 19. Current `AGENTS.md` intent

`AGENTS.md` in the spike worktree is currently untracked and about 88 lines.

It now contains these sections/concepts:

```text
Reuse-first engineering policy
Preserve the Govenv frontend
Literate Agda is for governance
Refactoring authority
Dependency discipline
devenv generated state
Centralized dependency management
```

Important current statements:

```text
- It is operational policy, not automatically a Governance item.
- Search Govenv → Agda/stdlib → external Agda → Nixpkgs → external input → bespoke.
- Reuse should happen below the Govenv frontend.
- .lagda.md is governed semantic documentation, not an implementation manual.
- Agents may refactor broadly to remove bespoke reinventions.
- No versioned devenv.yaml is part of the target environment.
- devenv.nix is a governed materialization.
- devenv.lock may be generated locally when deterministic but must not become versioned authority.
- Language/application package managers are not dependency authorities.
```

Review this file before committing because some wording is deliberately “target-state policy” while the current repository still has the old bootstrap files/versioning model.

---

## 20. Recommended next steps

Proceed in this order:

### Step 1 — proposition-first validity

Refactor only the V2 spike:

```text
Bool-defined validity
→ proposition-defined validity + Dec
```

Keep all canonical scenarios and extra stdlib semantic tests compiling.

### Step 2 — inspect stdlib before each custom helper

Especially investigate whether proposition-level forms can use:

```text
All
Any
Unique
membership
Subset
Disjoint
AllPairs
Permutation
Prefix
```

rather than writing local recursive predicates.

### Step 3 — reassess `currentResponsibility`

Decide whether it belongs in the core history module or a query layer.

Try the stronger dependent signature if it materially simplifies invalid states.

### Step 4 — only after the spike is stable, design migration topology

Plan how existing kernel/GVs map into:

```text
Proposition
Evidence
Obligation
HistoryEntry
ValidHistory
Supersession/Disposition
derived projections
```

Do not edit the real kernel before this plan is coherent.

### Step 5 — dependency-authority governance

Once the new model is usable for real constitutional additions, consider a new Governance decision with Propositions around:

```text
single dependency authority
no ecosystem package-manager resolution
governed update policies
devenv.nix as materialization
transient resolver state
pure/reproducible evaluation
dev/runtime restriction for Nixpkgs/non-Agda external deps
```

Then supersede/reformulate the relevant parts of GV71/GV72 as needed.

---

## 21. User preferences / working style relevant to continuation

- Prefer conceptual correctness over preserving implementation accidents.
- Be willing to refactor aggressively when ecosystem reuse gives a better foundation.
- Preserve the Govenv frontend/domain semantics while refactoring internals.
- Test risky model changes in isolated Agda spikes before touching the real kernel.
- Use the actual pinned/available Agda/Nix/devenv ecosystem instead of assuming latest docs/APIs.
- Treat `.lagda.md` as governance/rationale, not an implementation tutorial.
- Do not create GitHub releases without explicit user approval.
- Keep the user informed during multi-step work, but avoid noisy low-level narration.
- Do not ask repeated questions whose answers are already present in the handoff/repository state.

---

## 22. One-sentence state summary

The constitutional-history model now has a compiling stdlib-backed V2 with history-derived state, stronger uniqueness/set-coverage semantics, and all canonical scenarios green; the next work is to replace `Valid (Bool)` with proposition-level validity plus decidability before migrating anything into the real Govenv kernel.
