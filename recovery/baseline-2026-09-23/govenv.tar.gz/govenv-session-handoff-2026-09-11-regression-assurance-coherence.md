# Govenv session handoff — 2026-09-11

## Repositório e regras de trabalho

Repository: `klarkc/govenv`

Checkout principal local:
`/home/klarkc/Sources/klarkc/govenv`

Device:
`solo098`

Regras importantes:
- Nunca fazer merge de PR sem autorização explícita do usuário.
- Nunca criar/publicar release sem aprovação explícita do usuário, exceto pelo fluxo normal do Release Please iniciado pelo próprio merge do PR canônico de release.
- Nunca criar tag/release concorrente manual quando Release Please é o mecanismo esperado.
- Nunca editar manualmente PR do Release Please.
- Nunca marcar GV como `✓` só porque implementação existe; completion precisa de evidence governada.
- Não existe `amended`; qualquer correção exige supersession.
- Governance identities são append-only.
- Nunca modificar o wording de GV71.
- Manter WIP de Assurance isolado de release/materialization.

## WIP local que deve permanecer isolado

No checkout principal:

```text
 M src/Govenv/Kernel/Assurance.agda
?? Govenv/Assurance/GV60.lagda.md
```

Não misturar esses arquivos com outros PRs.

Inherited completions atuais:

```text
GV0 GV1 GV2 GV19 GV22 GV44 GV45 GV51 GV60
```

`migrationComplete assurances ≡ false`.

GV74 continua pendente.

---

# Release architecture estabelecida

Commits relevantes:

```text
1664c89 gov(release): separate canonical and GitHub projections
78923b0 chore(materialize): update governed materializations
d18a4a3 gov(release): decouple canonical changelog target
```

Targets do mesmo typed release document:

1. `CHANGELOG.md`
   - materialização canônica versionada
   - Markdown portátil

2. Release Please PR body
   - projeção GitHub enriquecida

3. Published GitHub Release body
   - parte do changelog carregado
   - substitui governance marker section em posição governada
   - valida external state via read-back equality

Boundary arquitetural:

```text
Materialization/domain
  possui semântica, estrutura, ordering, policy e capability decisions

Projection
  possui apenas representação target-format

Adapter
  possui apenas efeitos, observação e read-back
```

Nunca interpretar `CHANGELOG.md` de volta como governance semantics.

---

# Release v0.2.0

Usuário mergeou pessoalmente o Release Please PR #2.

Release:
- tag `v0.2.0`
- release ID `387010583`
- merge commit `0e03a8cfe4c4c89f83f390346e9ff26b0d5389fc`
- publicado `2026-09-11T12:12:10Z`
- corpo contém Governance impact enriquecido
- release reportado immutable

Fluxo esperado:

```text
merge canonical Release Please PR
→ Materialize
→ Release workflow
→ Release Please
→ create release
→ materialize published release governance
```

---

# PR #4 — merged

PR #4:
`gov(release): render sparse governance deltas`

Merged em:
`2026-09-11T16:24:08Z`

main após merge:
`e0b59aafd2e56f753ce52e0fc790377fa70936e4`

Mudança principal:
`ReleaseDocument` não carrega mais raw `Roadmap`; materialization resolve a semântica antes da Projection.

Modelo:

```agda
record PhaseChange : Set where
  constructor phaseChange
  field
    previousPhase : SomePhaseId
    currentPhase : SomePhaseId

record PropositionChange : Set where
  constructor propositionChange
  field
    previousProposition : String
    currentProposition : String

data SupersessionDelta : Set where
  resolvedSupersession :
    SomeGovernanceId →
    SomeGovernanceId →
    Maybe PhaseChange →
    Maybe PropositionChange →
    SupersessionDelta

  unresolvedSupersession :
    SomeGovernanceId →
    GovernanceRef →
    SupersessionDelta
```

GV83 continua `◇`.

---

# Regressão do release pipeline

Falha observada em `Materialize release governance`:

```text
Invalid roadmap snapshot item: item 0 phase 0 done "Literate `Govenv.lagda.md` closure root."
```

Root cause:
- snapshot serializer usa `primShowString`
- strings saem com aspas literais
- `release-governance.sh` usava regex Bash onde as aspas não eram tratadas como caracteres literais
- precisava usar `\"` no regex

Por que só apareceu agora:
- `v0.1.0` não tinha roadmap snapshot governado
- `v0.2.0` usou fallback
- `0.2.1` foi o primeiro release que precisou ler um snapshot v2 real de `v0.2.0`

Descoberta arquitetural:
- a gramática do snapshot está duplicada em Bash
- `roadmap-evolution.sh` e `release-governance.sh` têm parsers próprios
- um funcionava e o outro quebrou
- isso evidencia que codec semantics ainda estão fora do boundary canônico

Direção definitiva desejada:

```agda
decodeSnapshot (encodeSnapshot s) ≡ success s
```

Adapter deve apenas observar bytes e chamar decoder governado.

---

# PR #5 — hotfix do parser

PR #5:
`fix(release): parse quoted roadmap snapshot strings`

Branch:
`fix/release-snapshot-string-parser`

Commit:
`8dadeb6dd066dd92f29b170ac45b0a7a0a3a7818`

Refs:
`GV59 GV70 GV77`

Validação:
- CI Test #82 passou
- CodeRabbit passou
- reprodução local contra snapshot real de `v0.2.0`:
  - `parsed_items=78`
  - `bad=0`

Usuário informou no fim da sessão:

> merge do 5 feito

Portanto tratar PR #5 como merged e confirmar no início da próxima sessão.

Próximo passo imediato:
- verificar merge do #5
- observar main
- observar Materialize
- observar Release workflow
- confirmar que `Materialize release governance` agora passa
- confirmar que Release Please atualiza PR #3
- NÃO mergear PR #3 sem aprovação explícita do usuário

---

# Release Please PR #3

PR:
`#3 — chore(main): release 0.2.1`

Antes do merge do #5:
- aberto
- gerado por `github-actions[bot]`
- não draft
- corpo estava sem enriched governance porque o adapter falhou

Não editar manualmente.

Não mergear até autorização explícita do usuário para release `0.2.1`.

---

# GV84 e GV85

## GV84 — observed regression closure

Princípio aprovado:

Não é possível garantir genericamente que um agente reconheça todo bug como regressão de invariante.

É possível garantir:

```text
once a contradiction is recorded as an ObservedRegression
→ it cannot be silently fixed and forgotten
```

Lifecycle desejado:

```text
ObservedRegression
      ↓
counterexample preserved
      ↓
diagnose missing / wrongly scoped / duplicated semantic boundary
      ↓
strengthen assurance OR supersede overstated governance
      ↓
candidate validation rejects recurrence
      ↓
closed
```

Wording atual do PR #6:

```text
GV 84 "Make observed invariant regressions counterexample-closing: once a contradiction to a governed or relied-upon invariant is recorded as an observed regression, its repair is incomplete until the counterexample is preserved as governed evidence, the missing or incorrectly scoped assurance boundary is corrected or overstated governance superseded, and candidate validation rejects recurrence before the affected workflow may succeed." ◇
```

## GV85 — standalone `fix` como sinal conservador

Decisão aprovada:
- detectar palavra isolada `fix`
- case-insensitive
- em qualquer commit governado
- não apenas Conventional Commit type `fix`

Fluxo:

```text
standalone word "fix"
        ↓
Regression evidence?
  ├─ yes → ok
  └─ no
      ↓
explicit non-regression exemption?
  ├─ yes → rationale required
  └─ no → reject
```

Exemption:
- resolve falsos positivos
- nunca pode discharge uma `ObservedRegression` aberta

Wording atual:

```text
GV 85 "Treat the case-insensitive standalone word `fix` in governed commit messages as a conservative regression signal: candidate commit validation must reject it unless the commit references governed regression evidence or carries an explicit justified non-regression exemption; no exemption may discharge an unresolved observed regression." ◇
```

---

# PR #6 — NÃO mergear ainda

PR #6:
`gov(assurance): define regression closure policy`

Branch:
`gov/gv84-counterexample-closure`

Commit:
`c847e346625e8d73f69b5ecd8f2c73c5117af7bf`

Status antes do handoff:
- draft
- CI Test #84 passou
- CodeRabbit passou
- mergeable
- mas revisão global mostrou mudanças necessárias

Importante:
- GV84 em P1 faz sentido
- GV85 está na fase errada; deve ir para P3

---

# Global coherence review

Revisão feita sobre o branch do PR #6 sem alterar a constituição.

Estrutura:
- 86 GVs
- IDs 0..85
- sem gaps
- sem duplicatas
- 23 `✓`
- 17 `↪`
- 46 `◇`

Fases:
- P0 `■`
- P1 única `▣`
- P2–P6 `□`

Supersession chains válidas estruturalmente:
- targets existem
- IDs maiores
- nenhuma cadeia atual termina em `×`
- nenhum `amended`

Cadeias atuais:

```text
47→68
49→69
9→57
10→58
11→59
17→61→62
14→60
23→63
48→70
76→78
7→55
8→56
25→64
27→65
28→66
40→67
```

---

# Achado 1 — counterexample real contra GV54 `✓`

GV54 exige imutabilidade de identidade, definição e owning phase.

Mas snapshot guarda:

```agda
snapshotItemPhase : Nat
```

e não a descrição completa da `PhaseId`.

Counterexample Agda criado e type-checked:

```text
before:
P1 "phase"

after:
P1 "renamed"
```

mesmo GV, mesmo phase index.

`governanceDelta` aceitou como `validDelta`.

Consequência:
- GV54 proposition é mais forte que a assurance atual
- deve virar um caso canônico de GV84
- snapshot precisa preservar identidade completa da fase
- assurance de GV54 precisa ser fortalecida
- não alterar wording de GV54; ele já está correto

---

# Achado 2 — supersession target liveness não é garantido

Roadmap integrity hoje verifica:
- target existe
- target ID é maior

Não verifica:
- replacement chain termina em entidade viva
- target não termina eventualmente cancelled

O roadmap atual não possui esse problema, mas o modelo permite.

Precisa de decisão semântica antes de virar nova governance.

---

# Achado 3 — Evidence não está ligada à exact Claim

Tipos atuais:

```agda
record StaticEvidence (idx : Nat) : Set₁
record ObservedEvidence (idx : Nat) : Set₁
```

`completionCoverage` usa apenas o índice.

Counterexample Agda foi criado e type-checked:

```agda
trivialEvidence : StaticEvidence 99
trivialEvidence = staticEvidence ⊤ tt
```

Isso pode cobrir conceitualmente:

```text
GV 99 "arbitrarily strong claim" ✓
```

apenas porque ambos usam índice 99.

Portanto, `"a proof exists"` não basta.

Direção correta:

```text
exact governed Claim
        ↓
Evidence Claim
```

em vez de:

```text
GV number
   ↓
arbitrary Evidence
```

Esse é blocker para considerar GV74 concluída.

---

# Achado 4 — GV62 / Architecture está desatualizada

Roles atuais:

```text
closure
constitution
kernel
materialization
projection
adapter
generated
```

Não existe role `assurance`.

`Govenv/Assurance/*` cai como constitution, mas assurances existentes importam:
- Projection
- Materialization
- Project
- Kernel

Enquanto a matriz declarada permite `constitution → kernel`.

Adapters também importam:
- Kernel
- Materialization
- Projection
- Govenv.Roadmap

mas arquitetura declara apenas `adapter → projection`.

Conclusão:
- GV62 não pode ser simplesmente enforced sobre a matriz atual
- provavelmente precisa ser superseded por uma nova GV arquitetural
- novo modelo deve incluir explicitamente `assurance`
- assurance pode depender das camadas puras que prova
- production layers não devem depender de assurance
- adapter pode consumir semantics governadas sem possuir semantics

---

# Achado 5 — GV85 deve ir para P3

GV85 depende semanticamente de:
- GV66 commit policy
- GV29 candidate commit validation
- GV30 Git hook

Portanto deve sair de P1 e ir para P3 antes do merge do PR #6.

GV84 permanece em P1.

---

# Achado 6 — ReleaseKind provenance

Kernel contém:

```agda
data ReleaseKind : Set where
  major minor patch : ReleaseKind
```

GV55 pretende:

```text
major/minor → governance progress required
patch → exempt
```

Mas não há garantia explícita de origem de `ReleaseKind`.

Direção correta:

```text
old SemVer + new SemVer
      ↓
pure governed classifier
      ↓
ReleaseKind
```

Adapter só observa versões.

Isso pode ser requisito de fechamento de GV55/GV56/GV59 sem necessariamente criar nova GV.

---

# Achado 7 — release authorization não está explicitamente governada

Regra operacional já estabelecida:

```text
Release Please creates/updates canonical release PR
        ↓
user explicitly merges it
        ↓
release becomes authorized
```

Além disso:
- automation/adapters podem preparar/materializar
- não podem bypassar autorização
- não pode existir competing release path

Provavelmente precisa de nova GV em P1.

Formulação conceitual:

```text
Published releases must be causally authorized by the explicit merge
of the canonical Release Please pull request; automation and adapters
may prepare and materialize release state but may neither bypass that
authorization nor create a competing release path.
```

---

# Achado 8 — dependências entre GVs não são tipadas

Hoje ordem interna das fases é editorial.

Exemplos de dependências reais:

```text
GV58 depends on GV57
GV72 depends on GV71
GV81 depends on GV78/GV80/GV77
GV56 depends on GV55
GV29 depends on GV53/GV66
GV30 depends on GV29
GV32 depends on GV31
GV33 depends on incremental evaluator
```

Possível modelo futuro:

```agda
DependsOn GV81 (GV78 ∷ GV80 ∷ GV77 ∷ [])
```

Regra:

```text
GV cannot become established
while prerequisite governance is not established
```

Isso seria especialmente útil para agentes.

---

# Novas governanças discutidas mas ainda não materializadas

## Capability evidence / proof-carrying activation

A ideia `"every feature needs proof"` foi refinada.

Não é possível detectar genericamente a semântica de uma feature em um diff arbitrário.

O que é garantível:
- capability governada possui estado explícito
- transição para active/releasable exige evidence

Modelo conceitual:

```agda
data CapabilityState : Set where
  absent experimental active : CapabilityState
```

Então:

```text
experimental → active
        ↓
EstablishmentEvidence required
```

Distinção:

```text
implemented ≠ established ≠ active/releasable
```

Provavelmente P1.
Foi chamada provisoriamente de GV86.

## Semantic commit classification

GV66 governa gramática/metadata, mas não garante:

```text
declared commit type
≡
semantic nature of governed candidate delta
```

Desejado:

```text
feat        → capability introduction / expansion
fix         → regression repair
refactor    → behavior-preserving
docs        → documentation-only
test        → evidence/test-only
materialize → canonical materialization-only
```

Checker compara declared type com governed candidate delta.

Isso só pode ser garantido para semântica já modelada por Govenv.

Provavelmente P3.
Foi chamada provisoriamente de GV87.

## Earliest sound enforcement

Proposta do usuário:

> todo item de governança deve ser antecipado sempre que possível para o ponto mais próximo da linguagem/da origem da informação.

Canonical `govenv check` continua autoritativo.

Ordem conceitual:

```text
1. impossibilidade estrutural em Agda
2. static proof/reduction
3. incremental evaluator
4. LSP/editor
5. pre-commit / commit-msg hook
6. govenv check
7. CI/workflow
8. external/runtime observation
```

Princípios:

```text
early validation ≠ independent policy
early validation ≠ final authority
```

Mesma regra governada deve alimentar Agda/LSP/hook/check/CI sem duplicação semântica.

Provavelmente P4.
Foi chamada provisoriamente de GV88.

## Future feature heuristics

Depois de semantic commit classification, considerar sinais conservadores:

```text
add
introduce
support
enable
implement
expose
```

com exemption explícita + rationale.

Não criar isso antes do modelo semântico de commits.
Talvez futura GV89.

---

# Distribuição sugerida por fase

## P1 — Formal governance model and repository closure
- GV74
- GV84
- exact Claim ↔ Evidence binding
- capability activation requires evidence
- release authorization
- architecture/repository closure

## P2 — Pure repository evaluator
- pure rules/verdicts/obligations
- provenance/source mapping

## P3 — govenv check and commit governance
- GV53
- GV66
- GV29
- GV30
- mover GV85 para cá
- semantic commit classification
- commit heuristics

## P4 — Incremental governance
- GV31
- GV32
- GV33
- GV34
- earliest-sound-enforcement

P5/P6 permanecem coerentes no desenho atual.

---

# GVs relevantes — wording atual

GV71 — NEVER MODIFY:

```text
GV 71 "Restrict handwritten versioned repository content to Agda and Markdown only. Any generated or governed materialization may use its required target format. Until GV38 is completed, the only handwritten bootstrap escape hatch is root-level `devenv.nix`, `devenv.yaml`, and `devenv.lock`; all other implementation languages and handwritten configuration formats, including Nix elsewhere, are forbidden." ◇
```

GV72:

```text
GV 72 "Require every versioned repository artifact not permitted as handwritten source by GV71, except the temporary root-level `devenv.nix`, `devenv.yaml`, and `devenv.lock` bootstrap escape hatch, to be produced by exactly one governed `Govenv.Materialization.*` definition and verified against its materialized state; transient `.govenv` state is forbidden from being versioned." ◇
```

GV73:

```text
GV 73 "Require every persisted supporting artifact, including snapshots, fixtures, baselines, schemas, test vectors, and evidence, to be colocated with the module that semantically owns it; catch-all artifact directories are forbidden unless the artifact is genuinely project-global." ◇
```

GV74:

```text
GV 74 "Make governance completion evidence-bearing and persistent: a governance item may transition to `done` only when governed evidence establishes its proposition for the candidate repository state, and every non-superseded `done` item, including items completed before this rule, must remain satisfied in every subsequent valid repository state." ◇
```

GV75:

```text
GV 75 "Render release governance item changes as compact semantic diffs: remove redundant per-item progress labels, align before/after propositions for supersessions, visually distinguish only changed spans, and deterministically wrap or elide common context while preserving the full typed governance delta." ◇
```

GV77:

```text
GV 77 "Make `CHANGELOG.md` the canonical versioned portable materialization of each typed release entry, while the Release Please pull request and published GitHub Release project the same typed release content through a shared enriched GitHub renderer; external GitHub Release application must be verified by read-back equality." ◇
```

GV78:

```text
GV 78 "Define revision-aware documentation references for governed identities, lifecycle states, operators, transitions, and Agda modules and symbols, so every reference can be resolved against the repository revision or delta it semantically represents." ◇
```

GV79:

```text
GV 79 "Require every versioned Markdown artifact, including literate Agda, whether handwritten or materialized, to use valid navigable documentation references for governed concepts and Agda entities whenever such references are semantically exposed." ◇
```

GV80:

```text
GV 80 "Make Agda documentation addressable by immutable repository revision so revision-aware documentation references never depend on mutable current documentation." ◇
```

GV81:

```text
GV 81 "Require the Release Please pull request body to project governed and Agda documentation references using the revision-aware documentation reference model for the release delta it represents." ◇
```

GV82:

```text
GV 82 "Require the published GitHub Release body to project the same revision-aware governed and Agda documentation references as its release document." ◇
```

GV83:

```text
GV 83 "Render governance deltas sparsely: project only semantic dimensions whose values change, keep unchanged dimensions implicit, and retain only the identity and context required to unambiguously interpret the change." ◇
```

GV84:

```text
GV 84 "Make observed invariant regressions counterexample-closing: once a contradiction to a governed or relied-upon invariant is recorded as an observed regression, its repair is incomplete until the counterexample is preserved as governed evidence, the missing or incorrectly scoped assurance boundary is corrected or overstated governance superseded, and candidate validation rejects recurrence before the affected workflow may succeed." ◇
```

GV85:

```text
GV 85 "Treat the case-insensitive standalone word `fix` in governed commit messages as a conservative regression signal: candidate commit validation must reject it unless the commit references governed regression evidence or carries an explicit justified non-regression exemption; no exemption may discharge an unresolved observed regression." ◇
```

---

# Próxima sequência recomendada

1. Confirmar no GitHub que PR #5 foi merged.
2. Observar `main`.
3. Observar Materialize.
4. Observar Release workflow.
5. Confirmar que `Materialize release governance` passou.
6. Confirmar atualização automática do PR #3.
7. Inspecionar governance body do PR #3.
8. Não mergear PR #3 sem autorização explícita para release.
9. Revisar PR #6 antes de merge:
   - mover GV85 P1 → P3
   - incorporar consequências do coherence check
10. Projetar exact Claim ↔ Evidence binding.
11. Registrar phase-description mutation como observed regression contra GV54.
12. Registrar duplicated snapshot parser semantics como regression/closure issue de GV51.
13. Revisar/superseder GV62 com role explícito de Assurance.
14. Adicionar capability-evidence governance.
15. Adicionar semantic commit classification.
16. Adicionar earliest-sound-enforcement.
17. Considerar release-authorization governance.
18. Considerar typed GV dependencies.
19. Rodar novo coherence check global.
20. Só então considerar merge do PR #6.

---

# Conclusão arquitetural mais importante

Não basta:

```text
"a proof exists"
```

Precisamos:

```text
exact governed Claim
        ↓
Evidence indexed by that Claim
```

Não basta:

```text
"a validation exists"
```

Precisamos:

```text
one governed canonical rule
        ↓
Agda / LSP / hook / govenv check / CI
```

sem duplicar policy.

E para regressões:

```text
ObservedRegression
        ↓
permanent counterexample
        ↓
stronger assurance
```

A assurance deve crescer monotonicamente quando novos contraexemplos são descobertos.
