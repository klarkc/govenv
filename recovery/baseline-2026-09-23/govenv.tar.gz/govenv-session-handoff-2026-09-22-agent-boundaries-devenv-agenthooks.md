# Govenv session handoff — Agent boundaries, LSP, hooks, devenv, agenthooks

Date: 2026-09-22
Project: `klarkc/govenv`
Primary working language: Portuguese

## Purpose of this handoff

Continue the Govenv design in a fresh session without re-discovering the discussion around:

- Architecture becoming semantic (`Name`/definition-oriented), not path-oriented.
- Governance vs Protocol feedback.
- LSP diagnostics vs InlayHint.
- How coding agents actually consume diagnostics.
- Tool lifecycle hooks (`PreToolUse` / `PostToolUse`) as an earlier enforcement boundary.
- `agenthooks` as a provider-neutral interface.
- Git hooks and LSP as fallback boundaries.
- `devenv` as the likely operational control plane.
- Next investigation: how hard it is to generalize `devenv`'s existing Claude hooks into multi-agent hooks backed by `agenthooks`.

---

# 1. Current Govenv repo / PR state

Working repo/worktree previously used:

```text
/home/klarkc/Sources/klarkc/govenv-history-spike
```

Branch:

```text
spike/constitutional-history
```

PR:

```text
#32
gov(architecture): separate governance, protocol, and experiment domains
```

Relevant state from the previous session:

```text
HEAD=474a447
origin/main=8af5ae6
```

`origin/main` was an ancestor of HEAD.

The branch history was rewritten before merge to rename:

```text
OperationalPolicy -> Protocol
```

Force-pushed with lease.

PR #32 GitHub head was:

```text
474a447756cf178f113769cb35fa2ed2e714a96c
```

PR was mergeable.

Do NOT merge unless explicitly requested.

Checks previously passed:

```bash
nix run github:cachix/devenv/v2.3 -- tasks run govenv:check
```

Materialization command:

```bash
nix run github:cachix/devenv/v2.3 -- tasks run govenv:materialize
```

Generated materialization commit convention:

```text
chore(materialize): update governed materializations

Derived-From-Parent: true
Refs: GV44 GV51 GV90 GV92 GV93
skip-checks: true
```

If a generated `CHANGELOG` rebase conflict appears, skip the stale generated materialization commit and regenerate; do not hand-merge generated output.

---

# 2. Established architecture / domains

Current conceptual architecture:

- `Govenv.Governance` = constitutional normative authority (`*.lagda.md`).
- `Govenv.Protocol` = contributor/agent procedural normative authority (`*.lagda.md`), distinct from Governance.
- `Govenv.Architecture` = repository/semantic architecture; currently implemented too path-oriented and now recognized as needing redesign.
- `Govenv.Assurance/GV<n>/Counterexample/*.lagda.md` = canonical counterexamples/evidence.
- `Govenv.Materialization` = generated/canonical artifacts.
- `src/Govenv/Kernel` = established reusable semantics.
- `src/Govenv/Experiment` = candidate/experimental semantics.
- `src/Govenv/Projection`, `src/Govenv/Adapter`.
- `AGENTS.md` materializes from `Govenv.Protocol`; it is bootstrap/projection, NOT semantic authority.

Relevant candidate GVs introduced in PR work:

- GV96: versioned artifact authority.
- GV97: Governance vs Protocol + AGENTS materialization.
- GV98: expanded architecture roles.
- GV99: canonical counterexamples.
- Possible GV100 (`AGENTS.md <= 10,000 chars`) was discussed but not finalized.

Existing roadmap items relevant here:

- GV33: expose checker through LSP/editor loop.
- GV34: expose governance context/diagnostic deltas through MCP; future/optional.
- GV88: enforce every governable obligation at earliest sound information boundary while keeping `govenv check` authoritative.

Core governance model remains:

```text
Invariant -> Obligation -> Admin Materialize -> Evidence -> Assurance
```

Governance history/supersession/disposition already modeled. GV54 enforces governance identity/definition/phase immutability once introduced.

Because PR #32 is still unmerged, current candidate architecture can be corrected in-place before merge rather than creating later superseding governance just to fix this design.

---

# 3. Critical Architecture redesign already accepted

Current implementation is too filesystem-shaped.

Current `Kernel.Architecture` approximately:

```agda
record Area : Set where
  constructor area
  field
    root : String
    role : Role
```

with roles such as:

```text
closure constitution protocol kernel experiment
materialization projection adapter generated
```

Current `Architecture.lagda.md` classifies roots like:

```text
Govenv/
src/Govenv/Kernel/
src/Govenv/Experiment/
README.md
AGENTS.md
...
```

This conflates:

1. physical source/repository layout;
2. semantic architecture.

Accepted direction:

```text
SourceLayout
    FilePath -> source boundary / discovery

Architecture
    Agda semantic identity -> Role
```

The architecture should be born from Agda semantics, NOT paths.

Desired bridge:

```text
source file
   ↓ Agda elaboration
semantic module/name/definition
   ↓
Architecture classification
```

Important nuance discovered through Agda Reflection research:

- Agda Reflection exposes first-class `Name` (QName-like reflected declaration identity).
- It exposes reflected `Definition`.
- It does NOT currently expose a clean pure-Agda first-class `ModuleName` API in builtin Reflection.
- Therefore do not invent a fake `ModuleName` abstraction prematurely.

Likely architecture keys on reflected `Name`; `Definition` provides facts/body/category.

Do NOT freeze exact relation yet; candidates include ideas like:

```agda
RoleOf : Name → Role → Set
```

but `Area` may be redundant with `Role`, and non-Agda/generated/external artifacts also need typed treatment.

---

# 4. Reflection / dependency discovery: do not reimplement it in Govenv

Research on current Agda ecosystem found:

## agda-stdlib Reflection

Already provides substantial metaprogramming support:

- `Reflection.AST`
- `Reflection.AST.Name`
- `Reflection.AST.Definition`
- `Reflection.AST.Term`
- `Reflection.AST.Traversal`
- `Reflection.AnnotatedAST`
- `Reflection.TCM`
- `Reflection.TCM.Utilities`

Especially important:

```agda
record Actions : Set where
  field
    onVar  : Action ℕ
    onMeta : Action Meta
    onCon  : Action Name
    onDef  : Action Name
```

`Reflection.AST.Traversal` already performs de-Bruijn-aware traversal across reflected terms/clauses/patterns/telescopes/etc.

Therefore Govenv should NOT implement its own reflection AST walker.

`Reflection.TCM` gives APIs such as:

```agda
getType       : Name → TC Type
getDefinition : Name → TC Definition
```

plus `inferType`, `checkType`, `normalise`, `reduce`, `getContext`, etc.

## agda-stdlib-meta

Official repo exists and is useful, but current master depends on stdlib 2.3 / Agda 2.8 ecosystem and adds dependency/version coupling.

Recommendation so far:

> Do not add `agda-stdlib-meta` yet.
> Use regular stdlib Reflection first.

## Agda compiler module dependency graph

Agda already supports:

```text
--dependency-graph=FILE
--dependency-graph-include=LIBRARY
```

So Govenv should not independently reconstruct the whole module import graph unless needed.

Likely division:

| Need | Provider |
|---|---|
| definition identity | Agda `Name` |
| type | `Reflection.TCM.getType` |
| reflected definition/body | `getDefinition` |
| referenced defs/constructors | `Reflection.AST.Traversal` |
| module import graph | Agda compiler dependency graph |
| role/classification | Govenv |
| allowed role dependencies | Govenv |
| Governance/Protocol applicability | Govenv |

Current `devenv.nix` already has:

```nix
let
  agdaStdlib = pkgs.agdaPackages.standard-library;
```

So stdlib Reflection is already available without adding a new dependency.

---

# 5. LSP / ALS investigation — exact model

Important correction from earlier thinking:

```text
DocumentURI is transport identity, not Govenv semantic identity.
```

Correct semantic flow:

```text
editor text mutation
 -> load/typecheck
 -> Agda semantic environment/type checker
 -> semantic error + range
 -> interaction/LSP adapter
 -> editor
```

For example, changing:

```agda
f : Nat → Nat
f n = n

x : Nat
x = f zero
```

into:

```agda
f : Bool → Nat
f true  = zero
f false = zero

x : Nat
x = f zero
```

The text edit itself does not say “x broke”. Agda re-typechecks; `f zero` passes `Nat` where `Bool` is expected; a semantic type error is produced and surfaced.

Better Govenv model:

```text
                     Agda
                      |
             semantic environment
                      |
        module / definition / type
                      |
                   Subject/Focus
                      |
              relevant Context
```

LSP boundary:

```text
URI + Position
     |
     | locate
     v
Agda semantic entity
     |
     v
Focus/Subject
```

Then:

```text
LSP:
URI + Position
    -> Agda semantic focus
    -> resolveContext

CLI:
module / declaration / candidate
    -> semantic focus
    -> resolveContext

typechecking:
current Name / definition
    -> semantic focus
    -> resolveContext
```

LSP is an Adapter, not semantic authority.

---

# 6. Diagnostic Hint vs InlayHint — precise distinction

There are THREE distinct concepts:

```text
1. Diagnostic
   severity = Error | Warning | Information | Hint

2. textDocument/diagnostic
   pull protocol for Diagnostics

3. textDocument/inlayHint
   separate pull protocol for InlayHint[]
```

Important:

```text
DiagnosticSeverity.Hint ≠ InlayHint
```

## Diagnostics

Can arrive in classic PUSH mode:

```text
client edit
  ↓ didChange
server analyzes
  ↓ publishDiagnostics
client receives
```

Or via newer pull diagnostics:

```text
client
  ↓ textDocument/diagnostic
server
  ↓ Diagnostic[]
```

A Protocol item can be projected as:

```text
Diagnostic {
  severity = Hint
  range = semantic target range
  source = "govenv-protocol"
  code = "Pxx"
  message = ...
}
```

## InlayHint

Always fundamentally PULL:

```text
client sees visible range
  ↓ textDocument/inlayHint(document, range)
server
  ↓ InlayHint[]
```

A server can request refresh, but the client still has to pull the actual hints.

InlayHint is more UI/decorative, e.g. inline type/parameter annotations.

For coding agents, Diagnostics are generally much more useful than InlayHints.

---

# 7. ALS current limitations

Current Agda Language Server (ALS) was inspected.

Findings:

- `didOpen`, `didClose`, `didChange`, `didSave` handlers are currently dummy/no-op.
- ALS does NOT currently implement standard LSP `publishDiagnostics` pipeline.
- ALS does NOT currently implement `textDocument/diagnostic`.
- ALS does NOT currently implement `textDocument/inlayHint`.
- ALS still heavily forwards Agda's custom interaction protocol through custom LSP method `"agda"`.

Therefore the desired flow:

```text
Crush → didChange → ALS → publishDiagnostics
```

DOES NOT work today as desired.

Important conclusion:

> Do not make ALS the foundation of Govenv semantics.
> LSP should remain an adapter/projection.

---

# 8. How Crush actually consumes LSP diagnostics

Current `charmbracelet/crush` implementation was inspected.

Crush does NOT use InlayHint.

It DOES consume classic PUSH diagnostics:

```text
textDocument/publishDiagnostics
```

Crush:

- caches diagnostics by document;
- understands severities including `Hint`;
- exposes `lsp_diagnostics` tool;
- after edit/write/multiedit/LSP symbol edit, notifies the LSP via `didChange`;
- waits briefly for diagnostics to settle;
- appends diagnostics to the tool result that goes back to the LLM.

Actual conceptual flow:

```text
LLM
 ↓
edit(...)
 ↓
file written
 ↓
Crush -> textDocument/didChange
 ↓
language server
 ↓
publishDiagnostics
 ↓
Crush cache
 ↓
Crush waits for updated diagnostics
 ↓
edit result + diagnostics
 ↓
LLM context
```

Very important insight:

> The LLM is not “listening to LSP asynchronously”.
> Crush explicitly enriches the result of the edit tool with cached diagnostics.

This means context injection is really a host/tool-result integration problem.

Other coding agents inspected also consume diagnostics rather than InlayHints:

- Continue via VS Code `languages.getDiagnostics(uri)`.
- Cline via VS Code `languages.getDiagnostics()`.

No meaningful InlayHint consumption was found in these coding-agent paths.

---

# 9. Governance vs Protocol feedback model

Governance and Protocol can share semantic applicability/relevance resolution but have different consequences.

Suggested conceptual distinction:

```text
Finding
├── ObligationViolation   -- Governance, invalidating
└── Advisory              -- Protocol, informative
```

Governance:

```text
candidate invalid
 → may block/reject
```

Protocol:

```text
advice relevant
 → inform only
```

Important separation:

```text
Applicability = pure semantic property
Relevance to a change = projection/incremental selection
```

Do NOT bake editor state/didChange into Protocol semantics.

A pure resolver can be something conceptually like:

```text
relevantProtocols(state, focus)
```

or, for delta:

```text
protocolDelta(base, candidate)
```

Exact Agda types are NOT frozen yet.

---

# 10. `govenv check` must NOT dump all Protocols

A key design correction:

Pure does NOT mean:

```text
govenv check => must output every applicable Protocol
```

A function can remain pure while being focus- or delta-scoped.

Potential separation:

```text
govenv check
  → authoritative validation only

govenv advise <focus>
  → relevant Protocol advice

govenv advise --base X --candidate Y
  → delta-scoped advice
```

This avoids context bloat.

`govenv check` should likely stay concise and authoritative:

```text
✓ Governance valid
✓ Assurance valid
```

while Protocol is queried/projected only where relevant.

---

# 11. Tool lifecycle hooks — earlier boundary than LSP

Important architectural discovery:

LSP diagnostics happen after the filesystem/editor state changed:

```text
edit
 ↓
filesystem changed
 ↓
didChange
 ↓
diagnostic
```

Tool lifecycle hooks can enforce BEFORE the side effect:

```text
agent proposes edit
 ↓
PreTool hook
 ↓
construct candidate in memory
 ↓
Govenv governance
 ↓
valid? allow : deny
```

This is a better realization of GV88's “earliest sound information boundary”.

Potential chain:

```text
earliest
  │
  ▼
PreToolUse       -- prevent effect before edit
  │
PostToolUse      -- inject contextual advice after edit
  │
LSP Diagnostic  -- reactive semantic feedback
  │
Git hook         -- prevent commit/push
  │
govenv check    -- authoritative validation
  │
CI/PR gate       -- authoritative integration boundary
  ▼
latest
```

The semantic principle should be technology-neutral:

> Enforce an obligation at the earliest available boundary that has sufficient information and capability to prevent the governed effect.

For Protocol/advice:

> Project relevant advice at the earliest available boundary capable of delivering it to the actor without blocking the effect.

---

# 12. Coding-agent hook convention exists de facto

There is no single formal standard comparable to LSP/MCP, but coding agents strongly converge on:

```text
BEFORE TOOL
  tool name/input
  -> allow / deny / rewrite

TOOL

AFTER TOOL
  tool name/input/result
  -> context/result transformation
```

Examples discussed/researched:

- Pi: `tool_call` / `tool_result`.
- Claude Code: `PreToolUse` / `PostToolUse`.
- Codex: similar Claude-style hook model.
- Gemini CLI: `BeforeTool` / `AfterTool`.
- OpenCode: `tool.execute.before` / `tool.execute.after`.
- Crush: currently `PreToolUse`; can deny and can append context to the eventual tool result; no general `PostToolUse` yet.

Crush specifically has Claude-Code-compatible parsing, including fields such as:

```text
permissionDecision
permissionDecisionReason
updatedInput
additionalContext
```

So Claude-style hooks are an emerging de facto ABI, but Govenv should NOT encode provider specifics.

---

# 13. Important discovery: `speakeasy-api/agenthooks`

A library already exists that solves almost exactly the provider-normalization problem we were about to implement ourselves:

```text
speakeasy-api/agenthooks
```

Repository:

```text
https://github.com/speakeasy-api/agenthooks
```

Its own goal:

> author coding-agent hooks once in Go; run them on Claude Code, Cursor, OpenAI Codex, Gemini CLI, OpenCode, Kimi Code, OpenClaw, GitHub Copilot CLI, and Copilot Chat in VS Code.

Important API concepts:

```go
r.OnToolPre(...)
r.OnToolPost(...)
r.OnToolError(...)
r.OnPrompt(...)
r.OnPermission(...)
r.OnStop(...)
```

Decision algebra includes concepts like:

```text
NoDecision
Allow
Ask
Deny
```

Capabilities are explicit; unsupported semantics can either degrade or be strict.

It handles:

- provider-specific JSON dialects;
- exit codes;
- stderr/stdout discipline;
- deny/ask semantics;
- input rewrite;
- fail-open/fail-closed;
- provider quirks;
- installation/config generation;
- shims where necessary (e.g. OpenCode);
- capability matrix.

It also has an install API that renders provider-specific configs from one manifest.

Important design guarantee:

```text
consumer owns logic
agenthooks owns wire/provider quirks
```

This is exactly what Govenv wants.

## Caveat

Current advertised providers do NOT include Crush or Pi directly.

But:

- Crush is Claude-compatible enough that adding upstream support appears plausible.
- Pi has hook adapters in its ecosystem that map Claude hooks to Pi events.

Preferred direction:

> Upstream Crush/Pi support to `agenthooks` rather than writing Govenv-specific adapters.

## Library-first caveat

`agenthooks` is library-first, not a standalone configurable CLI.

But consumer binaries get runtime subcommands such as:

```text
mybinary agenthooks run --provider=...
mybinary agenthooks serve --provider=opencode
```

So Govenv would only need a thin operational bridge if this is not absorbed by devenv.

---

# 14. Govenv shell assumption

Accepted premise:

> A governed coding agent is always launched from inside `govenv shell`.

BUT:

> Govenv should NOT package/distribute the coding agent itself.

The shell establishes the environment/integrations; the user launches whichever agent binary is already available.

Conceptually:

```text
govenv shell
    ↓
establish governed environment
    ↓
establish hooks/LSP/git boundaries
    ↓
user launches codex/crush/pi/...
```

Important distinction:

```text
SupportedAgent ∧ GovenvShell
  -> lifecycle hooks guaranteed/available

UnsupportedAgent ∧ GovenvShell
  -> no guaranteed agent-lifecycle integration
     but later boundaries may still apply
```

Do not promise every arbitrary process inside the shell is hook-governed.

---

# 15. Unsupported agents and Git hooks as fallback boundary

For a truly unsupported agent, guaranteed context injection into the model is impossible without a host integration point.

However Git provides an agent-independent boundary:

```text
unsupported agent
  ↓
edits files
  ↓
git commit
  ↓
pre-commit
```

Governance can fail there:

```text
pre-commit -> govenv validation -> non-zero -> commit aborted
```

Protocol can inform there without blocking:

```text
pre-commit -> protocol delta over HEAD vs staged candidate
           -> print relevant advice
           -> exit 0
```

If the coding agent invokes Git through a shell tool whose stdout/stderr is returned to the model, this often becomes context injection in practice:

```text
Git hook stdout
  ↓
git command output
  ↓
shell tool result
  ↓
LLM
```

But this is NOT universally guaranteed.

Git hooks are not authoritative because they can be bypassed (`--no-verify`, custom Git clients, etc.). They are an early local optimization/boundary, not the final source of truth.

Potential boundary hierarchy:

```text
Agent ToolPre  -> preventive enforcement
Agent ToolPost -> targeted advice
LSP            -> reactive semantic feedback
Git pre-commit -> prevent commit / emit delta advice
Git pre-push   -> prevent publication
Govenv check   -> authoritative checker
CI / PR gate   -> authoritative integration boundary
```

---

# 16. Devenv research — key new discovery

We asked whether a CLI already provides most of these boundaries.

Conclusion:

> `devenv` already provides MOST of the desired operational control plane.

It already covers:

```text
devenv
├── governed shell/environment
├── packages/toolchains
├── LSP tooling/environment
├── tasks
├── test/check
├── git-hooks / prek integration
├── processes/services
├── MCP support
└── coding-agent lifecycle hooks for Claude Code
```

Important discovery:

> Current devenv already has Claude Code lifecycle hook support, including hooks such as `PreToolUse`, `PostToolUse`, `PostToolUseFailure`, `SessionStart`, `Stop`, etc.

`PreToolUse` can block actions.

Devenv also integrates its Git hooks/checks with Claude's edit/write lifecycle so checks can run close to the action.

Therefore the infrastructure gap is much smaller than previously thought.

Instead of building a new orchestration CLI, likely architecture is:

```text
                    Govenv
                 semantic core
             /                  \
       check/gate              advise
           │                     │
           └────────┬────────────┘
                    │
                  devenv
                    │
       ┌────────────┼──────────────┐
       │            │              │
      LSP       git hooks      agent hooks
       │            │              │
 diagnostics   pre-commit      ToolPre/ToolPost
```

Devenv becomes the operational boundary/orchestrator.

Govenv provides semantics; devenv establishes the environment and adapters.

---

# 17. `agenthooks` + devenv looks like the likely final composition

Very promising composition:

```text
                   Govenv
              proofs + Protocol
                    │
                    ▼
                  devenv
       environment/control plane
                    │
       ┌────────────┼────────────┐
       ▼            ▼            ▼
      LSP        git-hooks   agenthooks
```

Responsibilities:

## Govenv

```text
semantics
proofs
Architecture
relevance
candidate/gate
advice
```

## devenv

```text
shell
packages/toolchain
LSP environment
tasks/tests/checks
git hooks
processes
CI/dev environment
agent hook orchestration
```

## agenthooks

```text
multi-agent lifecycle normalization
provider quirks
install/config rendering
allow/deny/ask/rewrite/context semantics
```

This avoids Govenv knowing:

```text
Claude settings.json
Codex hooks.json/config.toml
Gemini settings.json
Cursor hooks.json
OpenCode plugin shim
...
```

Potential future upstream direction:

Today devenv has something Claude-specific conceptually like:

```nix
claude.code.hooks = { ... };
```

A more general future interface could conceptually be:

```nix
agents.hooks = {
  preTool = ...;
  postTool = ...;
};
```

with `agenthooks` underneath.

Exact API is NOT designed yet; this is the next investigation.

---

# 18. `hk` was investigated but is probably NOT the main answer

`jdx/hk` is relevant because it already combines:

- checks/fixes;
- Git hooks;
- CI/local execution;
- diagnostics;
- JSON/JSONL;
- MCP;
- some coding-agent integration.

But it overlaps heavily with devenv:

```text
devenv tasks/test  ↔ hk check
devenv git-hooks   ↔ hk git hooks
devenv MCP         ↔ hk MCP
```

And it does not appear to provide the generic multi-provider ToolPre/ToolPost lifecycle abstraction that `agenthooks` provides.

So adding `hk` would likely be:

```text
devenv + hk + still agenthooks
```

rather than simplifying the stack.

Current direction: keep `devenv`; do not adopt hk unless a future concrete gap justifies it.

---

# 19. Govenv semantic interface should remain technology-neutral

Do NOT model Claude/Codex/LSP/Git in the Kernel unless semantically necessary.

Potential neutral concepts (not frozen):

```text
Snapshot
Candidate
Focus
ProposedChange
Finding
Advisory
```

Possible operations conceptually:

```text
govenv check
  authoritative validation

govenv gate <candidate>
  can candidate/effect proceed?

govenv advise <focus or delta>
  minimal relevant Protocol context
```

Then adapters/boundaries map them:

```text
ToolPre   -> gate(candidate)
ToolPost  -> advise(delta/focus)
LSP       -> Finding -> Diagnostic
Git hook  -> gate(staged candidate) + advise(staged delta)
CLI/CI    -> check
```

Do not freeze exact CLI yet.

---

# 20. Important principles preserved

## A. `*.lagda.md` is normative semantics, not implementation docs

Implementation details belong in `.agda` colocated modules or adapters, not in governance prose unless they are themselves governed semantics.

## B. Experiments must not live under `Kernel`

Candidate reflective/tool integration work should begin in `Experiment`/`Adapter`, not established Kernel.

## C. LSP is optional projection, not authority

Do not make Govenv semantics dependent on ALS/LSP availability.

## D. Agent lifecycle hooks are early enforcement optimizations

They can deny earlier than LSP but do not replace `govenv check` / CI authority.

## E. Protocol must not become context bloat

Never dump all Protocols on every check/edit.

Resolve only semantically relevant advice for the current focus/delta.

## F. Unsupported agents degrade to later boundaries

No lifecycle integration does NOT imply no governance.

Fallbacks include LSP, Git hooks, check, CI.

## G. Coding agents need not be packaged by Govenv/devenv

The environment should establish integrations; the user supplies/launches the agent binary.

---

# 21. Exact next investigation requested by user

The user agreed with the direction and explicitly asked to check:

> how much work would it take to generalize devenv's current Claude Code hooks into a multi-agent integration based on `agenthooks`?

This should be the first task in the next clean session.

Recommended investigation plan:

1. Inspect current devenv source for Claude Code integration:
   - module definitions/options;
   - generated hook config;
   - how `PreToolUse`, `PostToolUse`, etc. are wired;
   - how Git hooks/checks are invoked after Edit/Write;
   - whether it is implemented as Nix module, scripts, shell setup, or a helper binary.

2. Identify the abstraction boundary already present:
   - provider-specific config generation;
   - lifecycle event model;
   - command runner;
   - installation timing (`enterShell`, activation, generated files, env vars).

3. Compare that implementation with `speakeasy-api/agenthooks` install/runtime model.

4. Determine whether multi-agent support could be:

```text
small refactor:
existing devenv Claude hooks
  -> generic hooks manifest
  -> agenthooks provider rendering
```

or whether deeper changes are required.

5. Specifically evaluate compatibility with the Govenv assumptions:
   - agent launched from inside `govenv shell`;
   - Govenv does not package agent;
   - supported agents get ToolPre/ToolPost;
   - unsupported agents still get Git/LSP/check fallbacks;
   - fail-closed should only be claimed where `agenthooks` says `Can(Deny)`;
   - Protocol context must remain delta/focus-scoped.

6. Check whether this should be contributed upstream to devenv rather than implemented as Govenv-specific infrastructure.

Strong preference:

> If this is reasonably general, upstream it to devenv and keep Govenv free of provider-specific infrastructure.

---

# 22. User preferences / interaction style relevant to continuation

- Portuguese, but English technical names are fine/preferred where natural.
- Direct technical dialogue.
- User expects pushback when representation is weak.
- Avoid redundant wrappers/abstractions if Agda already provides identity/semantics.
- Inspect repo/source before proposing implementation.
- Prefer compile-time / typed invariants over runtime conventions.
- `AGENTS.md` should eventually become minimal or unnecessary as richer boundaries mature.
- MCP is optional/future; do not force it into the current design.
- User values earliest possible enforcement but insists final checks remain authoritative.
- Do not pack coding-agent binaries into Govenv/devenv merely to gain control.
- Avoid context bloat; advice must be relevance-scoped.

---

# 23. Suggested opening question/statement for next session

No need to ask the user to restate anything.

Start by saying roughly:

> Vou inspecionar a implementação atual de `claude.code.hooks` no devenv e comparar diretamente com o modelo `agenthooks`, para medir se a generalização multi-agent é um refactor pequeno ou exige uma nova camada.

Then inspect current devenv source/current docs before making claims, because this area is moving quickly.

