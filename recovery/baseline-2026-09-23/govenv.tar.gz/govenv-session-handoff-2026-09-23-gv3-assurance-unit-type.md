# Govenv session handoff — GV3 assurance and `⊤`

Date: 2026-09-23

## Context

We inspected the current `klarkc/govenv` repository on GitHub to understand how `Govenv.Assurance.GV3` works.

Relevant files:

- `Govenv/Assurance/GV3.lagda.md`
- `src/Govenv/Kernel/Verdict.agda`
- `src/Govenv/Kernel/Assurance.agda`
- `Govenv/Assurance.lagda.md`
- `Govenv/Roadmap.lagda.md`
- `Govenv.lagda.md`
- `devenv.nix`

## GV3 in the roadmap

GV3 is currently:

```text
GV 3 "`Verdict`: `holds`, `violated`, and `unknown`." ✓
```

The governed claim is that `Verdict` has those three constructors.

## `Verdict`

Defined in:

`src/Govenv/Kernel/Verdict.agda`

```agda
data Verdict (Diagnostic Obligation : Set) : Set where
  holds : Verdict Diagnostic Obligation
  violated : Diagnostic → Verdict Diagnostic Obligation
  unknown : Obligation → Verdict Diagnostic Obligation
```

`Verdict` is generic in two payload types:

- `Diagnostic`
- `Obligation`

## GV3 assurance

Defined in:

`Govenv/Assurance/GV3.lagda.md`

Core implementation:

```agda
verdictCovered : Verdict ⊤ ⊤ → Bool
verdictCovered holds = true
verdictCovered (violated diagnostic) = true
verdictCovered (unknown obligation) = true

Proposition : Set
Proposition = (verdict : Verdict ⊤ ⊤) → verdictCovered verdict ≡ true

proof : Proposition
proof holds = refl
proof (violated diagnostic) = refl
proof (unknown obligation) = refl

evidence : StaticEvidence 3
evidence = staticEvidence Proposition proof
```

## What GV3 is actually proving

The important mechanism is not the returned `Bool`; it is Agda's exhaustive pattern matching.

The function:

```agda
verdictCovered : Verdict ⊤ ⊤ → Bool
```

must cover every possible constructor of `Verdict`.

If someone adds a fourth constructor to `Verdict`, for example:

```agda
deferred : Verdict Diagnostic Obligation
```

then the existing `verdictCovered` and `proof` become non-exhaustive and Agda rejects the module until the governance assurance is explicitly updated.

Therefore GV3 acts as a compile-time structural invariant over `Verdict`.

## What `⊤` means

`⊤` is Agda's unit type (`Agda.Builtin.Unit`), conceptually:

```agda
data ⊤ : Set where
  tt : ⊤
```

It has exactly one inhabitant: `tt`.

In GV3:

```agda
Verdict ⊤ ⊤
```

means:

```text
Diagnostic = ⊤
Obligation = ⊤
```

So the three structural cases remain inhabitably representable:

```agda
holds
violated tt
unknown tt
```

The payloads exist, but carry no relevant information.

## Why `⊤` is used in `Proposition`

GV3 is interested only in the shape of `Verdict`, not in the content of diagnostics or obligations.

Using `⊤` gives the smallest inhabited payload type possible.

Using something richer such as `Bool` would introduce irrelevant payload variation:

```agda
violated true
violated false
unknown true
unknown false
```

Using an empty type such as `⊥` would be wrong for this purpose because `violated` and `unknown` would become uninhabitable.

So `⊤` means roughly:

> there is a payload here, but its value does not matter for this property.

A useful reading of:

```agda
(verdict : Verdict ⊤ ⊤) →
```

is:

> for any structural form of `Verdict`, ignoring the actual diagnostic/obligation content...

## Where `⊤` enters

`⊤` is not part of the `Verdict` definition itself.

`Verdict` stays generic:

```agda
Verdict Diagnostic Obligation
```

GV3 chooses to instantiate both parameters with `⊤`:

```agda
Verdict ⊤ ⊤
```

So:

```text
Verdict Diagnostic Obligation
        ↓          ↓
        ⊤          ⊤
```

## StaticEvidence

Defined in:

`src/Govenv/Kernel/Assurance.agda`

Conceptually:

```agda
record StaticEvidence (idx : Nat) : Set₁ where
  constructor staticEvidence
  field
    Proposition : Set
    proof : Proposition
```

GV3 packages its proposition and proof as:

```agda
evidence : StaticEvidence 3
evidence = staticEvidence Proposition proof
```

The index `3` ties the evidence to governance identity GV3.

## Global assurance registry

`Govenv/Assurance.lagda.md` imports GV3 and registers it:

```agda
assures (statically GV3.evidence)
```

The assurance kernel checks that every roadmap item marked `done` (`✓`) has assurance coverage.

The project contains a regression theorem showing that an unassured done item is rejected:

```agda
unassuredDoneIsRejected :
  completionCoverage assurances unassuredDoneRoadmap ≡ false
```

And for the current real roadmap:

```agda
projectCompletionCovered :
  completionCoverage assurances roadmap ≡ true
```

## Closure into project checks

`Govenv.lagda.md` imports:

```agda
open import Govenv.Assurance
```

The project check runs Agda over the root:

```sh
agda -i . -i src Govenv.lagda.md
```

Therefore a broken GV3 proof breaks the project check.

## Important limitation

Agda does **not** understand the English roadmap sentence:

```text
"`Verdict`: `holds`, `violated`, and `unknown`."
```

and automatically derive the proposition.

The semantic mapping:

```text
roadmap description
        ↕
Proposition
        ↕
proof
```

is still authored by a human/agent.

What is formally enforced today is:

```text
GV index 3
    ↕
StaticEvidence 3
    ↕
Proposition
    ↕
proof
```

## Concise mental model

GV3 says:

```text
Verdict has exactly the governed structural cases
```

Its assurance works by:

```text
Verdict
  ↓
exhaustive Agda pattern matching
  ↓
Proposition
  ↓
proof
  ↓
StaticEvidence 3
  ↓
global assurance registry
  ↓
completionCoverage roadmap == true
```

And `⊤` is used only to make the payload parameters inhabited but semantically irrelevant.
