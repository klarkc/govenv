# Govenv session handoff - 2026-09-23

This handoff compacts the current Govenv session so work can continue in a fresh conversation without relying on chat history.

## Critical first rule

Do **not** update, reset, rebase, clean, or fast-forward the primary worktree before preserving the local uncommitted Assurance/GV60 experiment.

Primary repo:

```text
/home/klarkc/Sources/klarkc/govenv
```

Observed primary worktree state:

```text
branch: main
local HEAD: d18a4a3304114b7441282cdf59dd4ab82e897e7e
origin/main: ab5a0bdacf768adde1b939f8264706e12bfdde03
divergence: local main is 95 commits behind origin/main, 0 ahead
```

Uncommitted state:

```text
 M src/Govenv/Kernel/Assurance.agda
?? Govenv/Assurance/GV60.lagda.md
?? govenv-gv84-release-main/
```

`govenv-gv84-release-main/` is itself a registered worktree, not disposable junk.

Before touching `main`, inspect/preserve the two Assurance changes and decide whether they should be ported, abandoned, or conceptually rebased against current `origin/main`.

---

## Current authoritative remote state

Treat `origin/main` as the current repository truth for continuation, not the stale local `main`.

Latest observed `origin/main` history:

```text
ab5a0bd chore(materialize): update governed materializations
5990c74 chore(materialize): update governed materializations
ef3069e gov(authorization): separate bootstrap from authorized effects
5dcefb4 chore(materialize): update governed materializations
2a23717 chore(materialize): update governed materializations
36856d7 gov(governance): classify semantic authority domains
766e3db chore(materialize): update governed materializations
f661a06 chore(materialize): update governed materializations
675c1ee gov(project): align purpose and integration roadmap
d44eb2d chore(materialize): update governed materializations
c916e8d gov(architecture): separate normative and experiment domains
ff3c01c gov(architecture): close source-boundary counterexample
51cedb9 docs(policy): distinguish operations from governance
9d8a2be chore(spike): model constitutional history semantics
8af5ae6 tag: v0.2.7
0372f40 chore(main): release 0.2.7
```

Latest known published tag from the inspected remote history:

```text
v0.2.7
```

Do not assume a new release is desired merely because release infrastructure changes.

---

## Product identity and final direction

Canonical project identity is immutable:

```text
Govenv
```

White-label distributions may project different branding, but they do not rename the canonical Govenv project or redefine its purpose.

Current governed public description on `origin/main`:

> A type system for your repository. Govern code, configuration, tooling, CI, and AI agents through one typed Govenv model.

Current governed purpose:

> Turn a repository into a formally governed environment where code, configuration, tooling, CI, and AI agents operate from one typed and verifiable Govenv semantic model, with Governance defining validity, Protocol guiding process, and governable obligations enforced at their earliest sound information boundary.

Governed website:

```text
https://klarkc.github.io/govenv/
```

Governed topics:

```text
agda
ai-agents
devenv
formal-methods
nix
repository-governance
```

Important conceptual evolution:

- Govenv is **not** fundamentally a devenv wrapper.
- Govenv is **not** fundamentally a development-runtime compiler.
- Development/runtime is one projection/application of a wider governed project model.
- Final Govenv should cover repository state, CI, release, Git, editor/LSP, agents, environments, materializations, external effects, etc.
- The final product must be **ejectable** from `klarkc/govenv` and usable by white-label distributions without repository-specific code.

Core slogan:

> The agent may forget. The compiler may not.

Core mental model:

```text
project / repository / system state
              |
              v
      Govenv constitution
              |
              v
    valid / violated / unknown
              |
       governed projections
              |
 README / CI / runtime / GitHub / agents / etc.
```

---

## Governance vs Protocol vs irreducible effects

This distinction is now central and governed.

### Governance

Governance defines constitutional validity.

If a property of repository/system state, a transition, effect, authorization, or semantic output can be stated independently of contributor behavior and determines project validity, it is a Governance candidate.

### Protocol

Protocol guides how contributors and AI agents should work:

- investigation order,
- heuristics,
- implementation discipline,
- review procedure,
- reuse-first behavior,
- semantic validation process,
- documentation discipline,
- dependency discipline.

Protocol does **not** by itself make a repository state constitutionally invalid merely because a different valid process produced it.

`Govenv.Protocol` is the canonical semantic source for materialized `AGENTS.md`.

### Irreducible observation/effects

Adapters may:

- observe,
- apply,
- verify.

Adapters must not introduce semantic authority, policy, structure, ordering, or authorization decisions.

Central principle:

> Govern everything expressible/checkable that determines constitutional validity; keep contributor/agent process guidance in Protocol; leave only irreducible observation/effect execution outside semantics.

User-established principles:

> Tudo que for possível ser uma regra de governança deve ser uma regra de governança.

> A superfície do que não é governado deve sempre ser mínima possível.

Useful refinement:

> Subjectivity belongs at policy-definition time, not at policy-enforcement time.

---

## Architecture and semantic ownership

Canonical root:

```text
Govenv.lagda.md
```

High-level roles:

```text
Govenv.lagda.md                  formal closure root

Govenv/                          normative/project semantic authority
  Governance / Project / Roadmap
  Protocol
  Assurance
  Materialization
  Authorization / Administration
  Release
  ...

src/Govenv/Kernel/               reusable pure semantics
src/Govenv/Projection/           target-format projection
src/Govenv/Adapter/              observation/effects/read-back

generated/versioned artifacts    derived outputs, never independent semantic authority
```

Target architecture:

```text
Governed semantic source
        |
        v
Govenv.Materialization.* binding
        |
        v
Projection
        |
        v
Adapter
        |
        v
external/versioned target
```

The semantic domain owns meaning. Materialization binds that meaning to a target. Projection renders. Adapter observes/applies/verifies.

---

## Current roadmap position

The generated README on `origin/main` says:

```text
Current: P1 - Formal governance model and repository closure
Next: GV102
```

GV102:

> Separate domain semantic authority from materialization binding: every state materialized by Govenv must have exactly one canonical `Govenv.Materialization.*` definition that binds authoritative semantic sources and any target-specific composition, ordering, or inclusion to its target, application mode, privilege, required authority, and verification; Governance, Protocol, and other governed project data retain ownership of their domain semantics and must not be duplicated or re-owned by materializations, projections, or adapters; projections encode target-format representation and adapters only observe, apply, or verify effects.

Unless newer work changes the roadmap, **the next governed item is GV102**.

Do not restart old work such as "R1-04 dependency-indexed rules": on current `origin/main`, dependency-indexed rules are already completed as GV6.

---

## Roadmap model / identity invariants

The roadmap is governed Agda data.

Important rules:

- Governance IDs are immutable historical references.
- Once introduced, a GovernanceId, its definition, and owning phase cannot be modified, removed, or reused.
- Changed intent/correction requires a newer GV plus explicit supersession.
- Cancelled/superseded history remains represented.
- Phase progression and item lifecycle are structurally checked.
- README roadmap is a projection, not authority.
- README shows only two visible levels: Phase -> Item, with collapsible phases.
- Current/Next are derived from typed roadmap state, not maintained independently.

Use the current DSL from `origin/main`; do not reintroduce string IDs such as `"R1"`.

---

## Materialization model

Materialization is a first-class governed concept.

Key rules:

- Every materialized state has one canonical `Govenv.Materialization.*` binding.
- Domain semantics belong to Governance/Protocol/project data, not to the materialization itself.
- Materialization binds authoritative semantic sources to target, composition/order/inclusion where target-specific, application mode, privilege/authority, and verification.
- Projection only renders target representation.
- Adapter only observes/applies/verifies.
- Generated artifacts must not become independent semantic authority.
- Versioned materialization drift is rejected.
- `.govenv` transient state must not become versioned authority.
- README is generated from `Govenv.Materialization.Readme`.
- `AGENTS.md` is intended to be generated exclusively from `Govenv.Protocol`.
- CI/workflows and GitHub metadata are moving toward governed materializations.

Historical temporary workflow was:

```text
governance commit
then immediate subsequent chore(materialize)
```

Current `origin/main` has evolved toward automated authorized materialization after human authorization, so always inspect current Materialization/Authorization semantics before assuming the old two-commit rule remains operational.

---

## Administrative materialization and authority

The user already created:

```text
GitHub environment: admin-materialization
secret: GOVENV_ADMIN_TOKEN
```

The token was created with approximately one-year expiry.

The assistant is explicitly authorized to invoke `Admin Materialize` when needed.

Never broaden token permissions automatically. If a materializer lacks permission, report the exact missing capability.

### Current authoritative `origin/main` admin model

There is exactly one human-supplied administrative root:

```text
GOVENV_ADMIN_TOKEN
```

Current governed token requirements:

```text
repository-restricted fine-grained PAT

Administration: read/write
Environments: read/write

intentionally no:
Actions
Contents
Workflows
```

This is newer than the first bootstrap instructions. If admin setup fails, verify actual token scopes against current `Govenv.Administration`.

Key semantics:

- Replacing/rotating token changes the credential, not root-authority identity.
- Candidate, agent, release, Pages, and Git-materializer paths must never consume the root credential.
- Admin Materialize is bootstrap/recovery/rotation only.
- Direction is one revision-bound convergent `setup`, not a menu of ordinary admin targets.
- Ordinary deterministic project-state effects such as description/website/topics reconcile automatically after an `AuthorizedRevision`.
- Observable effects follow apply -> read-back -> equality.
- No second manually supplied credential should be necessary unless a hosting-platform impossibility is explicitly governed.

Derived materializer design includes:

```text
deploy key identity: govenv-materializer
materializer environment: authorized-materialization
secret: GOVENV_MATERIALIZER_SSH_KEY
authorized branch: main
```

The repository deploy-key set is intended to be a closed set because GitHub ruleset bypass applies to the broad `DeployKey` actor class.

---

## Human authorization boundary

Current architecture strongly separates:

```text
candidate state
human authorization
AuthorizedRevision
deterministic materializations/effects
```

Core rule:

> New semantic authority originates only from the exact repository state accepted by an explicit human pull-request merge.

Automation may derive deterministic outcomes after authorization, but those outcomes:

- create no new semantic authority,
- must retain causal provenance to the human-authorized revision,
- must not be treated as fresh human authorization.

Authority-boundary migrations must be monotonic and non-self-locking.

Do not activate a stronger restriction until all paths needed to operate, verify, and repair under it already exist and prerequisite external capabilities have been read-back verified.

---

## CI rules

Explicit decisions:

- CI uses Determinate Nix.
- CI uses local Nix caching via `DeterminateSystems/magic-nix-cache-action`.
- These are governance decisions, not incidental workflow preferences.
- Validation/publication materialize governed artifacts and reject drift.
- CI workflows should ultimately contain no independent policy; behavior should be traceable to governed project data.

Earlier cache investigation confirmed that Magic Nix Cache served paths via its local endpoint rather than rebuilding everything.

A Release Please run once failed with a transient GitHub GraphQL internal error after materialization/checks had succeeded. Re-running only the failed Release job succeeded. Do not change code for that historical transient failure unless it becomes reproducible.

---

## Release governance

Standing user instruction:

> **Notify the user when you think a release is warranted. Do not publish/create/merge a release without explicit user approval.**

Use releases for coherent milestones, not simply because commits accumulated.

Current release architecture:

- Release Please coordinates SemVer / Conventional Commit analysis / candidate/tag/release lifecycle.
- Govenv owns canonical changelog/release semantics.
- `CHANGELOG.md` is governed materialization.
- release governance delta is typed.
- approved freeze must survive merge-to-publication unchanged.
- Release Please rendered notes are observational input, not semantic authority.
- PR body and published GitHub Release should project the same authorized typed release document.
- external publication requires read-back verification.

GV95 is completed.

Latest known published tag from inspected remote: `v0.2.7`.

---

## Commit governance

Expected UX remains ordinary Git:

```text
git commit
    |
Git hook
    |
candidate staged state
    |
candidate governance
    |
accept / reject
```

There is no planned `govenv commit`.

Current direction:

- Conventional Commits vocabulary is governed project data.
- governance changes use `gov(...)`.
- governed commits should reference roadmap/GV items with `Refs: GV...`.
- staged candidate state should be validated using candidate governance.
- provider-neutral Git-hook semantics belong to Govenv.
- Stage 0 runtime backend (devenv) provides hook installation mechanics.
- future Govenv runtime owns integration without changing normal Git UX.

Regression direction:

- standalone case-insensitive `fix` is a conservative regression signal.
- unresolved observed regressions cannot be exempted away.
- regression repair should preserve a counterexample and close the missing assurance boundary.

---

## Assurance / evidence direction

Core principle:

> Governance completion must be evidence-bearing and persistent.

Pending GV74 formalizes that:

- an item becomes done only when governed evidence establishes its proposition for the candidate repository state;
- every non-superseded done item must remain satisfied in subsequent valid states.

GV84 regression closure direction:

- preserve counterexample as governed evidence,
- correct missing/incorrect assurance boundary or supersede overstated governance,
- candidate validation must reject recurrence.

### Local uncommitted experiment to preserve

`src/Govenv/Kernel/Assurance.agda` has a local modification adding an `establishObserved` idea:

```text
ObservedEvidence
+ dependent Facts
-> Maybe ObservedWitness
```

It runs `Rule.check`:

```text
holds            -> just witness
violated/unknown -> nothing
```

Untracked:

```text
Govenv/Assurance/GV60.lagda.md
```

This models GV60 as an observed README invariant:

- subject: README file
- observation: String
- dependency: README file
- actual README compared with canonical `renderReadme`
- exact equality -> holds
- mismatch -> violated readmeDrift

This experiment is on stale local `main`, 95 commits behind remote.

**Do not commit it directly as-is.** Re-evaluate/port the concept against current remote Assurance/Materialization semantics first.

---

## Current worktrees

There are many registered worktrees. Do not create another casually; inspect/reuse the relevant one.

Important observed worktrees:

```text
/home/klarkc/Sources/klarkc/govenv
  main @ d18a4a3 (stale; local experiment present)

/home/klarkc/Sources/klarkc/govenv-gv84
  gov/gv84-counterexample-closure @ 3467b29

/home/klarkc/Sources/klarkc/govenv/govenv-gv84-release-main
  wip/gv84-release-placement-main @ 81c8b1f

/home/klarkc/Sources/klarkc/govenv-gv101
  gov/gv101-global-classification @ 032fb1a

/home/klarkc/Sources/klarkc/govenv-purpose
  gov/product-purpose-stewardship @ ad94133

/home/klarkc/Sources/klarkc/govenv-gv94
  gov/gv94-derived-current @ 2a343fa

/home/klarkc/Sources/klarkc/govenv-gv95-release-renderer
  fix/gv95-release-renderer @ 7daa0bc

/home/klarkc/Sources/klarkc/govenv-gv95-unreleased-notes
  fix/gv95-unreleased-notes @ db6e61d

/home/klarkc/Sources/klarkc/govenv-gv92
  gov/gv92-admin-root @ 52575cf

/home/klarkc/Sources/klarkc/govenv-gv92-setup
  gov/gv92-setup @ 5ea0b20

/home/klarkc/Sources/klarkc/govenv-gv92-setup-readback
  gov/gv92-setup-readback @ 7b4873b

/home/klarkc/Sources/klarkc/govenv-history-spike
  spike/constitutional-history @ 7278674
```

There are additional verification/debug/fix worktrees. Run `git worktree list` before choosing where to continue.

---

## Protocol rules to preserve

Current `Govenv.Protocol` includes several process rules for humans/agents.

### Purpose stewardship

Before declaring a material scope/architecture/product/roadmap/integration change ready:

- compare it with `Govenv.Project.purpose`;
- update purpose deliberately only if project direction truly changes;
- do not rewrite purpose to justify a local design choice;
- keep public description as a concise faithful summary;
- review website/topics when public identity materially changes.

### Reuse-first

Before introducing new abstractions/infrastructure, inspect in order:

1. Govenv itself
2. Agda builtins / stdlib
3. mature external Agda libraries
4. Nixpkgs for dev/runtime dependencies
5. explicit external inputs for dev/runtime dependencies
6. bespoke implementation

Reuse-first does not mean dependency-first.

### Semantic validation before check trust

A green automated check proves only what current checks establish.

If a candidate observably contradicts established governance while CI passes:

- preserve the contradiction as a counterexample,
- treat it as an assurance/enforcement defect,
- repair the boundary so recurrence is rejected.

Do not silently erase the counterexample by merely editing until checks pass.

### Documentation follows semantic authority

- `*.lagda.md`: human-facing normative source for Governance/Protocol/evidence.
- Kernel/Projection/Adapter/Experiment: code-first `.agda`; documentation belongs in owning source.
- standalone versioned docs are not independent semantic authority unless governed materializations.
- `AGENTS.md` is generated from Protocol.

### Dependency discipline

No second package-manager authority.

Do not introduce dependency authority through npm/pnpm/yarn, pip/poetry/uv, Cargo, Cabal/Stack, Bundler, etc.

Dependency acquisition is centralized through governed devenv/Nix and pinned Agda sources.

---

## MCP / LSP / agent integration direction

MCP is on the roadmap but explicitly optional.

GV107 direction:

- core Governance semantics must not depend on MCP;
- Protocol must not depend on MCP;
- `govenv check` must not depend on MCP;
- LSP/editor integration must not depend on MCP;
- Git boundaries must not depend on MCP;
- coding-agent lifecycle integration must not depend on MCP.

MCP may project the same governed context or diagnostic/advisory deltas as an adapter only.

Agent integration direction:

```text
before-tool:
  anticipate / gate / rewrite governed effects when sound

after-tool:
  attach scoped Protocol advice/context

unsupported-agent fallback:
  LSP + Git hook + authoritative govenv check
```

`govenv shell` should establish integrations for supported agents launched inside the shell, but Govenv should not package or own the coding-agent executable.

---

## Enforcement timing principle

Every governable obligation should be enforced at its earliest sound information boundary while retaining `govenv check` as authoritative full evaluation.

Rough hierarchy:

```text
construction/type level
  -> typed IDs, roadmap validity, pure structural/evidence relationships

static candidate / incremental / LSP
  -> architecture, authority placement, materialization ownership/drift,
     immutable history, documentation references, regression obligations

commit boundary
  -> staged candidate validity, commit policy, GV refs, regression signals

PR / CI
  -> remote/provider facts first available there

post-effect
  -> external read-back, publication/admin/runtime observations
```

Later layers may confirm earlier conclusions, but must not re-own or duplicate semantics soundly enforceable earlier.

---

## Runtime / devenv / Nix direction

devenv remains Stage 0/backend, not Govenv's semantic center.

Long-term:

```text
Agda governance + typed Govenv model
              |
              v
       governed project IR
              |
              v
 runtime / integrations / projections
              |
       replaceable backend
              |
          Nix / devenv
```

Core must not semantically depend on devenv.

Desired eventual UX can resemble:

```text
install govenv
govenv setup
govenv shell
```

with Nix/devenv/Agda hidden as implementation details where practical.

P6 includes:

- standalone Govenv entrypoint,
- self-hosting,
- white-label distributions,
- declarative/reproducible bootstrap/integrations/secrets/admin setup,
- ejectability from the `klarkc/govenv` codebase.

---

## CI/cache observations from this session

Earlier Pages builds were very slow.

Investigation showed:

- Magic Nix Cache was serving Nix paths through its local endpoint.
- later docs/materialization runs dropped dramatically compared with the old long run.
- GitHub/FlakeHub auth noise was investigated.
- user explicitly required keeping Determinate Nix.
- user explicitly required Magic Nix Cache as a governed CI rule.

Do not remove Determinate Nix or Magic Nix Cache as an optimization without an explicit governance change.

---

## README / public presentation

README is governed/materialized, not manually authored.

Current generated README on `origin/main` contains:

- Govenv title
- governed description
- badges
- full Purpose
- collapsed two-level roadmap
- Current/Next derived from roadmap
- getting-started/runtime instructions

Do not manually edit generated README semantic content.

Earlier X teaser prepared in this session:

```text
What if your repository had a type system?

Cooking something 👀

https://github.com/klarkc/govenv
```

User wanted it deliberately short and curiosity-driven.

---

## Release behavior requested by user

Standing instruction:

- Continue coherent implementation work and make ordinary commits/pushes when appropriate.
- **Before a release is desired, tell the user.**
- Do not create/publish/approve/merge a release without explicit user approval.
- This boundary has been reinforced multiple times.

---

## Immediate next-session procedure

1. Read this handoff.
2. Inspect:
   ```text
   /home/klarkc/Sources/klarkc/govenv
   git status
   git worktree list
   ```
3. Confirm `origin/main` still points to `ab5a0bd` or a newer revision.
4. Preserve the stale local Assurance/GV60 experiment before updating `main`.
   Do not use destructive reset/clean.
5. Read current `origin/main` versions of:
   ```text
   Govenv/Project.lagda.md
   Govenv/Protocol.lagda.md
   Govenv/Roadmap.lagda.md
   Govenv/Materialization.lagda.md
   Govenv/Administration.lagda.md
   Govenv/Authorization.lagda.md
   ```
6. Treat generated README `Current` / `Next` as the roadmap entrypoint.
7. At handoff time the authoritative next item is:
   ```text
   GV102
   ```
8. Work from a clean/current worktree based on `origin/main`; do not casually reuse stale `main`.
9. Keep the core boundary in view:
   ```text
   semantic authority belongs to the domain
   materialization binds it to a target
   projection renders
   adapter observes/applies/verifies
   ```
10. Run the governed validation/materialization path required by the current remote tree before considering work ready.
11. If admin reconciliation is needed, the assistant may invoke Admin Materialize; never broaden root-token permissions automatically.
12. If a release appears justified, notify the user and wait for approval.

---

## High-level destination

Govenv's destination is not "configuration management with Agda".

It is a typed, formally governed semantic model for the project as a whole, where valid state, process guidance, authorization, effects, materializations, runtime integrations, CI, Git, editor/agent feedback, release state, and external projections derive from explicit semantic authority while the irreducibly ungoverned/effectful surface is minimized.

The product should eventually be portable enough that a white-label distribution can carry its own governed model, generated CI/materializations, integrations, and runtime without depending on repository-specific Govenv bootstrap code.

That portability/ejectability is part of the product definition, not a later packaging convenience.
