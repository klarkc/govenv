# Govenv session handoff — 2026-09-10 — release governance UI / canonical changelog

## Repository and tools

Repository: `/home/klarkc/Sources/klarkc/govenv`

Use Desktop Commander for local repository state/work and the GitHub connector for GitHub state. Desktop Commander device: `solo098` (`ee17d3e4-8041-4f18-9fe7-4f36099458e3`). Conversation language is Portuguese; code, governance text, docs and commit messages are English.

## Hard rules to preserve

- NEVER change GV71 wording again.
- Never mark a GV `✓` merely by editing the roadmap; completion needs governed evidence.
- Before merging Release Please PR #2, tagging, publishing a GitHub Release, or equivalent release action, notify the user and obtain explicit approval.
- User approval of GitHub Actions checks is NOT release approval.
- Never claim full `devenv test` passed unless it actually did. Root/targeted Agda checks passed; full suite historically not established.
- No `amended`. Any committed semantic/text correction requires a new GV and supersession. Removal forbidden; obsolete without replacement = cancelled.
- A `✓` GV is a persistent invariant.
- Materialization/domain data owns semantics; Projection owns target formatting; Adapter owns irreducible effects/observation/read-back only.

## Exact Git state at handoff

A fresh `git fetch origin` was run before this handoff.

```text
## main...origin/main [behind 1]
 M src/Govenv/Kernel/Assurance.agda
?? Govenv/Assurance/GV60.lagda.md
```

Local HEAD:

```text
288108c gov(release): render semantic governance diffs
```

Remote `origin/main`:

```text
87937cb chore(materialize): update governed materializations
```

`87937cb` was created by CI and changed only `.govenv/roadmap.snapshot` and `README.md` (+6 lines each). Preserve the two unfinished local assurance files when fast-forwarding.

Recent remote history:

```text
87937cb chore(materialize): update governed materializations
288108c gov(release): render semantic governance diffs
b50e8ef gov(assurance): require candidate witnesses
419c35c gov(assurance): separate completion evidence
faa1e59 gov(assurance): gate completed governance
37255ae gov(release): classify terminal introductions
ed1c61c gov(release): clarify governance impact
03b2d54 gov(roadmap): preserve immutable governance history
```

## PR #2 state

PR: `klarkc/govenv#2`, `chore(main): release 0.2.0`

```text
state: OPEN
isDraft: false
mergeable: MERGEABLE
base: 87937cb8a4eb98fdfa557069f788c5bd757db4b5
head: 1abb04fd9a4d3edd76fbec3912f10a20aa1da997
```

PR branch:

```text
1abb04f chore(materialize): update release governance impact
e8746ef chore(main): release 0.2.0
87937cb chore(materialize): update governed materializations
```

The user manually approved a previously blocked Actions execution. The visible `test` check is successful and GitHub showed “All checks have passed”. This is NOT permission to merge/release.

The actual PR body still uses the renderer committed in `288108c`: collapsible `<details>` groups and separate introduced cards. The newer UI discussed below was only tested manually in GitHub Preview; it is NOT implemented yet.

The user explicitly corrected workflow ownership: do NOT manually edit PR #2. Push governed source changes to `main`; CI/Release Please/materialization updates PR #2.

## What `288108c` implemented

Commit:

```text
288108c gov(release): render semantic governance diffs
Refs: GV70 GV75 GV76
```

Main changes:

- Added `src/Govenv/Projection/SemanticDiff.agda` with word-based `same` / `changed` spans.
- Improved semantic alignment to prefer nearby unique anchors; GV14→GV60 became much cleaner.
- Added typed `lookupGovernance` / `lookupGovernanceRef` in `Kernel.Roadmap`.
- `ReleaseDocument` carries the current typed roadmap so supersession targets are resolved semantically, not by projection hacks.
- Removed redundant per-item progress label design.
- Identical-proposition supersession (GV40→GV67) no longer produces fake duplicated before/after rows.
- Fixed PR insertion placement: governance now goes immediately after `## [version]`.
- Root `Govenv.lagda.md`, `SemanticDiff`, and `Projection.ReleaseGovernance` typechecked; adapters compiled/generated previews. Do not infer full `devenv test` passed.
- CI `Materialize` run `34522194745` succeeded and produced `87937cb`.

Current `src/Govenv/Projection/ReleaseGovernance.agda` still has ONE `renderDocument` used by BOTH `renderBodyMaterialization` and `renderChangelogMaterialization`, and `renderGroup` still emits `<details>`. This is the next major refactor.

## GV75 / GV76

Exact GV75:

```text
GV 75 "Render release governance item changes as compact semantic diffs: remove redundant per-item progress labels, align before/after propositions for supersessions, visually distinguish only changed spans, and deterministically wrap or elide common context while preserving the full typed governance delta." ◇
```

Exact GV76:

```text
GV 76 "Make governance references in Git-derived projections revision-aware and navigable: linked identities, lifecycle states and operators, transitions, and elisions must resolve to documentation derived from the immutable Git revision or delta they represent; before-state references use the base revision and after-state references use the candidate or head revision." ◇
```

GV76 is deferred. Future link semantics already agreed: before links use base revision; after links use head/candidate; transition operators may link to the delta; never silently link historical references to mutable current docs.

## GitHub renderer experiments — validated behavior

What does NOT work:

- `<table width="100%">` does not reliably stretch the table in GitHub.
- Raw HTML `<table align="center">...</table>` centers, but Markdown/MathJax inside cells was rendered literally, so it breaks the color diff.

What DOES work:

```html
<div align="center">

| normal Markdown table |
| --- |
| MathJax works here |

</div>
```

This was validated in GitHub Preview, including from a mobile viewport using desktop-mode GitHub. It centers the Markdown table, preserves table parsing, preserves MathJax red/green colors, and is responsive. Do not chase a fragile full-width hack; natural-width centered supersession cards were accepted as the practical solution.

Color is important. The user explicitly noticed when colors disappeared. Keep red for removed spans/sign and green for added spans/sign in the enriched GitHub projection.

Known-working pattern:

```markdown
<div align="center">

| **GV14 ↪ GV60** |
| :---: |
| $`{\color{red}\mathtt{-}}`$&nbsp;Govern&nbsp;$`{\color{red}\texttt{the README}}`$&nbsp;as&nbsp;the&nbsp;canonical&nbsp;$`{\color{red}\texttt{materialization of Govenv.Readme}}`$;&nbsp;manual&nbsp;divergence&nbsp;must&nbsp;fail&nbsp;the&nbsp;project&nbsp;check. |
| $`{\color{green}\mathtt{+}}`$&nbsp;Govern&nbsp;$`{\color{green}\texttt{README.md}}`$&nbsp;as&nbsp;the&nbsp;canonical&nbsp;$`{\color{green}\texttt{output of Govenv.Materialization.Readme}}`$;&nbsp;manual&nbsp;divergence&nbsp;must&nbsp;fail&nbsp;the&nbsp;project&nbsp;check. |

</div>
```

## Final desired enriched GitHub layout

Use the enriched GitHub presentation for BOTH:

1. Release Please PR body (preview), and
2. final GitHub Release body (publication).

The PR should be a faithful preview of the future GitHub Release.

Target structure:

```markdown
### Governance impact

**Phase:** `+ ▣ P1` — phase governance introduced  
**Items:** **61 introduced** · **16 superseded**

#### Introduced · 61

| GV | Proposition |
| :---: | --- |
| **+ GV0 ✓** | Literate `Govenv.lagda.md` closure root. |
| ... | ... |

#### Superseded · 16

<div align="center">

| **GV14 ↪ GV60** |
| :---: |
| red `-` + before proposition, only changed spans red |
| green `+` + after proposition, only changed spans green |

</div>
```

Decisions:

- no `<details>`; categories always visible;
- omit zero categories and zero counts;
- `Introduced` = ONE compact two-column Markdown table, all real items visible;
- superseded = individual centered cards;
- common text neutral, only changed spans colored;
- deterministic wrapping/elision for supersession rows, with `&nbsp;` and controlled `<br>` only in GitHub-specific projection;
- identical proposition supersession should not show duplicated diff rows; a neutral `proposition unchanged` marker + one proposition was proposed.

Tentative, NOT fully finalized: for replacements that are also introduced, a compact relation such as `… ↩ GV47` was proposed to reduce repetition. Do not assume exact notation without checking. If the column is named `Proposition`, it should still actually contain the proposition, not only “Replacement for GV47”.

## NEW final architecture decision: canonical CHANGELOG + rich PR/Release

The user explicitly wants:

```text
                    typed ReleaseEntry / GovernanceDelta
                              │
               ┌──────────────┼──────────────┐
               │              │              │
               ▼              ▼              ▼
          CHANGELOG.md      PR body      GitHub Release
          canonical        enriched        enriched
          portable MD      GitHub GFM      GitHub GFM
          versioned        preview          publication
```

Interpretation:

- `CHANGELOG.md` is the canonical VERSIONED materialization of the release entry.
- The typed release value remains the formal source; do NOT parse CHANGELOG back into semantics.
- PR and GitHub Release are enriched GitHub projections of the SAME typed release content represented canonically in the changelog.
- PR and GitHub Release should share the same governance visual language; PR is a preview of the published Release.
- GitHub-specific HTML/GFM tricks (`<div align="center">`, MathJax colors, `&nbsp;`, controlled `<br>`) belong only to the enriched GitHub renderer.
- CHANGELOG must remain portable Markdown and understandable outside GitHub.
- Canonicality does NOT mean byte-identical target renderings; it means one semantic/materialization authority and no independent semantic divergence.

Likely shape (illustrative names):

```agda
renderPortableRelease : ReleaseDocument → String
renderGithubRelease   : ReleaseDocument → String

renderChangelogMaterialization      = renderPortableRelease
renderBodyMaterialization           = renderGithubRelease
renderGithubReleaseMaterialization  = renderGithubRelease
```

A new pending GV is probably appropriate for this newly agreed policy (canonical changelog + same typed content projected to enriched PR/GitHub Release + external read-back). No GV beyond GV75/GV76 has been added for it yet.

## GitHub Release materialization — agreed, not implemented

Current `.github/workflows/release.yml` runs Release Please and, while a release PR exists, invokes `src/Govenv/Adapter/release-governance-pr.sh` to materialize changelog + PR governance impact.

Next direction:

```text
Release Please creates tag/release
        │
        ▼
Govenv.Materialization.Github.Release
        │
        ├─ expected rich body from same typed release entry
        ├─ adapter applies it
        ├─ adapter reads GitHub Release back
        └─ equality verification must pass
```

Adapter must remain effect-only. Expected structure/body belongs in typed materialization/projection code.

## Portable CHANGELOG requirement

No exact portable micro-layout was frozen, but it must be:

- ordinary portable Markdown;
- same semantic counts/items/transitions as the rich projection;
- no dependency on HTML centering or MathJax color for meaning;
- canonical/versioned;
- supersession may use bold + `-`/`+` or a `diff` fence, as long as ordinary renderers preserve meaning.

## PR placement requirement already fixed

Keep:

```text
:robot: I have created a release *beep* *boop*
---

## [0.2.0](...) (2026-09-10)

### Governance impact
...

### Features
...
```

Do not regress governance above the bot/release heading.

## Unfinished assurance work — preserve

Still local/uncommitted:

```text
 M src/Govenv/Kernel/Assurance.agda
?? Govenv/Assurance/GV60.lagda.md
```

`Kernel/Assurance.agda` contains uncommitted `establishObserved`: evaluate rule against candidate facts; `holds` => `just ObservedWitness`; `violated`/`unknown` => `nothing`; no postulate.

`Govenv/Assurance/GV60.lagda.md` is incomplete, untracked, not imported. Do NOT register GV60 as checked completion until candidate evidence is actually wired into project candidate closure.

Prior assurance state remains:

- `Govenv.Roadmap` independent of assurance;
- `CandidateEvidence` has only static/checked witness constructors, no inherited constructor;
- `completionCoverage` still does not require a CandidateEvidence value for every checked assurance;
- 9 historical `✓` remained inherited: GV0 GV1 GV2 GV19 GV22 GV44 GV45 GV51 GV60;
- `migrationComplete assurances ≡ false` intentionally;
- GV74 remains pending until inherited completions are honestly migrated and candidate-state evidence is enforced.

## Exact GV71–74 definitions

GV71 — DO NOT MODIFY:

```text
GV 71 "Restrict handwritten versioned repository content to Agda and Markdown only. Any generated or governed materialization may use its required target format. Until GV38 is completed, the only handwritten bootstrap escape hatch is root-level `devenv.nix`, `devenv.yaml`, and `devenv.lock`; all other implementation languages and handwritten configuration formats, including Nix elsewhere, are forbidden." ◇
```

GV72:

```text
GV 72 "Require every versioned repository artifact not permitted as handwritten source by GV71, except the temporary root-level `devenv.nix`, `devenv.yaml`, and `devenv.lock` bootstrap escape hatch, to be produced by exactly one governed `Govenv.Materialization.*` definition and verified against its materialized state; transient `.govenv` state is forbidden from being versioned." ◇
```

GV73:

```text
GV 73 "Require every persisted supporting artifact, including snapshots, fixtures, baselines, schemas, test vectors, and evidence, to be colocated with the module that semantically owns it; catch-all artifact directories are forbidden unless the artifact is genuinely project-global." ◇
```

GV74:

```text
GV 74 "Make governance completion evidence-bearing and persistent: a governance item may transition to `done` only when governed evidence establishes its proposition for the candidate repository state, and every non-superseded `done` item, including items completed before this rule, must remain satisfied in every subsequent valid repository state." ◇
```

## Supersession chains

```text
47→68, 49→69, 9→57, 10→58, 11→59, 17→61→62, 14→60, 23→63,
48→70, 7→55, 8→56, 25→64, 27→65, 28→66, 40→67
```

## Next-session priority

1. Preserve unfinished assurance files.
2. Fast-forward local `main` to `87937cb` safely.
3. Split release rendering into portable CHANGELOG vs enriched GitHub renderer.
4. Consider/add a pending GV for canonical changelog + rich PR/Release + read-back semantics.
5. Implement final PR UI: no collapse, zero groups omitted, one introduced table, centered MathJax supersession cards.
6. Add governed GitHub Release body materialization using the SAME enriched renderer as the PR.
7. Extend workflow/adapter minimally for post-release apply + read-back equality.
8. Typecheck root/targeted release modules; compile adapters; preview all three outputs.
9. Push to `main`; let CI update PR #2. Do not manually edit it.
10. Notify user when PR #2 is ready for visual review.
11. Do NOT merge/tag/publish until explicit release approval.
12. After release governance is satisfactory, resume GV60/GV74 assurance work, then GV71/72, then GV73.

## Continuation prompt

> Continue from this handoff using Desktop Commander and GitHub. Preserve the unfinished GV60 assurance work, fast-forward local main safely, then implement the agreed split where CHANGELOG.md is the canonical portable materialization while PR #2 and the final GitHub Release share the enriched GitHub governance presentation; let CI update PR #2 and notify me when it is ready for visual review. Do not merge/release without my explicit approval.
