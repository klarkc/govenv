# Govenv session handoff — constitutional history, propositions, obligations, supersession and derived state

**Date:** 2026-09-17  
**Repository:** `klarkc/govenv`  
**Purpose:** Continue the governance-lineage redesign in a new session without losing the refinements made after `govenv-session-handoff-2026-09-16-proposition-supersession-roadmap-delta(1).md`.

---

## 1. Session starting point

The previous handoff had already established:

```text
Governance
    ↓ declares
Proposition
    ↓ evidence/proof
Obligation
    ↓ constitutional evolution
Disposition
```

with these important constraints:

```text
- Governance must not own a fundamental lifecycle state.
- Proposition is the governed logical statement.
- Obligation means a Proposition has been constitutionally established.
- No pending/staged/non-operative Obligation.
- Pending is derived.
- Disposition is the constitutional destiny of a Proposition.
- Supersession is a relation between Governance items, not a GV status.
- Proposition identity must survive preservation across GVs.
- Proposition IDs should be globally unique.
- No general GV dependency DAG.
- Proposition/Obligation lineage is the long-term graph.
- README / CHANGELOG / PR / Release are projections only.
```

This session refined the formal topology further.

---

## 2. `PropositionId` should be independent from `GovernanceId`

Do not reuse the generic `Identifier Nat String` design for Proposition.

Preferred direction:

```agda
data PropositionId : Nat → Set where
  Prop : (idx : Nat) → PropositionId idx
```

Reason:

```text
GovernanceId
  Nat + String contract

PropositionId
  Nat only
```

The Governance `String` is the human/AI contract.

The Proposition has a formal `Statement`.

Do not add a String to Proposition just for symmetry.

---

## 3. Formal `Proposition` should contain identity + formal statement

Preferred conceptual type:

```agda
record Proposition (idx : Nat) : Set₁ where
  constructor proposition
  field
    propositionId : PropositionId idx
    Statement     : Set
```

Three distinct layers:

```text
Prop 17
    = immutable constitutional identity

Proposition 17
    = constitutional entity

Statement
    = formal logical meaning
```

This avoids conflating the existing local `Proposition : Set` declarations with the new constitutional Proposition entity.

---

## 4. Rename current assurance-local `Proposition : Set` to `Statement`

Current assurance modules commonly define:

```agda
Proposition : Set
proof : Proposition
```

In the new model, that local logical type should become something like:

```agda
Statement : Set
proof : Statement
```

while the constitutional entity is:

```agda
prop17 : Proposition 17
```

This removes a major naming collision.

---

## 5. `origin` should not be stored inside Proposition

Do not do:

```agda
record Proposition where
  ...
  origin : Governance
```

Instead model introduction as a constitutional relation/event:

```text
GV10 ──introduces──> Prop7
```

Then:

```text
origin(Prop7)
```

is derived from the unique historical introduction.

Reason:

```text
origin
  = immutable historical fact

currentResponsibility
  = derived current relation
```

They must not be conflated.

---

## 6. Evidence should eventually be indexed by Proposition, not GV number

Current kernel:

```agda
StaticEvidence 68
ObservedEvidence 60
```

implicitly means “evidence for GV68/GV60”.

New semantic direction:

```text
Evidence proves Proposition
Governance declares Proposition
```

So prefer:

```agda
record StaticEvidence
  {idx : Nat}
  (p : Proposition idx) : Set₁ where
  field
    proof : Proposition.Statement p
```

This makes mismatched evidence impossible by construction.

---

## 7. Constitutional `Obligation`

Preferred conceptual shape:

```agda
record Obligation
  {idx : Nat}
  (p : Proposition idx) : Set₁ where
  field
    evidence : Evidence p
```

Meaning:

```text
Obligation(p)
=
p has been constitutionally established
with evidence
```

Do not reintroduce:

```text
ObligationState
staged Obligation
operative Bool
established Bool
```

---

## 8. Naming collision: current `Rule` / `Verdict` also use `Obligation`

Current kernel uses:

```agda
Verdict Diagnostic Obligation
unknown : Obligation → Verdict Diagnostic Obligation
```

and `Rule` has:

```agda
(Diagnostic Obligation : Set)
```

That `Obligation` is the payload explaining what remains unknown, not a constitutional obligation.

Future migration should probably rename that parameter, e.g.:

```text
Requirement
```

so constitutional `Obligation` can keep the precise meaning established above.

No code change was made for this yet.

---

## 9. `TransitionId` is unnecessary

We considered:

```text
T1
T2
T3
```

for constitutional transition identity.

Conclusion:

```text
Do not add TransitionId.
```

The ordering/position of a transition in the append-only constitutional history is sufficient historical identity.

However, a generic **Transition concept** is useful.

---

## 10. Important correction: `Disposition` cannot exist only inside Supersession

Previous thinking leaned toward:

```text
Disposition = event inside a Supersession
```

But `✓*` exposes a case where a pending Proposition may be abandoned without any GV supersession:

```text
GV100
├── ✓ Prop50
├── ✓ Prop51
└── × Prop52
```

Therefore:

```text
abandonment
```

must also be possible as a standalone constitutional transition.

Revised direction:

```text
Transition
├── establishment
├── abandonment
└── supersession
```

`Disposition` remains the fate assigned to a Proposition by a transition that ends/transfers its previous constitutional situation.

---

## 11. Constitution should be append-only history, not current state

Reject:

```agda
record Constitution where
  propositions
  obligations
  currentOwners
  currentStates
  ...
```

because this stores derived state and hides lineage.

Preferred core:

```agda
data History : Set₁ where
  ε   : History
  _▻_ : History → HistoryEntry → History
```

Conceptually:

```text
ε
│
├─ declare GV10 / Prop7
├─ establish Prop7
├─ declare GV20 / Prop12
├─ supersede GV10 GV20
│    ≡ Prop7
└─ ...
```

The Constitution is a valid historical prefix, not a mutable snapshot of current facts.

---

## 12. Validate history separately from raw history

Avoid recursive construction where every history node requires a full Constitution value.

Better:

```agda
data History : Set₁ where
  ε   : History
  _▻_ : History → HistoryEntry → History
```

then:

```agda
data ValidHistory : History → Set₁ where

  empty :
    ValidHistory ε

  extend :
    {history : History} →
    ValidHistory history →
    (entry : HistoryEntry) →
    ValidEntry history entry →
    ValidHistory (history ▻ entry)
```

This gives:

```text
historical facts
+
proof each fact was valid relative to the prefix before it
```

---

## 13. Minimal historical entry set

Current preferred minimum:

```text
declare
establish
abandon
supersede
```

Conceptually:

```agda
data HistoryEntry : Set₁ where
  declare   : GovernanceDeclaration → HistoryEntry
  establish : Establishment → HistoryEntry
  abandon   : PropositionRef → HistoryEntry
  supersede : Supersession → HistoryEntry
```

Do not create separate history entries for:

```text
withdrawn
reformulated
preserved
```

because those only make sense inside an atomic supersession cutover.

`abandon` is the exception because pending scope may be abandoned without superseding its GV.

---

## 14. `GovernanceDeclaration`

Preferred direction:

```agda
record GovernanceDeclaration : Set₁ where
  field
    governance   : SomeGovernanceId
    phase        : SomePhaseId
    propositions : List SomeProposition
```

Important:

```text
propositions = []
```

must be allowed.

Example:

```text
GV10 introduces Prop7

GV10 ↪ GV20
  ≡ Prop7
```

GV20 may introduce no new Proposition and only inherit responsibility for Prop7.

This confirms:

```text
introduced propositions
≠
all propositions relevant to a GV
```

---

## 15. Declaration validity

A valid `declare` must ensure:

```text
- GovernanceId was never declared before.
- Governance contract/phase are fixed by the original declaration.
- Every new Prop n is globally fresh.
- A Proposition is introduced exactly once.
```

Therefore changing:

```text
GV47 "contract A"
```

into:

```text
GV47 "contract B"
```

is not a state transition — it is rewriting constitutional history.

---

## 16. Derived historical predicates

Do not store lifecycle state.

Derive at least:

```text
Declared h p
EverEstablished h p
WasAbandoned h p
Terminated h p
Live h p
Pending h p
Active h p
```

Suggested semantics:

```text
Terminated
=
abandoned
or withdrawn
or reformulated
```

Not:

```text
preserved
```

Then:

```text
Live h p
=
Declared h p
and not Terminated h p
```

```text
Pending h p
=
Live h p
and not EverEstablished h p
```

```text
Active h p
=
Live h p
and EverEstablished h p
```

---

## 17. `EverEstablished` vs current active obligation

Important distinction:

```text
EverEstablished h p
```

is historical and monotonic.

Once true, always true.

```text
Active h p
```

means:

```text
p was established
and is still live
```

Example after withdrawal:

```text
EverEstablished Prop10 = true
Live Prop10            = false
Active Prop10          = false
```

No `ObligationState = withdrawn` is needed.

---

## 18. `establish` validity

A normal establishment must satisfy:

```text
Pending h p
and evidence proves Statement p
```

Consequences:

```text
- cannot establish same Prop twice
- cannot establish an abandoned Prop
- cannot establish a withdrawn Prop
- cannot establish a reformulated Prop
```

If the same semantic rule returns later, create a new Proposition ID.

---

## 19. Standalone `abandon`

A standalone abandonment is valid only for:

```text
Pending h p
```

After:

```text
abandon Prop52
```

derive:

```text
WasAbandoned = true
Live         = false
```

This is how a Governance can end as:

```text
✓*
```

without any supersession.

---

## 20. Planning vs effective supersession

Keep both concepts, but separate layers.

Roadmap planning:

```text
GV77 ↝ GV95
```

Constitutional fact:

```text
GV77 ↪ GV95
```

Therefore:

```text
↝  = roadmap intent / SupersessionPlan
↪  = effective constitutional Supersession
```

Do not encode:

```text
SupersessionState = planned | effective
```

---

## 21. `Supersession`

Current minimal conceptual direction:

```agda
record Supersession : Set₁ where
  field
    previous       : GovernanceRef
    successor      : GovernanceRef
    establishments : List Establishment
    dispositions   : List PropositionDisposition
```

where:

```agda
record PropositionDisposition : Set where
  field
    proposition : PropositionRef
    disposition : Disposition
```

and:

```text
Disposition
├── preserved
├── abandoned
├── withdrawn
└── reformulated targets
```

The exact dependent Agda representation remains to be spiked.

---

## 22. Supersession is atomic

Never model:

```text
withdraw old Prop
publish intermediate Constitution
establish new Prop
publish
mark GV superseded
```

Instead:

```text
before
  │
  │ one Supersession history entry
  ▼
after
```

The entry contains all dispositions and any replacement establishments required for the cutover.

No publishable intermediate constitutional state.

---

## 23. `outgoing`

For history `h` and Governance `g`:

```text
outgoing h g
```

must derive:

```text
all live Propositions p such that
currentResponsibility h p = g
```

Example:

```text
GV10 introduced Prop7

GV10 ↪ GV20
  ≡ Prop7

GV20 introduced Prop12
GV20 introduced Prop13
```

then:

```text
outgoing h GV20
=
[Prop7, Prop12, Prop13]
```

It is based on current responsibility, not origin.

---

## 24. Supersession coverage

The subjects of the dispositions must exactly equal the outgoing set for the old GV.

Conceptually:

```text
subjects(dispositions)
=
outgoing h previous
```

plus uniqueness.

This prevents:

```text
- forgetting a live inherited proposition
- disposing the same proposition twice
- disposing an unrelated proposition
```

Potential formal direction:

```agda
SupersessionCoverage h s =
  Unique (subjects s)
  ×
  subjects s ≡ outgoing h (previous s)
```

or an equivalent dependent `All` structure.

---

## 25. Disposition validity matrix

Keep rigid:

| Before | preserved | abandoned | withdrawn | reformulated |
|---|---:|---:|---:|---:|
| pending | valid | valid | invalid | invalid |
| active obligation | valid | invalid | valid | valid |

This should be enforced by types/proofs:

```text
abandoned
  requires Pending

withdrawn
  requires Active

reformulated
  requires Active

preserved
  requires Live
```

No lifecycle enum.

---

## 26. `preserved` transfers responsibility

A preserved Proposition remains the same identity:

```text
Prop7 ≡ Prop7
```

and the successor becomes its current responsible Governance.

Therefore do not add separate facts such as:

```text
inherit
transferOwnership
ownerState
```

`preserved` itself is the transfer event.

---

## 27. Reformulation replacement rules

For:

```text
Prop17 ⇒ Prop23
```

the replacement must belong to the successor’s constitutional scope.

It may be:

```text
already active before cutover
```

or:

```text
established atomically inside the Supersession
```

This allows overlap or exact atomic replacement without a normative gap.

Suggested semantic predicate:

```text
ReplacementReady h s Prop23
=
Active h Prop23
OR
EstablishedByCutover s Prop23
```

---

## 28. No replacement establishment smuggling

Any establishment embedded inside a Supersession must be used by at least one `reformulated` disposition.

Otherwise someone could hide an unrelated establishment inside the cutover.

Independent new obligations must be established by a normal `establish` entry.

---

## 29. Split and merge remain natural

Split:

```text
Prop10 ⇒ Prop20, Prop21
```

Merge:

```text
Prop10 ┐
Prop20 ├⇒ Prop100
Prop30 ┘
```

can be represented by ordinary reformulation targets.

No split/merge constructors required.

---

## 30. `origin`

Derived only from the unique introduction:

```text
origin Prop7 = GV10
```

A Proposition may later be preserved through multiple GVs without changing origin.

---

## 31. `currentResponsibility`

Preferred strong signature:

```agda
currentResponsibility :
  (h : History) →
  (p : PropositionRef) →
  Live h p →
  GovernanceRef
```

Not:

```text
Proposition → Maybe Governance
```

in the core.

The `Maybe` form can exist in projection/query layers.

Example:

```text
GV10 introduced Prop7
GV10 ↪ GV20 ≡ Prop7
GV20 ↪ GV30 ≡ Prop7
```

then:

```text
origin Prop7                = GV10
currentResponsibility Prop7 = GV30
```

---

## 32. Governance subjects

Using only “Propositions introduced by GV” is insufficient.

A Governance may introduce nothing but inherit a preserved Proposition.

Therefore derive:

```text
GovernanceSubjects h g
```

from at least:

```text
- Propositions introduced by g
- Propositions handled by g as successor in a Supersession
```

Example:

```text
GV10 ↪ GV20
  ≡ Prop7
```

GV20 has `Prop7` as a subject even if it introduced no new Prop.

---

## 33. Derived Proposition resolution

A small derived enum is acceptable because it is not stored:

```text
pending
established
abandoned
```

Suggested derivation:

```text
if EverEstablished p
  => established

else if WasAbandoned p
  => abandoned

else
  => pending
```

Important:

```text
withdrawn
reformulated
```

still derive as historically `established`.

They do not become abandonment.

---

## 34. Governance glyph derivation

For:

```text
GovernanceSubjects h g
```

derive:

```text
◇
  if any subject is pending

×
  if none pending
  and all are abandoned

✓*
  if none pending
  and at least one established
  and at least one abandoned

✓
  if all subjects are established
```

For an empty subject set, current preferred default is:

```text
◇
```

because the GV has no resolved semantic content yet.

This remains worth testing in the spike.

---

## 35. Pure preservation example

```text
GV10
└── Prop7 established

GV10 ↪ GV20
    ≡ Prop7
```

GV20 introduces nothing.

Derived:

```text
GovernanceSubjects GV20 = [Prop7]
resolution Prop7        = established
```

so:

```text
✓ GV20
```

If Prop7 was still pending, GV20 would be:

```text
◇ GV20
```

until it is established.

---

## 36. Withdrawal example

```text
GV10:
  Prop7 established

GV10 ↪ GV20
  ⊘ Prop7
```

Prop7 becomes non-live but remains historically established.

Therefore:

```text
✓ GV20
```

is compatible with withdrawal.

The status means the relevant Proposition had acquired normative force; GV20 later removed that force.

---

## 37. Historical case: GV47 ↪ GV68

Candidate migration semantics:

```text
declare GV47
  Prop17

establish Prop17

declare GV68
  Prop23

supersede GV47 GV68
  Prop17 ⇒ Prop23
  establish Prop23 atomically
```

After:

```text
Prop17:
  EverEstablished = true
  Live            = false

Prop23:
  EverEstablished = true
  Live            = true
  responsibility  = GV68
```

Projection:

```text
✓   GV47   ↪ GV68
✓   GV68
```

Detailed:

```text
✓   GV47   ↪ GV68
    ⇒   Prop17 → Prop23
```

---

## 38. Historical case: GV77 ↪ GV95

Candidate semantics:

```text
declare GV77
  Prop41
```

Prop41 remains pending.

Later:

```text
declare GV95
  Prop60

supersede GV77 GV95
  × Prop41
```

After:

```text
Prop41:
  WasAbandoned = true
  Live         = false
```

Projection:

```text
×   GV77   ↪ GV95
◇   GV95
```

If Prop60 is later established, then GV95 has:

```text
Prop41 abandoned
Prop60 established
```

and therefore:

```text
✓* GV95
```

This was considered a desirable result.

---

## 39. Important consequence for GV54

Current GV54 assurance explicitly checks:

```text
governance removed
definition changed
phase changed
completion regression
cancelled rewrite
supersession rewrite
```

With append-only Constitution history, these mostly collapse into one fundamental property:

```text
previousHistory ⊑ currentHistory
```

If the previous history is not a prefix of the candidate history, constitutional past was rewritten.

This subsumes:

```text
- removal
- contract mutation
- phase-owner mutation
- supersession rewrite
- disposition rewrite
- evidence-establishment rewrite
```

This is structurally stronger than old `ItemState` transition validation.

---

## 40. Important consequence for GV70 / release delta

Current `Kernel.Release` derives changes by comparing old and new `ItemState`.

Future direction:

```text
currentHistory
=
previousHistory ++ newEntries
```

Then:

```text
GovernanceDelta
=
newEntries
```

with semantic projection from those typed entries.

Example:

```text
declare GV95
supersede GV77 GV95
```

directly yields:

```text
Governance:
  GV95 introduced
  GV77 ↪ GV95

Propositions:
  Prop41 abandoned
  Prop60 introduced
```

No inference from:

```text
todo → cancelled
todo → superseded
```

---

## 41. `advanced` should leave constitutional delta

Current release model has:

```text
advanced
```

when pending GV is referenced by commits.

That is development/activity metadata, not constitutional change.

Future release may optionally show:

```text
Activity:
  GV57 referenced by N commits
```

but `advanced` should not be a constitutional history entry or GovernanceDelta event.

---

## 42. Snapshot should represent semantic constitutional history

Keep snapshots.

Do not rely on Git history to reconstruct semantics.

Distinguish:

```text
Git history
  = physical repository history

Constitution history
  = typed semantic history
```

Future snapshot should represent a canonical constitutional history prefix, or equivalent stable typed representation.

Core validation becomes:

```text
previousSnapshot.history
  ⊑
candidateSnapshot.history
```

---

## 43. Evidence persistence vs current satisfaction

Do not conflate:

```text
evidence that established an Obligation
```

with:

```text
evidence that an active Obligation remains satisfied
in the current candidate repository state
```

Static proof may naturally persist.

Observed evidence may need re-checking.

Likely future separation:

```text
Constitution
  derives ActiveObligations

Assurance
  checks current candidate state
  against ActiveObligations
```

This fits the intent of GV74.

Do not solve this prematurely in the history spike.

---

## 44. Revised topology

```text
                    Roadmap / declarations
                            |
                            v
                       Governance
                            |
                        introduces
                            |
                            v
                       Proposition
                            |
             +--------------+---------------+
             |                              |
             v                              v
          Statement                       History
                                            |
                         +------------------+------------------+
                         |                  |                  |
                         v                  v                  v
                   Establishment       Abandonment       Supersession
                                                              |
                                                        Dispositions
                                                    +-----+-----+-----+
                                                    ≡     ⇒     ⊘     ×
```

Derived from history:

```text
origin
live
pending
active obligation
current responsibility
outgoing
GovernanceSubjects
PropositionResolution
GovernanceGlyph
OperativeConstitution
GovernanceDelta
README
CHANGELOG
PR
Release
```

---

## 45. Explicitly avoid reintroducing

Do not bring back without strong justification:

```text
ItemState
Governance lifecycle status
ObligationState
pending Obligation
staged Obligation
operative Bool
P(GV n, localIndex) as Prop identity
TransitionId
general GV dependency DAG
advanced as constitutional event
owner stored on Proposition
origin stored on Proposition
superseded as the GV's state
```

---

## 46. Repository inspection performed

Read-only inspection confirmed:

```text
src/Govenv/Kernel/Identifier.agda
src/Govenv/Kernel/Assurance.agda
src/Govenv/Kernel/Roadmap.agda
src/Govenv/Kernel/Release.agda
Govenv/Assurance/GV54.lagda.md
Govenv/Assurance/GV70.lagda.md
Govenv/Roadmap.lagda.md
Govenv/Release.lagda.md
Govenv/Materialization/RoadmapSnapshot.lagda.md
```

Relevant findings:

```text
- current roadmap stores ItemState
- current release delta compares lifecycle states
- GV54 proves mutation/removal/terminal-state rejection by snapshot comparison
- GV70 classifies introduced/advanced/completed/cancelled/superseded
- current assurance uses local Proposition : Set
- current Rule/Verdict use the name Obligation for unknown requirements
```

---

## 47. Local workspace caution

Pre-existing unrelated local work was detected and left untouched:

```text
M  src/Govenv/Kernel/Assurance.agda
?? Govenv/Assurance/GV60.lagda.md
?? govenv-gv84-release-main/
```

An accidental `.devenv.flake.nix` produced during inspection was removed.

No intended repository changes were made by this session.

---

## 48. Recommended next step

Do not migrate the real kernel yet.

Create an isolated Agda spike for the new topology and encode only:

```text
PropositionId / Proposition
GovernanceDeclaration
HistoryEntry
History
ValidHistory
Declared
EverEstablished
WasAbandoned
Terminated
Live
Pending
Active
Origin
CurrentResponsibility
Outgoing
Disposition
Supersession
SupersessionCoverage
PropositionResolution
GovernanceSubjects
GovernanceGlyph
```

Then exercise exactly four scenarios:

```text
1. simple establishment
   expected glyph: ✓

2. establishment + abandonment
   expected glyph: ✓*

3. GV47 ↪ GV68 reformulation
   expected glyphs: ✓ / ✓

4. GV77 ↪ GV95 abandonment
   expected glyphs: × / ◇
```

Success criterion:

```text
All four reduce/typecheck in Agda
without:
- ItemState
- stored owner/current responsibility
- stored GV lifecycle status
- special-case projection hacks
```

Only after that should migration strategy for Roadmap, snapshots, release delta, and assurance be designed.

---

## 49. Resume from here

Resume next session from:

> **Build the isolated Agda history spike and validate the four canonical scenarios before changing the real Govenv kernel.**
