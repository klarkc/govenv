# Govenv session handoff — post-PR #32 merge, global coherence and project purpose

Date: 2026-09-22  
Repository: `klarkc/govenv`  
Status: PR #32 merged

## 1. What was completed

PR #32 was fully reworked, validated, pushed, reviewed by the user, and merged.

Final PR title before merge:

`gov(architecture): align semantic domains, purpose, and integration roadmap`

The branch used was:

`spike/constitutional-history`

The validated pre-merge head was:

`72786747c8f2e19053e54baa610cda79b02b1fce`

The base `main` SHA at validation time was:

`8af5ae63bf4590e134cd6826c48aba70f0881f2d`

The PR was reported by GitHub as mergeable before the user merged it.

Do not assume these SHAs are still `main` after merge; inspect GitHub/repo state in the new session.

---

## 2. Canonical project purpose

`Govenv.Project` now owns the canonical project purpose and public project identity metadata.

Final intended values:

```agda
name : String
name = "Govenv"

descriptionCharacterLimit : Nat
descriptionCharacterLimit = 250

purposeCharacterLimit : Nat
purposeCharacterLimit = 500

description : String
description =
  "A type system for your repository. Govern code, configuration, tooling, CI, and AI agents through one typed Govenv model."

purpose : String
purpose =
  "Turn a repository into a formally governed environment where code, configuration, tooling, CI, and AI agents operate from one typed and verifiable Govenv semantic model, with Governance defining validity, Protocol guiding process, and governable obligations enforced at their earliest sound information boundary."

website : String
website = "https://klarkc.github.io/govenv/"

topics : List String
topics =
    "agda"
  ∷ "ai-agents"
  ∷ "devenv"
  ∷ "formal-methods"
  ∷ "nix"
  ∷ "repository-governance"
  ∷ []
```

Static proofs were added so the compiler enforces:

- `description <= 250` characters
- `purpose <= 500` characters

The README now projects the full purpose under a `## Purpose` section.

The public GitHub description remains a concise summary of that purpose.

`Govenv.Readme.docsUrl` now derives from `Govenv.Project.website` rather than duplicating the Pages URL.

---

## 3. Project purpose stewardship

`Govenv.Protocol` now includes a `Project purpose stewardship` section.

The intent is:

- `Govenv.Project.purpose` is the long-term criterion for project coherence.
- Before a material change to:
  - project scope,
  - architecture,
  - product boundaries,
  - roadmap direction,
  - supported contributor workflow,
  - supported AI-agent workflow,
  compare the candidate direction with the current purpose.
- If the purpose is no longer accurate, update it deliberately as part of the same conceptual change.
- Do not rewrite the purpose merely to justify a local implementation/design decision.
- Keep:
  - public description,
  - README purpose,
  - website,
  - topics
  coherent with the canonical purpose.

This stewardship is Protocol: it guides contributors/agents. The actual governed state and materialization contracts are Governance/project semantics.

---

## 4. GitHub repository metadata is governed

Previously only description had a dedicated external materialization path.

Now GitHub repository metadata includes:

- description
- website/homepage
- topics

New materializations:

- `Govenv.Materialization.Github.Repository.Description`
- `Govenv.Materialization.Github.Repository.Website`
- `Govenv.Materialization.Github.Repository.Topics`

New projections:

- `src/Govenv/Projection/Github/Repository/Description.agda`
- `src/Govenv/Projection/Github/Repository/Website.agda`
- `src/Govenv/Projection/Github/Repository/Topics.agda`

The old adapter:

`src/Govenv/Adapter/Github/Repository/DescriptionApplication.agda`

was replaced by:

`src/Govenv/Adapter/Github/Repository/MetadataApplication.agda`

The new adapter applies all three metadata classes in one operational step and performs read-back verification.

Topics are compared as a set, not by list ordering.

The verification type was tightened so the compiler distinguishes:

- `descriptionReadBackEquality`
- `websiteReadBackEquality`
- `topicsReadBackSetEquality`

This avoids accidentally treating topic-list order as semantic equality.

The admin setup step was renamed from repository-description to repository-metadata and now executes:

`.govenv/admin-apply-build/MetadataApplication`

Important: the PR only governed/materialized these values. It did not directly mutate GitHub during development; actual external application should still happen through the governed `Admin Materialize` path.

At the time of research, GitHub currently exposed:

- description: prior shorter Govenv description
- homepage: `https://klarkc.github.io/govenv/`
- topics: `agda`, `devenv`, `nix`

The governed target topics after PR #32 are broader:

`agda`, `ai-agents`, `devenv`, `formal-methods`, `nix`, `repository-governance`

After merge, check whether `Admin Materialize` has been run and whether GitHub read-back matches the new governed metadata.

---

## 5. Governance vs Protocol

The project now explicitly distinguishes:

### Governance

Constitutional normative authority.

Defines repository/system:

- valid/invalid states,
- permitted/forbidden transitions,
- effects,
- authorization,
- semantic properties.

Governance validity is independent of which contributor or agent produced the state.

### Protocol

Non-constitutional normative process guidance.

Examples:

- how contributors/agents should investigate,
- preferred ordering,
- reuse-first workflow,
- project-purpose stewardship,
- documentation ownership conventions.

Protocol compliance itself does not make a repository state constitutionally valid/invalid.

However, Governance may independently require canonical Protocol materializations (e.g. `AGENTS.md`) to equal their source.

`AGENTS.md` is a tracked materialization of `Govenv.Protocol`; it is not semantic authority.

---

## 6. GV101 — corrected global classification

The previous inventory model was too binary:

`Governance vs irreducible effects`

That did not leave a legitimate semantic place for Protocol.

Therefore:

- GV57 → superseded by GV101
- GV58 → superseded by GV101
- GV59 → superseded by GV101

GV101 states conceptually:

> Partition project requirements/mechanisms into Governance, Protocol, and irreducible observation/effect execution.

Key rule:

- expressible/checkable properties that determine constitutional validity belong to Governance;
- contributor/agent process guidance remains Protocol even if machine-checkable;
- following Protocol does not itself determine repository validity;
- adapters only observe/apply/verify effects and do not create semantic authority.

This was one of the most important global-coherence corrections.

---

## 7. GV102 — corrected materialization semantics

GV51 previously implied that `Govenv.Materialization.*` owns all semantic content, structure, ordering, inclusion, policy, etc.

That became inconsistent once `Govenv.Protocol` became the semantic owner of `AGENTS.md`.

Therefore:

GV51 → superseded by GV102.

GV102 separates:

### semantic authority

May come from:

- Governance
- Protocol
- `Govenv.Project`
- other governed semantic/project state

### materialization binding

`Govenv.Materialization.*` owns:

- target binding,
- target-specific composition,
- target-specific ordering/inclusion,
- application mode,
- privilege,
- authority requirement,
- verification method.

### Projection

Encodes target representation.

### Adapter

Observes/applies/verifies effects only.

Do not reintroduce the idea that Materialization re-owns Governance/Protocol semantics.

---

## 8. Architecture redesign — GV98

The earlier Architecture model was filesystem-oriented:

`path -> role`

This was rejected.

The intended split is now:

```text
SourceLayout
    FilePath -> source/discovery boundary

Architecture
    Agda semantic identity -> Role
```

Architecture uses Agda Reflection `Name`.

Do not invent a fake first-class `ModuleName` unless upstream Agda actually provides one appropriate to the use case.

Final role vocabulary established in PR #32:

- `governance`
- `protocol`
- `assurance`
- `kernel`
- `experiment`
- `materialization`
- `projection`
- `adapter`

Things intentionally NOT modeled as semantic roles:

- root closure
- source layout
- generated artifacts

Those are composition/layout/materialization concerns.

`Assurance` was explicitly added because it is a real semantic domain already present in the repository.

Current architecture module defines role vocabulary and allowed dependency directions but GV98 remains TODO: full repository declaration classification/import enforcement does not yet exist.

Important dependency intentions:

- `experiment -> kernel`
- never `kernel -> experiment`
- Governance may depend on Kernel
- Protocol may depend on Governance
- Assurance may depend on Governance, Protocol, Materialization, Projection, Kernel
- Materialization may depend on Governance, Protocol, Kernel
- Projection may depend on Materialization, Kernel
- Adapter is the outer effect layer and may depend inward as required, but cannot introduce semantic authority

Exact list should be inspected in current `Govenv/Architecture.lagda.md` after merge rather than assumed unchanged.

---

## 9. SourceLayout / GV1

Source paths remain relevant only for source discovery/layout.

Current GV1 assurance still uses a source-placement boundary:

- tracked `*.agda`
- tracked `*.lagda.md`
- reject source outside governed Govenv roots

The canonical counterexample lives at:

`Govenv/Assurance/GV1/Counterexample/SourcePlacement.lagda.md`

The old standalone architecture counterexample file was removed.

Important:

GV1 source placement is NOT semantic architecture classification.

The project deliberately avoids claiming that filesystem path establishes architectural role.

GV1 still has legacy assurance debt for stronger semantic classification.

---

## 10. Counterexamples — GV99

GV99 establishes the intended organization:

`Govenv/Assurance/GV<n>/Counterexample/*.lagda.md`

Persisted counterexamples should be governed literate evidence owned by the Assurance boundary they refute.

Any external fixture needed to exercise the counterexample should be a governed materialization of the canonical evidence, not an independent handwritten authority.

Historical fixtures have not necessarily all been migrated yet.

---

## 11. Artifact authority — GV96

GV96 supersedes GV71/GV72.

Target model:

- handwritten semantic authority:
  - code-first `.agda`
  - human-facing normative `.lagda.md`
- implementation/experiment documentation lives with owning `.agda`
- Governance/Protocol/evidence may use literate `.lagda.md`
- every other versioned artifact must converge on exactly one governed Materialization definition
- transient `.govenv` state must not be versioned
- current Stage-0 bootstrap escape hatch still exists until GV38 is done:
  - root `devenv.nix`
  - root `devenv.yaml`
  - root `devenv.lock`

Earlier design direction still applies:

- final target should avoid versioned `devenv.yaml`
- `devenv.lock` should become transient/ignored if deterministically derivable
- `devenv.nix` should eventually be governed/materialized

Do not prematurely encode implementation detail into governance prose unless it is actually semantic policy.

---

## 12. Agent / editor / runtime integration plan now captured in roadmap

A major goal of the global audit was to move important decisions that existed only in session discussion into the governed roadmap.

### GV103 — Git-hook boundary

GV30 was superseded.

Old GV30 implied Govenv would later directly own Git-hook integration.

New intent:

- Govenv owns staged candidate / commit-gate semantics.
- The active runtime backend owns operational hook installation/mechanics.
- Stage 0 uses devenv.
- Hook manager/provider mechanics are integration concerns.

This preserves provider neutrality.

### GV104 — scoped Protocol advice

Separates:

- `govenv check`
  - authoritative Governance evaluation
- scoped Protocol advice
  - semantic focus or candidate delta
  - informative, non-constitutional

Applicability belongs to Protocol semantics.

Relevance/scoping belongs to projection/incremental selection.

Do not bake editor `didChange` state or agent-host transport into Protocol semantics.

Illustrative CLI ideas discussed before, not yet frozen:

```text
govenv check
govenv advise <focus>
govenv advise --base X --candidate Y
```

### GV105 — coding-agent lifecycle boundaries

Provider-neutral agent lifecycle integration.

Desired semantics:

```text
BeforeTool
    may gate / deny / rewrite governed effects

AfterTool
    may attach scoped Protocol advice/context
```

Provider capability/wire differences belong to adapters.

Unsupported agents fall back to available:

- LSP
- Git-hook
- authoritative check

without weakening final validation.

### GV106 — govenv shell

`govenv shell` should establish supported editor/coding-agent integrations for agents launched within that shell:

- lifecycle hooks
- LSP
- Git fallback boundary

Govenv must NOT:

- package the coding-agent executable
- own the agent itself

This matches the user's explicit requirement that the coding agent is launched inside `govenv shell`, but is not a Govenv package.

### GV107 — MCP optional

GV34 was superseded.

MCP is strictly:

- optional
- adapter-only

Core semantics must NOT depend on MCP:

- Governance
- Protocol
- `govenv check`
- scoped advice
- LSP
- Git hooks
- coding-agent lifecycle hooks

An MCP adapter may project the same context/diagnostics/advisories, but never becomes semantic authority.

### GV88 remains central

Earliest-sound-information-boundary principle.

Boundary ordering discussed:

```text
PreToolUse
    -> PostToolUse
    -> LSP diagnostic
    -> Git hook
    -> govenv check
    -> CI / PR gate
```

Interpretation:

- enforce an obligation at the earliest boundary with enough information/capability to soundly prevent the governed effect
- expose advice at the earliest boundary capable of delivering it without falsely becoming authority
- later stages may confirm earlier checks but should not independently redefine semantics
- final authoritative validation remains `govenv check` / CI

---

## 13. Devenv as Stage-0 operational control plane

The accepted direction remains:

```text
Govenv semantic core
        ↓
devenv operational/runtime boundary
        ↓
LSP / Git hooks / agent lifecycle hooks / services / tasks
```

Do not generalize all Claude-specific devenv features into a generic agent abstraction.

Only the lifecycle-hook plane is a strong candidate for genericization.

Claude-specific:

- skills
- subagents
- permissions
- commands

should remain Claude-specific unless a truly common semantic abstraction emerges.

---

## 14. Agenthooks research

The leading reusable library identified was:

`speakeasy-api/agenthooks`

Important characteristics discovered:

- Go library
- normalized lifecycle API
- events like:
  - `OnToolPre`
  - `OnToolPost`
  - `OnToolError`
  - `OnPrompt`
  - `OnPermission`
  - `OnStop`
- decision model:
  - NoDecision
  - Allow
  - Ask
  - Deny
- handles provider:
  - JSON wire formats
  - config rendering
  - shims
  - capability differences
  - fail modes
- advertised providers included Claude Code, Cursor, Codex, Gemini, OpenCode, Kimi, OpenClaw, GitHub Copilot CLI, VS Code Copilot
- at research time it did not advertise Crush/Pi

Important mismatch with devenv:

### devenv hook model

Declarative arbitrary command per event:

```nix
hookType = ...
matcher = ...
command = ...
```

### agenthooks model

A consumer Go binary embeds the library and registers handlers.

Its `Manifest.Command` points back to the consumer executable; it is not a generic shell-command handler.

Therefore:

A small provider-neutral `exec` bridge is probably needed if devenv is to retain a declarative command-hook model while using agenthooks as the provider normalization runtime.

Desired runtime shape:

```text
provider
  -> agenthooks
  -> normalized Event
  -> generic exec bridge
  -> govenv gate/advise
  -> normalized Decision
  -> agenthooks
  -> provider
```

Do NOT write provider adapters in Govenv if upstream agenthooks can own them.

Preferred direction:

- contribute Crush/Pi support upstream to agenthooks if necessary
- keep provider quirks outside Govenv

Open research for later:

- inspect actual normalized `Event` / `Decision` / runner Go types
- design minimal `agenthooks-exec` ABI:
  - event kind
  - provider
  - tool name
  - canonical tool input
  - cwd/session IDs where useful
  - allow/deny/ask
  - input rewrite
  - additional context
  - fail open/closed
  - timeout
  - deterministic multi-hook composition
  - provider capabilities

No implementation of this integration was included in PR #32.

---

## 15. LSP

LSP remains adapter/projection, not authority.

Key accepted points:

- `DocumentURI` is transport identity, not semantic identity.
- Focus should resolve URI/position to Agda semantic identity.
- diagnostics are more relevant to coding agents than inlay hints.
- agent hosts often consume LSP diagnostics and append them to tool results; the LLM itself is not directly asynchronously listening.

ALS was inspected previously and should not be treated as the architectural foundation because important standard notification/diagnostic behavior was weak/incomplete.

Reuse upstream Agda reflection / compiler functionality rather than building a custom AST/import framework.

Potential upstream primitives already identified:

- Reflection `Name`
- `Definition`
- `getType`
- `getDefinition`
- stdlib `Reflection.AST.Traversal`
- Agda compiler `--dependency-graph`

Do not add `agda-stdlib-meta` without a concrete need.

---

## 16. PR #32 final validation

Before merge, final clean-tree validation was:

```text
roadmap IDs: 0..107
count: 108
duplicate IDs: none
missing IDs: none
invalid supersession targets: none

git diff --check          ✓
govenv:materialize        ✓
govenv:admin:build        ✓
govenv:check              ✓
```

`govenv:admin:build` successfully compiled the new repository metadata adapter.

The final derived materialization commit was explicitly marked:

```text
Derived-From-Parent: true
```

This matters because release/changelog provenance resolves through derived commits to the causal semantic revision and avoids materialization commits becoming self-referential release-note authority.

A final issue caught during validation:

A manually created materialization commit lacked `Derived-From-Parent: true`, causing `govenv:check` to detect changelog drift/self-reference.

This was corrected before merge.

Remember this pattern whenever creating a manual derived materialization commit.

---

## 17. Architecture fix was rewritten into GV98 introduction history

GV54 says established Governance identity/definition/owning phase is immutable.

During the review, the exact proposition of GV98 was corrected before merge.

Rather than mutate it in a later commit, history was rewritten so the corrected GV98 definition is born in its introduction commit.

The subsequent materialization commit was regenerated.

This is the correct pattern while a Governance item is still only inside an unmerged branch and its introduction history can be safely rewritten.

After merge, never mutate GV98's definition directly. A changed intent now requires a newer GV + supersession.

---

## 18. Current roadmap additions from this session

New GVs introduced during the global coherence pass:

### GV100
Canonical project purpose + public repository metadata:
- purpose
- description limits
- README purpose projection
- website
- topics
- GitHub read-back materialization

### GV101
Governance / Protocol / irreducible effects partition.

Supersedes GV57, GV58, GV59.

### GV102
Semantic authority vs materialization binding.

Supersedes GV51.

### GV103
Provider-neutral Git-hook boundary owned operationally by active runtime backend.

Supersedes GV30.

### GV104
Constitutional Findings vs scoped non-constitutional Protocol advice.

### GV105
Provider-neutral coding-agent lifecycle integration.

### GV106
`govenv shell` establishes agent/editor integrations without packaging the coding agent.

### GV107
MCP optional and adapter-only.

Supersedes GV34.

The exact post-merge ordering/current item should be inspected fresh from `main`.

---

## 19. Conceptual end-state

The project purpose and architecture now converge on:

```text
                  Govenv.Project
                  purpose / identity
                         │
          ┌──────────────┴──────────────┐
          │                             │
    Governance                       Protocol
 constitutional validity          process guidance
          │                             │
          └──────────────┬──────────────┘
                         │
                    semantic kernel
                         │
       ┌─────────────────┼─────────────────┐
       │                 │                 │
   Assurance       Materialization      Projection
       │                 │                 │
       └─────────────────┴──────────┬──────┘
                                   │
                                Adapter
                                   │
                        irreducible effects/IO
```

Operationally:

```text
Govenv semantic model
      ↓
Runtime backend / devenv
      ↓
shell / LSP / tasks / services / git hooks / agenthooks
      ↓
supported editor or coding agent
```

The coding agent itself remains outside Govenv ownership.

---

## 20. Suggested next move after opening a fresh session

First inspect current post-merge GitHub/main state.

Recommended immediate sequence:

1. Confirm PR #32 merge commit and current `main`.
2. Pull/update the local worktree from merged `main`.
3. Run or inspect CI from the merge.
4. If `Admin Materialize` has not yet been run after merge:
   - inspect whether the new repository metadata step is ready,
   - then have the user explicitly run/authorize it if needed.
5. Read the current roadmap from `main` and let it determine the next governance item.
6. Likely continue with the architecture/integration program:
   - GV101 / global classification,
   - GV102 materialization semantics,
   - GV98 reflected-Name classification/import enforcement,
   - then later GV104–GV107 agent/editor/runtime boundaries.

Do not jump directly into agenthooks implementation unless the roadmap/current state makes that the next appropriate work.

PR #32 deliberately captured the future direction without implementing the devenv/agenthooks integration.

---

## 21. Interaction style / user preferences for this project

The user prefers:

- direct technical dialogue in Portuguese;
- English identifiers for types/modules/concepts;
- pushback when a design is semantically weak;
- compile-time/static invariants over procedural validation;
- formal type/Agda representation when practical;
- reuse upstream ecosystem tooling rather than bespoke wrappers;
- minimal duplication of semantic authority;
- no implementation detail in Governance unless it is actually semantic policy;
- `lagda` for human-facing normative authority/evidence, not ordinary implementation documentation;
- no PR merge unless explicitly requested;
- when the user says `prossiga` / `continue`, proceed without redundant clarification.

The user explicitly accepted:
- Govenv should not package the coding agent.
- Supported agents are assumed to be launched from inside `govenv shell`.
- MCP is optional.
- LSP is important for agents/editors but remains a projection/adapter boundary.
- Git hooks are provider-independent fallback, not final authority.
- Final authority remains `govenv check` / CI.
