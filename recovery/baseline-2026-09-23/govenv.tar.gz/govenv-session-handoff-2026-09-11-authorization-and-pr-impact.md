# Govenv session handoff — 2026-09-11

This file is the canonical continuation context for the next session. It supersedes earlier conversational summaries where they conflict with decisions recorded here.

## 1. Non-negotiable operational rules

- Never merge any PR without explicit user approval.
- Never create/publish a release without explicit user approval, except the normal Release Please release that follows from the user explicitly merging the canonical Release Please PR.
- Never create a manual competing tag/release when Release Please is expected.
- Never manually edit the Release Please PR body; it is governed/materialized by automation.
- Never mark a GV `✓` merely because implementation exists. Completion requires governed evidence.
- No `amended`. Corrections require supersession.
- Governance identities are append-only; identity, proposition, and owning phase are immutable once introduced.
- Never modify GV71 wording.
- Keep WIP Assurance isolated from release/materialization work.

## 2. Repository / local worktrees

Repository: `klarkc/govenv`

Worktrees:

- `/home/klarkc/Sources/klarkc/govenv`
  - local `main` intentionally stale at `d18a4a3304114b7441282cdf59dd4ab82e897e7e`
  - `origin/main` is `ac963c3fad1f15f66dd73409564fbd2cb0480cb6`
  - DO NOT TOUCH existing WIP:
    - `M src/Govenv/Kernel/Assurance.agda`
    - `?? Govenv/Assurance/GV60.lagda.md`

- `/home/klarkc/Sources/klarkc/govenv-gv84`
  - branch: `gov/gv84-counterexample-closure`
  - local HEAD after rebase: `500e3e76de652fd6b8c255b3fe2648ea06c0716c`
  - this local branch is rebased onto `origin/main`
  - current uncommitted intended changes:
    - `M .govenv/roadmap.snapshot`
    - `M Govenv/Roadmap.lagda.md`
    - `M README.md`
  - accidental `devenv.lock` and `.devenv.flake.nix` changes caused by local devenv evaluation were cleaned and must not be included.
  - these new local governance changes have NOT been pushed to GitHub.

- `/home/klarkc/Sources/klarkc/govenv-pr5-verify`
  - detached verification worktree around the PR #5 hotfix.

## 3. GitHub state at handoff

### PR #5 — merged

`fix(release): parse quoted roadmap snapshot strings`

- merged at `2026-09-11T19:08:16Z`
- merge commit: `ac963c3fad1f15f66dd73409564fbd2cb0480cb6`
- real CI confirmed the parser hotfix works.

Subsequent workflows on `ac963c3...`:

- Materialize run #28 / `34637194136`: success.
- Test #85 / `34637763738`: completed successfully.
- Release #47 / `34637763733`: completed successfully.

### PR #3 — Release Please 0.2.1

`chore(main): release 0.2.1`

- open
- mergeable
- NOT merged
- NOT draft
- base SHA: `ac963c3...`
- head SHA: `22fcddbc...`
- Release Please automatically updated its body after the hotfix.
- Body now contains the enriched governed `Governance impact` section.
- Current impact in PR #3 reports:
  - phase P1 unchanged
  - 2 advanced
  - 6 introduced
  - 1 superseded
  - includes the hotfix commit and sparse/revision-aware governance changes.

DO NOT merge PR #3 without explicit user approval.

### PR #6 — regression closure governance

`gov(assurance): define regression closure policy`

GitHub remote state is still the OLD one:

- open
- draft
- mergeable
- remote head SHA: `c847e346...`
- remote base SHA still `e0b59a...`
- remote body still describes only GV84 + GV85.

The local PR #6 worktree has been rebased onto current `origin/main` and contains additional uncommitted decisions from this session. Those are not yet on GitHub.

DO NOT merge PR #6 without explicit user approval.

## 4. Release architecture already established

Same typed release semantics feed three targets:

1. `CHANGELOG.md` — canonical portable Markdown materialization.
2. Release Please PR body — enriched GitHub projection.
3. Published GitHub Release body — enriched GitHub projection + read-back verification.

Boundary remains:

```text
Materialization/domain → owns semantics, ordering, policy, capabilities
Projection             → owns only target representation
Adapter                → owns only observation/effects/read-back
```

Never parse `CHANGELOG.md` back into governance semantics.

Release v0.2.0 already exists and is immutable.

## 5. Important inherited regression / coherence findings

### 5.1 GV54 has a real counterexample

GV54 says governance identity includes immutable definition and owning phase.
Current snapshot stores only `snapshotItemPhase : Nat`, not full phase identity/description.
A phase description can change while keeping the same phase number and current delta logic accepts it.

Required direction:

- preserve full phase identity in snapshot
- preserve the counterexample as governed evidence under GV84
- strengthen GV54 assurance
- DO NOT change GV54 wording

### 5.2 Snapshot grammar duplication

`roadmap-evolution.sh` and `release-governance.sh` duplicate snapshot parsing semantics.
The quoted-string regression exposed this.
Desired canonical direction:

```text
decodeSnapshot (encodeSnapshot s) ≡ success s
```

Adapter should only observe bytes and invoke the governed decoder.

### 5.3 Evidence is not bound to the exact Claim

Current evidence is indexed only by GV number, allowing conceptually arbitrary evidence for an arbitrary claim at the same number.
Desired direction:

```text
exact governed Claim
        ↓
Evidence Claim
```

This blocks treating GV74 as complete.

### 5.4 GV62 architecture matrix is stale

Current architecture roles do not model Assurance explicitly, while assurance modules import more than the old matrix permits.
Likely direction:

- supersede GV62
- explicit Assurance role
- assurance may depend on pure layers it proves
- production layers must not depend on Assurance
- adapters may consume governed semantics but own none

### 5.5 Other still-open coherence items

- supersession target liveness: model permits replacement chains that could eventually terminate badly; current roadmap has no known bad chain. Needs semantic decision.
- `ReleaseKind` provenance: derive `major/minor/patch` from old/new SemVer via governed pure classifier; adapter only observes versions.
- capability activation: likely explicit `absent/experimental/active`, where activation requires governed establishment evidence.
- semantic commit classification: compare declared Conventional Commit type with governed semantic candidate delta where Govenv can model it.

## 6. Major decision: ADR-like / cumulative constitutional semantics

The user explicitly decided AGAINST typed dependency relationships such as `DependsOn GV...`.

Every new GV assumes the constitution as a whole, ADR-style.
This is not just all currently live/established governance: the user explicitly corrected this to mean the **complete constitution at that revision**, including historical `superseded` and `cancelled` items. Lifecycle state determines each item's operative effect, but historical items remain part of constitutional context/history.

Binding design:

```text
new GV
  ↓
interpreted against complete constitution at revision
  ↓
no explicit GV dependency graph
```

`todo` vs `done` is establishment/completion state, not constitutional membership or initial applicability.

### Local GV86 wording now in PR #6 worktree

```text
GV 86 "Treat governance items as cumulative constitutional decisions: from introduction onward, every item is interpreted against the complete constitution at that revision, including `todo`, `done`, `superseded`, and `cancelled` history; lifecycle state determines operative effect rather than constitutional membership, completion records establishment rather than applicability, and explicit dependency relationships between governance items are neither required nor modeled." ◇
```

This wording reflects the latest correction and is locally materialized but not committed/pushed.

## 7. PR Governance Impact decision

User agreed it is useful to expose the typed governance delta on ordinary PRs, not only release PRs.

Preferred UX/architecture:

- use a GitHub-native Check as the primary projection
- use workflow artifact only as transient inspection material
- reuse the SAME typed `GovernanceDelta`; do not invent PR-specific semantics
- candidate delta should represent the PR's causal contribution, conceptually `merge-base(base, head) → head`
- `govenv check` remains authoritative
- GitHub adapter must not own policy

### Artifact retention decision

GitHub workflow artifacts have finite retention (commonly ~90 days/configurable). Do NOT hardcode `90 days` as constitutional semantics.

Rule must instead say that external/transient artifact retention is finite and therefore artifacts must NEVER be the sole or authoritative governance evidence.
Anything required for:

- completion
- regression closure
- auditability
- future validation

must persist in governed, revision-addressable form from which transient GitHub projections/artifacts can be reproduced.

### Local GV87 wording

```text
GV 87 "Project the typed candidate governance delta of every governed pull request through a GitHub-native check derived from revision-aware governance state; workflow artifacts may provide transient inspection material, but finite external retention means they must never be the sole or authoritative governance evidence, and any evidence required for completion, regression closure, auditability, or future validation must persist in governed revision-addressable form from which transient projections can be reproduced." ◇
```

Currently placed in P1. Locally materialized, not committed/pushed.

## 8. Earliest-sound-enforcement governance

User asked for a governance rule saying every item should be anticipated/enforced as early as sound, as close as possible to the language/Agda source of truth.

Important principle:

```text
early validation ≠ independent policy
early validation ≠ final authority
```

All surfaces must derive from the same governed rule; later layers may confirm but must not re-own semantics.

User then asked to INVENTORY what can be anticipated and incorporate that inventory into the GV itself.

The inventory was organized by information boundary, not hard-coded GV numbers, so future GVs inherit the principle without requiring GV88 to be superseded each time.

### Local GV88 wording

```text
GV 88 "Require every governable obligation to be enforced at its earliest sound information boundary while retaining `govenv check` as the authoritative repository evaluation and deriving every anticipatory enforcement from the same governed rule. Maintain an explicit enforcement inventory that anticipates, at minimum: construction-time Agda constraints for typed identities, roadmap/lifecycle validity, constitutional structure, evidence relationships, pure kernel boundaries, and projection/materialization structure; static candidate or incremental/LSP checks for governance evolution, immutable identity, architecture imports, handwritten-source restrictions, materialization ownership and drift, artifact colocation, documentation references, regression obligations, governance/release deltas, and release-progress classification; commit-boundary checks for staged candidate validity, commit policy, governance references, semantic commit classification, and regression signals; PR/CI checks only for information first available from GitHub or the remote candidate; and post-effect checks only for irreducible external observations such as read-back equality, publication state, admin effects, and runtime facts. Later stages may confirm earlier results but must not re-own, duplicate, or independently specify semantics that were soundly enforceable earlier." ◇
```

Placed in P4. Locally materialized, not committed/pushed.

## 9. GV85 phase correction discovered by actual validation

Earlier we reasoned GV85 belongs in P3 because it is commit governance.
An attempted direct move P1 → P3 was rejected by existing governance:

```text
Immutable governance owner phase was changed for GV85 from P1 to P3
```

This is correct behavior under GV54.

Therefore the local roadmap now preserves GV85 in P1 as historical and supersedes it:

```text
GV 85 "...fix regression signal..." ↪ GVR 89
```

Then introduces the same corrected decision in P3:

```text
GV 89 "Treat the case-insensitive standalone word `fix` in governed commit messages as a conservative regression signal: candidate commit validation must reject it unless the commit references governed regression evidence or carries an explicit justified non-regression exemption; no exemption may discharge an unresolved observed regression." ◇
```

This is locally materialized and `govenv:materialize` succeeds.

## 10. Local PR #6 diff currently intended

Current canonical Roadmap changes compared with local rebased HEAD:

- GV85: `◇` → `↪ GVR 89`
- add GV86 in P1: cumulative/ADR-like constitutional semantics
- add GV87 in P1: PR Governance Impact + transient-artifact rule
- add GV89 in P3: corrected placement of commit `fix` regression signal
- add GV88 in P4: earliest sound enforcement + inventory

Materializations regenerated:

- `.govenv/roadmap.snapshot`
- `README.md`

`govenv:materialize` completed successfully after correcting the illegal GV85 phase move.

These changes are UNCOMMITTED and UNPUSHED.

## 11. Human authorization / AuthorizedRevision discussion — latest conceptual model

This was the final major architectural discussion of the session and is NOT yet materialized as a GV.

### 11.1 Current GitHub reality

Current repository `main` is:

- `protected: false`
- no branch-protection enforcement
- repository rulesets API returned `[]`

Current `.github/workflows/materialize.yml` has:

```yaml
permissions:
  contents: write
```

and ultimately:

```sh
git push origin HEAD:main
```

Therefore today a principal/agent holding suitable repository write credentials can directly commit/push to `main`. The Materialize workflow itself already does so.

### 11.2 Do NOT prematurely supersede GV44

We initially considered "main only through PR" but identified an important distinction:

- semantic/autoral changes create new authority
- deterministic materialization commits merely close consequences already authorized

User does NOT currently want to remove GV44's direct-main Materialize behavior merely for purity.
No supersession of GV44 has been approved.

### 11.3 Why "everything must be inside the PR" is insufficient

Some governed effects are external and cannot be contained in a PR tree, e.g.:

- creating a GitHub Release
- repository description changes
- future external/admin materializations

Therefore the correct abstraction is not "the PR contains every effect".

The PR/revision must determine the expected effects; the effects may happen only later and then be read back/verified.

### 11.4 Chosen trust model

The important unit is an **AuthorizedRevision**.

Conceptual flow:

```text
candidate revision X
      │
      │ untrusted / no privileged materialization capability
      ▼
PR reviewed and explicitly merged by a human
      │
      ▼
AuthorizedRevision X
      │
      ├─ deterministic repository materialization
      ├─ GitHub Release
      ├─ admin/external materialization
      └─ other governed derived effects
```

The user agreed that once a human has approved/merged the exact PR revision that generates those effects, that revision's code/configuration can be treated as trusted for executing its governed effects.

Therefore a separate external "trusted materializer service" is NOT currently considered necessary.

### 11.5 Security boundary that matters

Before human authorization:

```text
candidate code = untrusted
privileged capabilities = unavailable
```

After human merge of the exact revision:

```text
authorized revision = trusted
necessary governed capabilities may become available
```

Derived effects must NOT create new semantic authority.
They must remain causally attributable to the original human-authorized revision.

Example:

```text
human-authorized X
      ↓
bot materialization commit Y
      ↓
Y is derived from X, not a new independent authorization
```

Similarly:

```text
GitHub Release R
  └─ derived from AuthorizedRevision X
```

The next design should prevent a bot-derived effect from recursively being treated as a fresh human authorization.

### 11.6 Scoped token / GitHub App discussion

A dedicated scoped token, analogous to `GOVENV_ADMIN_TOKEN`, was discussed.
A GitHub App with a separate machine identity and short-lived installation token may be preferable to a PAT, but this is NOT decided.

Critical observation:

- `Contents: write` is coarse; a token with it can technically write more than just materializations.
- If candidate/untrusted code gets that token, privilege escalation is possible.
- But under the chosen model, privileged credentials/capabilities only become available to code after the exact revision was human-authorized.

So the security argument is not "the token is mathematically incapable of arbitrary writes". It is:

```text
only human-authorized repository code crosses the privileged boundary
```

combined with governance requiring derived effects to be deterministic and to create no independent semantic authority.

Potential later hardening:

- ruleset on `main`
- block arbitrary direct pushes
- allow a dedicated Materializer identity to bypass only as the governed materialization actor
- candidate PR workflows have no privileged materialization credentials
- authorized post-merge workflows may use scoped credentials

Exact GitHub ruleset/token/App materialization remains to be designed.

### 11.7 Provisional future GV direction

Do NOT copy this blindly without re-evaluating exact wording. The agreed semantics are approximately:

> Every new semantic authority exercised by Govenv must originate from an exact repository revision explicitly authorized by a human pull-request merge. Candidate revisions must not receive privileged materialization capabilities; after authorization, governed automation may exercise capabilities necessary to produce deterministic repository or external materializations derived from that revision, but such derived effects create no independent semantic authority and must remain causally attributable to the authorizing revision.

Likely P1 because this defines the project's authorization model.

This should probably become the next new GV after 89 (likely GV90 if numbering remains unchanged), but it has NOT been added yet.

## 12. Relationship to existing GVs

The new authorization model should be designed coherently with:

- GV44 — automatic versioned non-admin materializations on `main`
- GV45 — external/admin read-back equality + execution evidence
- GV46 — typed admin materialization evidence
- GV51 — materialization semantic closure; materializations own no independent semantics
- GV59 — adapters/effects must not introduce semantic content/policy/authorization decisions
- GV74 — completion requires persistent governed evidence
- GV84 — observed regressions require counterexample-closing evidence
- GV86 local — all new governance is interpreted against the entire constitution
- GV88 local — enforce each obligation at earliest sound information boundary

Do not add typed `DependsOn` relationships among these. Their interaction follows the cumulative-constitution model.

## 13. Exact important GVs that must be preserved

### GV71 — NEVER MODIFY

```text
GV 71 "Restrict handwritten versioned repository content to Agda and Markdown only. Any generated or governed materialization may use its required target format. Until GV38 is completed, the only handwritten bootstrap escape hatch is root-level `devenv.nix`, `devenv.yaml`, and `devenv.lock`; all other implementation languages and handwritten configuration formats, including Nix elsewhere, are forbidden." ◇
```

### GV84

```text
GV 84 "Make observed invariant regressions counterexample-closing: once a contradiction to a governed or relied-upon invariant is recorded as an observed regression, its repair is incomplete until the counterexample is preserved as governed evidence, the missing or incorrectly scoped assurance boundary is corrected or overstated governance superseded, and candidate validation rejects recurrence before the affected workflow may succeed." ◇
```

### GV89 local replacement for GV85

```text
GV 89 "Treat the case-insensitive standalone word `fix` in governed commit messages as a conservative regression signal: candidate commit validation must reject it unless the commit references governed regression evidence or carries an explicit justified non-regression exemption; no exemption may discharge an unresolved observed regression." ◇
```

## 14. Suggested next-session order

1. Load this handoff and inspect the local PR #6 worktree before changing anything.
2. Preserve main WIP untouched.
3. Review the exact local GV86/GV87/GV88/GV89 wording for global coherence.
4. Turn the agreed AuthorizedRevision / human-merge trust model into an exact governance proposition (likely next GV in P1).
5. Decide its GitHub enforcement/materialization separately (ruleset + identity/token/App), without embedding implementation details in the constitutional wording unless truly semantic.
6. Re-run a full global coherence check across GVs/phases after adding the authorization GV.
7. Continue unresolved correctness work:
   - GV54 full phase identity counterexample/evidence
   - canonical snapshot codec / parser regression closure
   - exact Claim ↔ Evidence binding
   - supersede GV62 with explicit Assurance role
   - ReleaseKind provenance
   - capability activation evidence
   - semantic commit classification
8. Regenerate materializations and validate.
9. Only then update/push PR #6 as appropriate.
10. Never merge PR #6 or PR #3 without explicit user approval.

## 15. Core design principles now binding

```text
Constitution is cumulative and ADR-like.
No explicit GV dependency graph.
All historical governance remains constitutional context.
Lifecycle determines operative effect.
Materializations contain no independent semantics.
Checks/projections/adapters do not re-own policy.
Enforce as early as sound, but keep one governed semantic source.
Transient GitHub artifacts are never authoritative evidence.
Human merge of an exact PR revision is the intended root of new semantic authority.
Candidate code is untrusted; privileged materialization capability belongs only after authorization.
Derived repository/external effects may be automatic but create no new independent semantic authority.
Every derived effect must remain causally attributable to the human-authorized revision.
```
